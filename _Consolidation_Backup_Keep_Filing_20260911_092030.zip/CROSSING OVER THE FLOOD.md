

Crossing over the Flood
Ogha-taraṇa Sutta  (SN 1:1)

NAVIGATIONSuttas/SN/1:1

I have heard that on one occasion the Blessed One was staying near Sāvatthī in Jeta’s Grove, Anāthapiṇḍika’s monastery. Then a certain devatā, in the far extreme of the night, her extreme radiance lighting up the entirety of Jeta’s Grove, went to the Blessed One. On arrival, having bowed down to him, she stood to one side. As she was standing there, she said to him, “Tell me, dear sir, how you crossed over the flood.”
“I crossed over the flood without pushing forward, without staying in place.”
“But how, dear sir, did you cross over the flood without pushing forward, without staying in place?”
“When I pushed forward, I was whirled about. When I stayed in place, I sank. And so I crossed over the flood without pushing forward, without staying in place.”

The devatā:
“At long last I see
a brahman, totally unbound,
who
without pushing forward,
without staying in place,
has crossed              over
the entanglements
of the world.”

That is what the devatā said. The Teacher approved. Realizing that “The Teacher has approved of me,” she bowed down to him, circumambulated him—keeping him to her right—and then vanished right there.
See also: MN 138; Ud 8:1
