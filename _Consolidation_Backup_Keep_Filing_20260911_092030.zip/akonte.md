---
tags: []
---

Patience in discomfort 