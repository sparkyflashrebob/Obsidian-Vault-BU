
court ordered meditation