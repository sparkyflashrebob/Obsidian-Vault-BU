---
tags:
- forteaching
---

1. Can we pause and be with - come to body and feel our feelings - allows more choices
2. Attuning to others - secret suffering of others
3. Comprehensive mindfulness - structural - larger currents - playing a role - heirarchy
4. Group Guidelines for process
5.  Agreement for process
6. Wise Listening and speech

Mistakes I have made

A. Getting caught in the conflict
B. No preset process
C. Not mindful of structural dynamics
D. Timing - speed of response - felt disrespect and not caring - you are in power you can afford to do
E. Building relationships needed/listening critical

Deep listening

Principles around truth and reconciliation
Restorative Justice
profoundly spiritual
everyone's needs are valued and without blame



