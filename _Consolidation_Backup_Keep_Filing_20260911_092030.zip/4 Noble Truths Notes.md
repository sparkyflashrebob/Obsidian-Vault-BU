
From Majjima 2
ALL THE TAINTS

(SUMMARY)
 3. “Bhikkhus, I say that the destruction of the taints is for one who knows and sees, not for one who does not know and see. Who knows and sees what? Wise attention and unwise attention. 33 When one attends unwisely, unarisen taints arise and arisen taints increase. When one attends wisely, unarisen taints do not arise and arisen taints are abandoned. 
 4. 4. “Bhikkhus, there are taints that should be abandoned by seeing. There are taints that should be abandoned by restraining. There are taints that should be abandoned by using. There are taints that should be abandoned by enduring. There are taints that should be abandoned by avoiding. There are taints that should be abandoned by removing. There are taints that should be abandoned by developing.


These are the things unfit for attention that he attends to.
increase. 
7. “This is how he attends unwisely: ‘Was I in the past? Was I not in the past? What was I in the past? How was I in the past? Having been what, what did I become in the past? Shall I be in the future? Shall I not be in the future? What shall I be in the future? How shall I be in the future? Having been what, what shall I become in the future?’Or else he is inwardly perplexed about the present thus: ‘Am I? Am I not? What am I? How am I? Where has this being come from? Where will it go?’38 
8. “When he attends unwisely in this way, one of six views arises in him. 39 The view ‘self exists for me’arises in him as true and established; or the view ‘no self exists for me’arises in him as true and established; or the view ‘I perceive self with self’arises in him as true and established; or the view ‘I perceive not-self with self’arises in him as true and established; or the view ‘I perceive self with not-self’arises in him as true and established; or else he has some such view as this: ‘It is this self of mine that speaks and feels and experiences here and there the result of good and bad actions; but this self of mine is permanent, everlasting, eternal, not subject to change, and it will endure as long as eternity.’40 This speculative view, bhikkhus, is called the thicket of views, the wilderness of views, the contortion of views, the vacillation of views, the fetter of views. Fettered by the fetter of views, the untaught ordinary person is not freed from birth, ageing, and death, from sorrow, lamentation, pain, grief, and despair; he is not freed from suffering, I say.

11 
He attends wisely: ‘This is suffering’; he attends wisely: ‘This is the origin of suffering ’; he attends wisely: ‘This is the cessation of suffering’; he attends wisely: ‘This is the way leading to the cessation of suffering.’ 41 When he attends wisely in this way, three fetters are abandoned in him: personality view, doubt, and adherence to rules and observances. These are called the taints that should be abandoned by seeing. 42
