---
aliases:
  - Goodwill
  - Mettā Sutta  (AN 11:16)
tags:
  - quotes
  - core
---

“Monks, for one whose awareness-release through goodwill is cultivated, developed, pursued, given a means of transport, given a grounding, steadied, consolidated, and well-undertaken, eleven benefits can be expected. Which eleven?

“One sleeps easily, wakes easily, dreams no evil dreams. One is dear to human beings, dear to non-human beings. The devas protect one. Neither fire, poison, nor weapons can touch one. One’s mind gains concentration quickly. One’s complexion is bright. One dies unconfused and—if penetrating no higher—is headed for a Brahmā world.

“These are the eleven benefits that can be expected for one whose awareness-release through goodwill is cultivated, developed, pursued, handed the reins, taken as a basis, steadied, consolidated, and well-undertaken.”