---
tags:
- inspirational
---

Rumi
