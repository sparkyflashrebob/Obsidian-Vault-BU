
Awareness knowing itself