---
aliases:
- 'Establishing Mindfulness '
tags:
- daily-reminders
- core
- quotes
- mindfulness
---

My friends, it is through the establishment of the lovely clarity of mindfulness that you can let go of grasping after past and future, overcome attachment and grief, abandon all clinging and anxiety, and awaken an unshakable freedom of heart, here, now. —Buddha