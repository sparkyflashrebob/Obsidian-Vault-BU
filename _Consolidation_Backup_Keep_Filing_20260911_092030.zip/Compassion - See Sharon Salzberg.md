---
tags:
- brahmavihara/paramis
---
