---
aliases:
  - An Analysis of Dependent Co-arising
  - Paṭiccasamuppāda Vibhaṅga Sutta  (SN 12:2)
---

An Analysis of Dependent Co-arising
Paṭiccasamuppāda Vibhaṅga Sutta  (SN 12:2)

NAVIGATIONSuttas/SN/12:2

Staying near Sāvatthī … “Monks, I will describe & analyze dependent co-arising for you. And what is dependent co-arising?
From ignorance as a requisite condition come fabrications.
From fabrications as a requisite condition comes consciousness.
From consciousness as a requisite condition comes name-&-form.
From name-&-form as a requisite condition come the six sense media.
From the six sense media as a requisite condition comes contact.
From contact as a requisite condition comes feeling.
From feeling as a requisite condition comes craving.
From craving as a requisite condition comes clinging/sustenance.
From clinging/sustenance as a requisite condition comes becoming.
From becoming as a requisite condition comes birth.
From birth as a requisite condition, then aging-&-death, sorrow, lamentation, pain, distress, & despair come into play. Such is the origination of this entire mass of stress & suffering.
“Now which aging-&-death? Whatever aging, decrepitude, brokenness, graying, wrinkling, decline of life-force, weakening of the faculties of the various beings in this or that group of beings, that is called aging. Whatever deceasing, passing away, breaking up, disappearance, dying, death, completion of time, break up of the aggregates, casting off of the body, interruption in the life faculty of the various beings in this or that group of beings, that is called death.
“And which birth? Whatever birth, taking birth, descent, coming-to-be, coming-forth, appearance of aggregates, & acquisition of (sense) media of the various beings in this or that group of beings, that is called birth.
“And which becoming? These three becomings: sensual becoming, form becoming, & formless becoming. This is called becoming.
“And which clinging/sustenance? These four are clingings: sensuality-clinging, view-clinging, habit-&-practice-clinging, and doctrine-of-self-clinging. This is called clinging. [Or: These four are sustenances: sensuality-sustenance, view-sustenance, habit-&-practice-sustenance, and doctrine-of-self-sustenance.]
“And which craving? These six are classes of craving: craving for forms, craving for sounds, craving for smells, craving for tastes, craving for tactile sensations, craving for ideas. This is called craving.
“And which feeling? These six are classes of feeling: feeling born from eye-contact, feeling born from ear-contact, feeling born from nose-contact, feeling born from tongue-contact, feeling born from body-contact, feeling born from intellect-contact. This is called feeling.
“And which contact? These six are classes of contact: eye-contact, ear-contact, nose-contact, tongue-contact, body-contact, intellect-contact. This is called contact.
“And which six sense media? These six are sense media: the eye-medium, the ear-medium, the nose-medium, the tongue-medium, the body-medium, the intellect-medium. These are called the six sense media.
“And which name-&-form? Feeling, perception, intention, contact, & attention: This is called name. The four great elements, and the form dependent on the four great elements: This is called form. This name & this form are called name-&-form.
“And which consciousness? These six are classes of consciousness: eye-consciousness, ear-consciousness, nose-consciousness, tongue-consciousness, body-consciousness, intellect-consciousness. This is called consciousness.
“And which fabrications? These three are fabrications: bodily fabrications, verbal fabrications, mental fabrications. These are called fabrications.
“And which ignorance? Not knowing stress, not knowing the origination of stress, not knowing the cessation of stress, not knowing the way of practice leading to the cessation of stress: This is called ignorance.
“Now from the remainderless fading & cessation of that very ignorance comes the cessation of fabrications. From the cessation of fabrications comes the cessation of consciousness. From the cessation of consciousness comes the cessation of name-&-form. From the cessation of name-&-form comes the cessation of the six sense media. From the cessation of the six sense media comes the cessation of contact. From the cessation of contact comes the cessation of feeling. From the cessation of feeling comes the cessation of craving. From the cessation of craving comes the cessation of clinging/sustenance. From the cessation of clinging/sustenance comes the cessation of becoming. From the cessation of becoming comes the cessation of birth. From the cessation of birth, then aging & death, sorrow, lamentation, pain, distress, & despair all cease. Such is the cessation of this entire mass of stress & suffering.”
See also: DN 15; MN 9; Sn 3:12