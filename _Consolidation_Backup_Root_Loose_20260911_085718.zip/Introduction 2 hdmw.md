---
Created: 2023-07-09
---
And this workshop, we reconnect with the sacred drum drumming connects you with your bones your heartbeat and your natural rhythms you connect with the drum by holding it close to your heart and letting your feelings transfer into the drum when we breathe we all beat upon a common drum The drum acts as a mediator between the drummer and the spirits between space and time power and people The drum can change the drum the direction of a ceremony calling everyone's attention and eliminating distractions when we drum our 10 IR out and are intuition is acute and we feel for atmosphere feel for spirit and as we wait and call for a sacred space to be filled with wonkin all that is holy and sacred the drum acts as a channel a method of centering and projecting the attention into the areas of consciousness that in normal life are unobtainable

Drumming is an opportunity to serve spirit the very source of all of our lives and all that surrounds us in this beautiful planet we need to feel inspiration we need to feel as if we are coming from the real me where love rests and there is no fear we sit here beating our drum waiting for guidance activity actively seeking guidance through the slow gentle connection that did drum beat gives us it does not take long it is the intention that counts as we strike the skin with the stick we move into the desire to serve clearly and in our minds we begin to speak to spirit 

Forward by grandfather Wallace black elk

this is the story of the drum The drum keeper is an old woman she lives north at a lake far away first came to thunder and lightning this was the first wave The second wave came and the second wave was a continuous noise continuous sound The people had come to seek the old woman asked each other can you drum no was the answer from everyone so there was no drummer 

they went on to meet the old lady and when they got there at daybreak they heard the sound of the drum it was a good sound a sound of welcome for the spirit kin for family they could hear all of their relatives in that drum sound for 4 days of herd that drum beat and then found it was a woodpecker tapping on a hollow log so it is woodpecker who is the drum keeper 

this is a story of how the first ceremonial drum was made they found a hollow log and they stretch an animal skin on each end and they put a willow around it and then they heard the rain snow wind and all the natural elements and then they heard thunder echo in the clouds with lightning flashing across the sky and they heard a voice yell it was a woman's voice
