---
tag: 4_Noble_Truths, reality, stress, origination, cessation
Source: SN 56.20 PTS S v 430
Translator: Thanissaro Bhikkhu
URL: https://www.accesstoinsight.org/tipitaka/sn/sn56/sn56.020.than.html
Created: 2023-04-28
---
"Monks, these four things are real, not unreal, not otherwise. Which four?

"'This is stress,' is real, not unreal, not otherwise. 'This is the origination of stress,' is real, not unreal, not otherwise. 'This is the cessation of stress,' is real, not unreal, not otherwise. 'This is the path of practice leading to the cessation of stress,' is real, not unreal, not otherwise.

"These are the four things that are real, not unreal, not otherwise.

"Therefore your duty is the contemplation, 'This is stress... This is the origination of stress... This is the cessation of stress... This is the path of practice leading to the cessation of stress.'"