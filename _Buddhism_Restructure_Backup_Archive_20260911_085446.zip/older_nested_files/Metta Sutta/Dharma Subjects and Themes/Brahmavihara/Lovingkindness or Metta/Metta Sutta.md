---
tag: mettasutta, chanting, dharma
Created: 2023-10-14
---
[This is what should be done] 
By one who is skilled in goodness 
And who knows the path of peace: 
Let them be able and upright, 
Straightforward and gentle in speech, 
Humble and not conceited, 
Contented and easily satisfied, 
Unburdened with duties and frugal in their ways. 
Peaceful and calm, and wise and skillful, 
Not proud and demanding in nature. 

Let them not do the slightest thing 
That the wise would later reprove, 
Wishing: In gladness and in safety, 
May all beings be at ease. 

Whatever living beings there may be, 
Whether they are weak or strong, omitting none, 
The great or the mighty, medium, short, or small, 
The seen and the unseen, 
Those living near and far away, 
Those born and to꜕ be born, 
May all beings be at ease  

Let none deceive another 
Or despise any being in any state. 
Let none through anger or ill-will 
Wish harm upon another. 
Even as a mother protects with her life 
Her child, her only child, 
So with a boundless heart 
Should one cherish all living beings, 
Radiating kindness over the entire world: 
Spreading upwards to the skies 
And downwards to the depths, 
Outwards and unbounded, 
Freed from hatred and ill-will. 

Whether standing or walking, seated, 
Or lying down — free from drowsiness 
One should sustain this recollection. 
This is said to be the sublime abiding. 

By not holding to fixed views, 
The pure-hearted one, having clarity of vision, 
Being freed from all sense-desires, 
Is not born again into this world.