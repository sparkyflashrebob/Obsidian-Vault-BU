**

YONISO MANASIKÄRA stands for a form of "attention" that is "thorough" and "penetrative", and

therefore also "wise". To explore the connotations of yoniso manasikära, the present article will begin by examining the terms yoniso and manasikära individually, followed by surveying passages that are of relevance to the implications of the expression yoniso manasikāra, and to its importance in the thought world of the Pali canon.

  

### Yoniso

  

The term yoniso derives from yoni, which stands for a "womb", a "matrix", or a "place of origin". Thus yoniso can convey the sense of doing something "thoroughly" or "penetratively", in the sense of going "down to its origins". The idea of doing something in a penetrative manner can be seen in a simile that describes how examining a lump of foam in a manner that is yoniso leads to the realization that this lump of foam is empty of any substance (S. III, 140). In the context of this simile, yoniso conveys the idea of penetrating through the outer surface of phenomena - in this case the surface of a lump of foam- and realizing the true nature of what is found beneath this surface. 

  

The nuance of thoroughness, in the sense of doing something intensively, seems to be prominent in a description of someone who is stirred by the prospect of disease or death and thereon "thoroughly" endeavours, samviggo yoniso padahati, in order to progress on the path to liberation (A. II, 115). 'Another example would be a verse, which proclaims that the deathless can be attained even today by those who "thoroughly" apply themselves, amatam aj špi ca labhaniyam idam yo yoniso payunjati (Thig. 513). A monk who in this way "thoroughly endeavours, will reach the destruction of - dukkha, yoniso padaham bhikkhu, khayam dukkhassa păpușe (It. 10). The idea of thoroughness would also be relevant for an occurrence of yoniso in a verse that compares "thoroughly" restraining the mind to a mahout who controls an elephant, cittam ... tad ajj'aham niggahess imi yoniso, hatthippabhinnam viya anikusaggaho (Dhp. 326).

  

At times, yoniso can also convey the sense of "proper" or "appropriate". This meaning underlies a passage where a king finds out that the Buddhist monks make good use of robe material given to them, as once their robes become worn, they employ the cloth as mattress coverings, foot-wipers etc., and the shreds left over after such usage are kneaded with mud and used for construction work. This convinces the king that the monks make use of the cloth they receive in a "proper" manner, yoniso upanenti (Vin. II, 292). The nuance of appropriateness could also be relevant to a passage in the Bhumija Sutta, according to which it is not beneficial to live the holy life in an "improper" manner, ayoniso brahmacariyam carati (M. 111, 138).

  

Besides the nuances of thoroughness and appropriateness, yoniso often conveys the idea of doing something in a "wise" manner. This sense of the term becomes particularly evident with a set of similes, where the opposite term ayoniso stands for doing something in an unwise" or even "foolish" manner. One of these similes describes a woman wondering if the child she is pregnant with will be a male and thus become the heir to the family's wealth. In order to find out, she takes a knife and cuts open her own belly. As a result, she passes away together with the embryo. Such a way of acting is to seek for an inheritance in an "unwise" manner, like fools would do, yatha tambala ... ayoniso dayajam gavesanti (D. II, 331). The same imagery of seeking for something in an unwise manner, ayoniso, recurs in another simile which describes how a group of villagers tries to find the sound of a trumpet by speaking to the trumpet, shaking it and hitting it (D. II, 337). A third instance of the same imagery involves making a fire. Here someone tries to kindle a fire by just chopping up the fire sticks, a rather "unwise" manner, ayoniso, of searching for fire (D. II, 341). These three similes employ ayoniso in a way that clearly suggests the nuance of "wisely" for the opposite term yoniso.

  

The meaning of "wisely" as a central implication of the qualification yoniso can be seen in several occurrences of the term itself. Thus to put questions in a way that is yoniso, or to answer them in such a way, is the hallmark of a wise person, a pandita (A. I, 103). In contrast, one who is not capable of asking questions in such a manner will be reckoned a fool (D. 1. 118). Another type of context involves "wisely" reflecting on the import of the teachings one has heard, yoniso paccavekkhisam (Thag. 347). To investigate the teachings in a manner that is yoniso leads to purification and wisdom, yoniso vicine dhammam, evam tattha visujjhati (S. I, 34); yoniso vicine dhammam, padayattham vipassati (A. IV, 3). Thus yoniso can qualify the type of wise mental investigation that leads to liberation, vicinantiya yoniso (Thig. 85); or stand for wisely seeing with insight the true characteristics of reality, aniccam dukkan 'ti vipassa yoniso, suññam anattai (Thag. 1117).

  

In sum, then, yoniso in its early canonical usage conveys a sense of doing something "thoroughly", in an "appropriate" manner, and "wisely". These nuances cannot be neatly separated from each other and, even though at times one of these meanings may be more prominent, in other instances it would be difficult to decide on any of them. Thus the above selection of instances only intends to reflect the range of nuances conveyed by yoniso, without thereby implying that each occurrence has to necessarily correspond to only one of these three related meanings. An example for the convergence of these three nuances would be a verse that describes how a monk reached liberation after having practised in a yoniso manner, yoniso pațipajjitá (Thag. 158). His practice would have to have been "thorough", must have been "proper", and certainly was "wise".

  

### Manasikära

  

Translated literally, manasi karoti means to "do" or to "make" something "in the mind". Being one of the constituents of nāma (M. 1, 53), manasikára is an ever-present aspect of the mind. As such, manasikara lies at the origin of all experienced phenomena, manasikarasambhavā sabbe dhamma (A. IV, 339); since once attention arises, phenomena will arise, manasikarasamudaya dhammanam samudayo (S. V, 184).

  

Given that manasikára is present in all states of mind, the crucial question is: to what object and in what manner is this faculty of attention directed? If, for example, manasikära focuses on the feature of physical beauty, lust will invade the mind, subhanimittassa manasikarā rāgo cittam anuddha msessati (M. I, 26). Or else, if manasikara dwells on the bad qualities of another person, anger will arise (A. III, 187). Taking into account the need of avoiding the dire consequences of wrongly directed manasikära, the Buddha would teach his disciples how attention should be directed, evam manasikarotha, mãevam manas akattha (D. 1, 214). This "how" of directing attention, as one might well suspect from the thrust of the present article, should be yoniso, that is: "wise", "thorough" and "Appropriate".

  

### The implications of yoniso manasikära

  

Yoniso manasikára is thus a form of attention" purposely directed in a manner that is "wise" and at the same time "thorough" and "appropriate". A central task of yoniso manasikára, in line with its nature as a form of attention that goes to the very origin of things. is to explore the conditioned nature of phenomena. A case in point can be seen in the description of the process of mental development that preceded the awakening of Vipassi bodhisattva. His understanding of the dependent arising of each of the links of paticca samuppåda - old age and death, birth, etc. - took place through yoniso manasikára (D. II, 31 or S. 11, 5). Yoniso manasikära performed the same role in relation to the awakening of other previous Buddhas, including Gotama Buddha, who similarly developed insight into the links of paticca samuppāda with the help of yoniso manasikara (S. II, 9-10; See also S. II, 104).

  

In all these cases, yoniso manasikära was instrumental in arousing the wisdom that led to realization, yoniso manasikar á ahu paraya abhisamayo. Since Buddhas awaken on their own, without being taught the way to liberation by others, the potential of yoniso manasikära in preparing the ground for the arising of liberating insight can hardly be overestimated. That yoniso manasikära performed a rather crucial role in relation to Gotama Buddha's attainment of supreme liberation is also reflected in another discourse, which highlights that the Buddha's awakening took place through yoniso manasikära and through striving that was similarly directed in a yoniso manner, yoniso manasikarayoniso sammappadh in a anuttará imutti anuppattä (Vin. 1, 22 or S. 1, 105).

  

The practical implications of yoniso manasikara in relation to paticca samuppada are spelled out in several discourses, which clarify that such wise and penetrative attention focuses on the specific conditionality of phenomena: "when this is that comes to be with the arising of this, that arises" etc., imasmim sati idam hoti, imassa uppādā idam uppajati (e.g. S II, 95).

  

Paticca samuppāda is, however, certainly not the only object of yoniso manasikāra, a mental quality which much rather is of relevance to the entire field of insight. Yoniso manasikara directed to the impermanent nature of the five aggregates of clinging, in particular, has a considerable potential of leading to the destruction of lust and therewith to liberation (S. III, 52). It goes without saying that a similar outcome can also be attained if yoniso manasikára is directed to the impermanent nature of the senses or their objects (S. IV, 142). Besides awareness of impermanence, the range of yoniso manasikára also comprises giving attention to the five aggregates of clinging as something that is unsatisfactory, a disease, a tumour, a dart, a misery, an affliction, alien, disintegrating, empty and not-self (S. III, 167).

  

Yoniso manasikāra as a form of attention directed  to the true nature of phenomena stands in direct  contrast to ayoniso manasikīra, which according to  the Vibhanga can be characterized as 'mis'-taking what  is impermanent for permanent, anicce 'niccan'ri  ayoniso manasikaro, or mistaking what is  unsatisfactory for being satisfactory, what is not-self  for being self, and what is not beautiful for being  beautiful (Vibh. 373)

  

Cultivated in this way, voniso manasikára can become a powerful tool for de-conditioning the way to perception, safi, misinterprets the world of experience. Such misinterpretations are traditionally listed as the vipallasas, corresponding to the four types of ayoniso manasikara listed in the Vibhanga passage above. The operational mechanism of such perceptual misinterpretations through ayoniso manasikära is based on the very nature of said, whose task is to match information received through the sense doors with mental labels and concepts, leading to various associations and memories. Such concepts and associations are only too often tinged by desire, aversion and delusion, being the outcome of habitual reactions under the influence of defilements. Such habits have been built up throughout the past and continue to be fortified in the present, whenever such reactions recur. Due to the influence of these habitual reactions and associations, whatever is experienced will be apprehended together with the subjective notions the mind projects onto the data of the senses. Both come together in an almost inextricable mix, and the perceiver is mostly unaware of the degree to which his or her experience is influenced by preconceived notions and thereby mirrors and confirms subjective prejudices.

  

Ayoniso manasikara as a form of unwise and perhaps also somewhat 'superficial' attention perpetuates this state of affairs, where the falsification of data through safita remains unquestioned. The remedy here is yoniso manasikūra, a wise and penetrative form of attention that goes beyond the superficial appearance of things in order to come to know their true nature, however much disappointing this may be. Continuous training in yoniso manasikara will eventually change the way perception apprehends the world, whereby awareness of the true characteristics of reality will gradually become as ingrained in perceptual appraisal as the earlier habitual Reactions.

  

In view of this potential, it comes as no surprise that yoniso manasikära is a central condition for the arising of the awakening factors, just as its opposite ayoniso manasikāra is responsible for the arising of the hindrances (S. V, 94 and S. V, 84). The discourses express this by reckoning yoniso manasikara the "nutriment", dh ára, for the awakening factors (S. V, 104). That is, "attention that is "thorough" or "wise" quite literally "nourishes" the arising and establishment of those mental conditions that are directly responsible for awakening.

  

In particular, yoniso manasikära directed to the distinction between what is wholesome and what is unwholesome nourishes the awakening factor of investigation-of-phenomena, dhammavicaya; yoniso manasikāra aimed at exertion and effort nourishes the awakening factor of energy: yoniso manasikära in regard to tranquillity of body and mind nourishes the awakening factor of tranquillity; and yoniso manasikära directed to the characteristic of tranquillity and collectedness of the mind nourishes the awakening factor of concentration (S. V, 104). In the case of the awakening factors of mindfulness, joy and equanimity, yoniso manasikära should be aimed at whatever constitutes a basis for these awakening factors, their respective sambojjhangathaniya dhamma.

  

Besides standing in a close relationship to the development of the awakening factors, yoniso manasikāra is also relevant for examining if the factors of awakening are well established in one's mind (S. V, 76), or if the mind of another is ripe for attaining any of the four levels of awakening (D. III, 107).

  

The imagery of providing a "nutriment" for certain mental qualities or factors also applies to the hindrances. Here yoniso manasikara has the task of attending in such a way as to deprive the hindrances of nourishment. This takes place by directing yoniso manasikära to the absence of beauty, to loving kindness, to exertion and effort, to peacefulness of the mind, and to the distinction between what is wholesome and what is unwholesome in order to "de- nourish", as it were, the hindrances of sensual desire, ill-will, sloth-and-torpor, restlessness-and-worry, and doubt (S. V, 105).

  

In a more general way, the task of yoniso manasikāra comprises overcoming all three roots of evil. By wisely and thoroughly attending to the absence of beauty, the root defilement of lust, rāga, will no longer arise in the mind. Attending to loving kindness with yoniso manasikära will lead to overcoming the root defilement of anger, dosa; and by dint of simply developing yoniso manasikāra as such it will be possible to overcome delusion, moha (A. I, 200). It is notable that just yoniso manasikära itself is the chief factor responsible for avoiding delusion, which further reinforces the importance of its role as a "wise" form of attention that leads to liberating insight.

  

A practical example of how one should deal with unwholesome mental qualities through yoniso manasikāra can be found in a discourse that describes a monk whose mind is full of thoughts related to sensuality, ill-will and harming. A deva, who has become aware of the monk's condition, admonishes him (S. 1. 203). The deva tells the monk that his condition is due to ayoniso manasik ära and advises him that he should give up such unwise forms of thinking, ayoniso paținissajja. Instead, he should direct his thoughts in a more appropriate manner, yoniso anucintaya. This he could do by recollecting his teacher, the teaching, the community, or his own virtue. Directing his thoughts in such a yoniso manner, joy will arise and lead him onwards on the path to liberation from dukkha.

  

A whole range of practical examples for yoniso manasikāra can be found in the Sabbāsava Sutta, whose exposition presents a series of activities that lead to overcoming the influxes. According to the introductory statement in this discourse, the destruction of the influxes requires knowing and seeing, and such knowing and seeing comes about through yoniso manasikära. (M. 1, 7). Thus yoniso manasikira serves as a heading for all the methods listed in the Sabbâsava Sutta.

  

Of the altogether seven methods for overcoming the influxes listed in the Sabbasava Sutta, the first requires developing a vision of the four noble truth. Such vision stands in contrast to unwisely attending, ayoniso manasikära, to meaningless questions of the type "am I at present?" etc. (M. 1, 8). The other six methods involve "reflecting wisely", patisankha yoniso, in order to establish sense-restraint; properly use one's requisites, patiently endure vicissitudes of climate etc.; avoid dangerous situations such as encountering wild animals etc.; remove unwholesome thoughts from the mind, and develop the factors of awakening. The range of activities assembled here reflects the compass of yoniso manasikūra, which covers proper use of requisites just as much as developing the mental qualities required to experience awakening. Whether one is wisely reflecting that food should not be taken for amusement, but only in order to maintain the body, or whether the factors of awakening are developed in such a manner that the mind inclines towards cessation and letting go - all such activities fall under the heading of yoniso manasikāra, developed for the sake of removing the Influxes.

  

The presentation given in the Sabbâsava Sutta shows that yoniso manasikära can take place at a reflective conceptual level of the mind as well as during deep meditation. Several discourses show how a more reflective type of yoniso manasikära can serve as a transition from hearing teachings to engaging in actual practice. Yet, yoniso manasikära is also part of the practice itself, since it includes the wise form of attention that is present during deeper stages of insight Contemplation.

  

### The importance of yoniso manasikära

  

The importance of yoniso manasik ära for progress on the path to liberation can be gauged from its appearance in several listings of the factors that are required for reaching stream-entry. A rather brief listing speaks of two main factors for arousing right view: the voice of another and yoniso manasik ära (M. 1, 294 or A. 1, 87). Elsewhere in the discourses, the same theme is treated in more detail by listing altogether four factors of stream-entry. These comprise association with superior human beings and listening to the proper teachings, followed by yoniso manasikära and practice undertaken according to these teachings (e.g. D. III, 227). The listing clearly follows a temporal sequence, delineating the main steps that lead up to the attainment of stream-entry. The obvious and most basic requirement is to come in contact with a superior human being who transmits the type of proper teachings that, on being put into practice, lead to liberation. Another basic requirement is to be willing to listen to such teachings. Given that much, one needs to listen to the teachings without being mentally distracted, avikhittacitto dhammam sunāti, in order to be able to develop single-minded yoniso manasikära on such an occasion (A. III, 175).

  

Additional detail on this series of steps leading up to stream-entry can be gathered from some discourses, which depict a progression from listening to the proper teachings via the establishment of "faith" or "confidence", saddha, to yoniso manasikara(e.g. A. V, 115). The inner confidence or faith gained from listening to the proper teachings thus serves as a "nutriment" for yoniso manasikära, since the inspiration developed in such way quite literally nourishes the development and maintainence of wise and thorough attention (A. V, 115). To be able to rouse such inspiration requires overcoming three adverse conditions: forgetfulness, thoughtlessness, and confusion (A. V, 145).

  

Once that much has been achieved, yoniso manasikára plays its crucial role in bridging the transition from passive reception of the teachings to their active application. In this way, yoniso manasikära can become the basis for overcoming sensuality and other unwholesome qualities, for tranquillizing any gross type of activity by way of body, speech and mind; and for developing insight into what is wholesome and what is unwholesome (D. II, 214).

  

The directional input provided by yoniso manasikūra for undertaking practice is comparable to the early morning dawn. Just as the early morning dawn is the harbinger of the rising of the sun, so yoniso manasikāra is the harbinger of the noble eightfold path (S. V, 31) and of the seven factors of awakening (S. V, 79). Yoniso manasikära is of such importance in relation to these two sets, that some discourses declare no other mental quality to be more helpful for arousing the noble eightfold path (S. V, 35), or for developing the awakening factors (S. V, 101).

  

In short, all wholesome qualities have their root in yoniso manasikāra (S. V, 91), and the proper directional input given by yoniso manasikāra is the decisive factor for undertaking wholesome deeds (A. V, 87). Thus yoniso manasikära is the factor par excellence for arousing wholesome qualities and for overcoming unwholesome qualities (A. I, 13), thereby leading to great benefit and ensuring the endurance of the teachings (A. I, 18). Besides, the development of yoniso manasikāra also constitutes a source of delight, joy and happiness, yonisomanasikaroto pamojjam jāyati, pamuditassa piti jāyati, pâtimanassa... sukham vedeti (D. III, 288).

  

As a form of actual practice, yoniso manasikāra is of continuous relevance all the way from the first steps of practice to final liberation, a progressive development during which what initially was a form of reflection on teachings one has heard grows into a silent attention directed to the true nature of reality during deeper stages of meditation. As a form of attention present during deeper stages of insight, yoniso manasikära directed to the impermanent, unsatisfactory and selfless nature of the five aggregates of clinging is a form of meditation practice that is relevant to the stage of a worldling as well as to an arahant (S III, 167). That is, independent of what level of liberation someone may have already reached, yoniso manasikāra developed in this way constitutes the path to the next higher stage. For those who have completed the path, the fully awakened ones, yoniso manasikära is still of continuous relevance, since it provides a pleasant abiding in the present moment and because it engenders mindfulness and clear Comprehension.

  

The importance of yoniso manasikära as a form of attention that leads to various stages of awakening is also reflected in the Theragatha, where verses related to the attainment of liberation repeatedly indicate how on that occasion yoniso manasikāra arouse in the mind, tato me manas ikãoyoniso udapаjjatha. In such contexts, the task of yoniso manasikūra is to reveal the true nature of experience and thereby cause the arising of utter disenchantment. Examples are the verses of Nagasamala, who attained liberation when directing yoniso manasikära to the vision of a dancing girl giving a performance (Thag. 269); Sundarasamudda, who faced temptation by a courtesan with yoniso manasikara (Thag. 464); Candana, who maintained yoniso manasikara when encountering his former wife (Thag. 301); Rajadatta, who kept to yoniso manasikära when contemplating a corpse (Thag. 318); Bhagu, who was full of yoniso manasikāra after struggling to overcome torpor (Thag. 273); and Sappadāsa, who was saved from committing suicide by yoniso manasikāra (Thag. 409).

  

In the majority of these cases, yoniso manasik ära appears to be directed to the absence of beauty in particular, asubha, whereby not only the hindrance of sensual desire can be overcome, but even, as these instances show, the goal of final liberation can be won. But struggle with sensuality is clearly not the only occasion when yoniso manasikāra can unfold its awakening potential, as the above examples show that it can also serve its purpose when having to confront torpor or being under the influence of suicidal Intentions.

  

In sum, then, yoniso manasikāra as a "wise" and at the same time "thorough" and "appropriate" type of attention has a remarkably broad scope within the context of early Buddhist mental training, ranging from attention given to the proper attitude towards food and similar requisites, or from attending single- mindedly to the oral delivery of teachings, all the way up to the penetrative type of attention that heralds the breakthrough to awakening. Given its range of applicability, yoniso manasikära thus stands out as one of the key aspects of the early Buddhist path to liberation, a quality whose gradual development offers a substantial contribution to various aspects of the path to deliverance.

  

In sum: 

"Wise attention - this is one factor that conduces to distinction. 

Unwise attention- this is one factor that conduces to ruin". 

  

Yoniso manasikaro - ayam eko dhammo visesabhagiyo. 

Ayoniso manasikaro - ayam eko dhammo hānabhägiyo (D. III, 273).

  

Anālayo

References

  

1 Cf. also Il. 30, which indicates that to be stirred and to thoroughly endeavour are two conditions that are a source of abundant happiness here and now, and that lead to the destruction of the influxes. According to Dhs. 234, these two - samvigga and yoniso padhana - stand for the four aspects of right effort (i.e, preventing the arising of unwholesome states, removing arisen unwholesome states, arousing unarisen wholesome states, and strengthening arisen wholesome states). 

  

2 The Abhidhammantha Sangaha 2.2 expresses the by reckoning manasikara a sabbacittas adhārana, a mental factor that is common to any state of mind. 

  

3 Cf. also DA. II, 643, which glosses yoniso manasikāra as upayamanasikara. 

  

4 The idea of attending to something in a penetrative manner, down to its very origins, can also be seen in a literal manner when Mahāmoggallāna directs yoniso manasikära to his own body in order to find out what is afflicting his bowels (M. 1, 332). same

  
**