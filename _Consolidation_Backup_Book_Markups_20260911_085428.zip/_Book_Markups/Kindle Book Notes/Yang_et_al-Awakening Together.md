---
kindle-sync:
  bookId: '21637'
  title: 'Awakening Together: The Spiritual Practice of Inclusivity and Community'
  author: 'Larry Yang, Jan Willis, and Sylvia Boorstein'
  asin: B071Z6SQPL
  lastAnnotatedDate: '2022-03-23'
  bookImageUrl: 'https://m.media-amazon.com/images/I/81DZu7piJ+L._SY160.jpg'
  highlightsCount: 96
---
# Awakening Together
## Metadata
* Author: [Larry Yang, Jan Willis, and Sylvia Boorstein](https://www.amazon.com/Larry-Yang/e/B078C6CK5Q/ref=dp_byline_cont_ebooks_1)
* ASIN: B071Z6SQPL
* Reference: https://www.amazon.com/dp/B071Z6SQPL
* [Kindle link](kindle://book?action=open&asin=B071Z6SQPL)

## Highlights
It is precisely our refuge in the Buddha — the idea that all of us are worthy of awakening and can attain it — that justifies and requires that there be culturally specific teaching and practice venues to skillfully meet the differing cultural needs of diverse communities. — location: [1132](kindle://book?action=open&asin=B071Z6SQPL&location=1132) ^ref-15147

---
practicing mindfulness with respect to our own unconsciousness that we begin to wake up! — location: [1154](kindle://book?action=open&asin=B071Z6SQPL&location=1154) ^ref-3169

---
We find what lies beyond the layers of our experience by probing deeply into them, not by ignoring them. — location: [1159](kindle://book?action=open&asin=B071Z6SQPL&location=1159) ^ref-45873

---
Communal culture is one of the doors through which the Buddha’s teachings are being transmitted into the diverse communities of the West. — location: [1248](kindle://book?action=open&asin=B071Z6SQPL&location=1248) ^ref-59133

---
Oneness is valuable, but variety is also wonderful. — location: [1275](kindle://book?action=open&asin=B071Z6SQPL&location=1275) ^ref-47136

---
We need a larger perspective that can recognize and include two different tracks of human development — which we might call growing up and waking up, healing and awakening, or becoming a genuine human person and going beyond the person altogether. We are not just humans learning to become buddhas, but also buddhas waking up in human form, learning to become fully human. And these two tracks of development can mutually enrich each other. — location: [1279](kindle://book?action=open&asin=B071Z6SQPL&location=1279) ^ref-47903

---
feeling of safety and being acknowledged within the teachings. — location: [1290](kindle://book?action=open&asin=B071Z6SQPL&location=1290) ^ref-63018

---
It is interesting to reflect on why European Americans returning from Asia did not practice and teach in the Asian Buddhist temples and communities already established here. — location: [1297](kindle://book?action=open&asin=B071Z6SQPL&location=1297) ^ref-36282

---
I do not want to overgeneralize, but I suspect that it was at least partially because European Americans did not see themselves reflected in Asian American spiritual centers and communities. The way the teachings were expressed in Asian American centers likely did not reflect the worlds of life within the dominant mainstream cultures. — location: [1300](kindle://book?action=open&asin=B071Z6SQPL&location=1300) ^ref-36494

---
So European American practitioners created communities focused upon European American experiences. — location: [1305](kindle://book?action=open&asin=B071Z6SQPL&location=1305) ^ref-55046

---
We are all human. We all want to feel safe, to feel we belong, especially in the vulnerabilities at the beginning of our spiritual paths. In the service of this, it is helpful to see ourselves reflected in the teachings, reflected in the teachers who share them, and reflected in the spiritual community surrounding us. — location: [1313](kindle://book?action=open&asin=B071Z6SQPL&location=1313) ^ref-45197

---
Spiritual explorations require intimacy and tenderness, and it is very hard to relax into what is an open, vulnerable state when our defenses already have to be in place to protect from the injuries and traumas caused by unconsciousness and patterns embedded in the dominant culture. — location: [1316](kindle://book?action=open&asin=B071Z6SQPL&location=1316) ^ref-62114

---
we call on spiritual practice specifically to create the skillful means that will enable us to extinguish such harms. — location: [1326](kindle://book?action=open&asin=B071Z6SQPL&location=1326) ^ref-57041

---
Even though a mainstream sangha may have the intention of being totally inclusive, unless dedicated and inspired attention is paid to culture and diversity within the group, the outcome will likely fall short of the intent. — location: [1333](kindle://book?action=open&asin=B071Z6SQPL&location=1333) ^ref-38201

---
Beloved Communities — location: [1339](kindle://book?action=open&asin=B071Z6SQPL&location=1339) ^ref-48053

---
When we create practice opportunities so that both culturally specific populations and the larger community can gather in cultural mindfulness and awareness of our shared humanity, we are invited to move from the question “Who am I?” to a broader exploration of “Who are we?” What kind of path is possible leading to collective liberation? — location: [1356](kindle://book?action=open&asin=B071Z6SQPL&location=1356) ^ref-36590

---
diversity of tactics — location: [1427](kindle://book?action=open&asin=B071Z6SQPL&location=1427) ^ref-3306

---
So how do we meet even struggles for justice and equity with a heart that is both tenderly open and deeply wise? What is truly beneficial in the face of oppression and inequity? As mentioned above, in the Dhammapada the Buddha teaches “Hate never yet dispelled hate.” — location: [1434](kindle://book?action=open&asin=B071Z6SQPL&location=1434) ^ref-44045

---
the creation of justice and the diminishment of injustice must and indeed can only happen through just means. We cannot create justice through unjust means. Justice created through unjust means is not justice, nor is it freedom. — location: [1437](kindle://book?action=open&asin=B071Z6SQPL&location=1437) ^ref-37855

---
A reactive heart and mind may want to meet the forces of injustice with force, but our spiritual practice challenges us to determine whether the force we marhsal emerges from the power of love and wisdom or from a strong aversion to obliterate pain. — location: [1441](kindle://book?action=open&asin=B071Z6SQPL&location=1441) ^ref-52725

---
Returning violence for violence multiplies violence, adding deeper darkness to a night already devoid of stars. Darkness cannot drive out darkness; only light can do that. Hate cannot drive out hate; only love can do that. — location: [1445](kindle://book?action=open&asin=B071Z6SQPL&location=1445) ^ref-50911

---
“For to be free is not merely to cast off one’s chains, but to live in a way that respects and enhances the freedom of others.” — location: [1449](kindle://book?action=open&asin=B071Z6SQPL&location=1449) ^ref-46700

---
paused — a nonverbal way of expressing softness and tenderness — location: [1452](kindle://book?action=open&asin=B071Z6SQPL&location=1452) ^ref-15658

---
“Well, war is obsolete, you know.” He paused again briefly, and then added, “Of course, the mind can rationalize fighting back. But the heart, the heart would never understand. Then you would be divided in yourself, the heart and the mind, and the war would be inside you.” — location: [1453](kindle://book?action=open&asin=B071Z6SQPL&location=1453) ^ref-15450

---
Practicing [the foundations of mindfulness] means building peaceful little worlds within each of those who practice. Without peace in our little worlds, crying out for peace in the Big World with clenched fists and raised arms is something to think about. — location: [1460](kindle://book?action=open&asin=B071Z6SQPL&location=1460) ^ref-11761

---
Kingian Nonviolence Conflict Reconciliation — location: [1463](kindle://book?action=open&asin=B071Z6SQPL&location=1463) ^ref-26135

---
There is a famous story about a meeting between a warlord general and a Buddhist monk. The warlord was conquering the countryside and violently taking over the lives and property of all its inhabitants. When he came upon the temple of a renowned meditation master, he intended to ransack it and destroy all of its resident monastics. As the warlord entered the meditation hall, he beheld the temple’s meditation master, sitting perfectly still in its center, calm, composed, and with complete poise as if nothing were happening around him. Charging up to the sitting monk, the warlord roared, “Do you realize that I am the kind of person who can run my sword through you without batting an eye?” And without missing a beat or even the length of a breath, the meditation master replied, “And do you realize that I am the kind of person who can sit here while you run your sword through me, without batting an eye?” — location: [1468](kindle://book?action=open&asin=B071Z6SQPL&location=1468) ^ref-16236

---
There is an intentional relationship between personal spiritual practice and how we live together in community in the world. — location: [1479](kindle://book?action=open&asin=B071Z6SQPL&location=1479) ^ref-35831

---
By emphasizing the refuge of Sangha, the Buddha was connecting personal practice of mindfulness to a collective form of awareness. I believe he was interested in transforming our collective experience into a higher order of consciousness not bound by individual experience but inclusive of the diverse experiences of all of us. — location: [1487](kindle://book?action=open&asin=B071Z6SQPL&location=1487) ^ref-36137

---
As practice expands from the personal to the collective, from the internal to the external, from the particular to the universal, it comes to embody the value of inclusion of all things, of all people, of all differences. All of our experiences are invited and belong; none of us is marginalized or excluded. In this way, we are being invited to create beautiful and Beloved Communities. — location: [1489](kindle://book?action=open&asin=B071Z6SQPL&location=1489) ^ref-58453

---
From the perspective of Dharma, beautiful doesn’t refer to an aesthetic quality but rather to the qualities of mind and heart that lead to happiness and freedom — the end of suffering. — location: [1492](kindle://book?action=open&asin=B071Z6SQPL&location=1492) ^ref-37843

---
Because it is not an aesthetic characteristic, beauty is not necessarily pleasant to experience or easy to create. Like the rest of our spiritual practice, it requires effort, concentration, integrity, discernment, intention, and mindfulness. In actuality, beauty requires the panoply of teachings that create freedom of the mind and heart. It is the complexity of life that challenges each of us every day to accept the ten thousand joys and the ten thousand sorrows to be nothing less than beautiful. — location: [1496](kindle://book?action=open&asin=B071Z6SQPL&location=1496) ^ref-52155

---
beautiful — location: [1503](kindle://book?action=open&asin=B071Z6SQPL&location=1503) ^ref-33220

---
beloved — location: [1503](kindle://book?action=open&asin=B071Z6SQPL&location=1503) ^ref-32739

---
felt totally inadequate. — location: [1543](kindle://book?action=open&asin=B071Z6SQPL&location=1543) ^ref-21836

---
In my current teaching, I endeavor to meet practitioners however they self-identify, not denying any aspect of their backgrounds or cultural experiences. — location: [1571](kindle://book?action=open&asin=B071Z6SQPL&location=1571) ^ref-51348

---
Especially in one’s entry into the Dharma, invoking the complex teaching of not identifying with one’s self can be experienced as a spiritual bypass of a practitioner’s reality in the world’s external conditions. — location: [1572](kindle://book?action=open&asin=B071Z6SQPL&location=1572) ^ref-52184

---
Naming how I have been caught in the complex feelings of identity and intersections of multiple identities can invite connection and relationship with the practitioner’s own experience. — location: [1575](kindle://book?action=open&asin=B071Z6SQPL&location=1575) ^ref-51101

---
a process of purification. — location: [1578](kindle://book?action=open&asin=B071Z6SQPL&location=1578) ^ref-30169

---
Like everyone, I wanted to hear the teachings and cultivate the wisdom that would allow me to be happier in life and to reduce suffering. What was most important to me was how the practices of mindfulness and meditation were relevant to what I was actually going through every day. And of course I would imagine this to be true for most practitioners, regardless of the circumstances of their background, families of origin, or difficulties that they have experienced. — location: [1602](kindle://book?action=open&asin=B071Z6SQPL&location=1602) ^ref-59338

---
learned at this retreat how we, with our inevitable human frailties, can be aware and simultaneously unaware of how we apply our practice to the actual life experiences that arise in front of us. — location: [2037](kindle://book?action=open&asin=B071Z6SQPL&location=2037) ^ref-38117

---
Mindfulness practice is never only about our own personal experience. — location: [2057](kindle://book?action=open&asin=B071Z6SQPL&location=2057) ^ref-32618

---
While we continue to be aware of our thoughts, emotions, and intentions, we do not just stop at the boundaries of our own bodies, minds, or hearts. — location: [2057](kindle://book?action=open&asin=B071Z6SQPL&location=2057) ^ref-24422

---
sound of the breath of the person next to me that reminded me to return to the sensations of present moment — location: [2059](kindle://book?action=open&asin=B071Z6SQPL&location=2059) ^ref-21660

---
Buddha is inviting us to be aware of more than just ourselves; he is inviting us to be aware of our communities, our culture, and our world, and finally to be aware of the relationship between all of ourselves in the totality of our experience together. — location: [2080](kindle://book?action=open&asin=B071Z6SQPL&location=2080) ^ref-12505

---
mindfulness moves in the direction of external input and takes external events or people as object of attention. — location: [2087](kindle://book?action=open&asin=B071Z6SQPL&location=2087) ^ref-6954

---
Diagrammed, this would represent awareness going in both directions, including both experiences of internal and external: — location: [2090](kindle://book?action=open&asin=B071Z6SQPL&location=2090) ^ref-4039

---
avoiding the ego-oriented extreme of focusing only on our own internal experience and the codependent extreme of attending solely to the needs of someone or something else. — location: [2093](kindle://book?action=open&asin=B071Z6SQPL&location=2093) ^ref-23157

---
balance between the extremes — location: [2094](kindle://book?action=open&asin=B071Z6SQPL&location=2094) ^ref-2760

---
awareness that notices both internal and external impacts — location: [2095](kindle://book?action=open&asin=B071Z6SQPL&location=2095) ^ref-42997

---
combining our insight with our empathy. — location: [2096](kindle://book?action=open&asin=B071Z6SQPL&location=2096) ^ref-61672

---
“exchanging self for other” — location: [2097](kindle://book?action=open&asin=B071Z6SQPL&location=2097) ^ref-29081

---
How would you feel if you were sitting in the other person’s life? — location: [2098](kindle://book?action=open&asin=B071Z6SQPL&location=2098) ^ref-7179

---
“Put yourself in the other person’s shoes. How would you feel if this happened to you?” — location: [2100](kindle://book?action=open&asin=B071Z6SQPL&location=2100) ^ref-63776

---
If we focus solely on inner awareness, we can become preoccupied with our own experience at the expense of our awareness of the experience of others and how our own actions impact them. — location: [2102](kindle://book?action=open&asin=B071Z6SQPL&location=2102) ^ref-3407

---
This is the dance between being fully present to our inner world and what is happening in the outer world. This is a relational experience created by being mindful internally and externally, from within to without. We use this relational experience to begin to feel, understand, and live the teachings that we are all interconnected and interrelated. — location: [2118](kindle://book?action=open&asin=B071Z6SQPL&location=2118) ^ref-29060

---
How often are we not aware of our impact on others? — location: [2124](kindle://book?action=open&asin=B071Z6SQPL&location=2124) ^ref-30859

---
Unless we are careful to balance this aspect of mindfulness between individual experience (either as an individual person or as an individual community) and collective experience as people and multiple communities, we may tend to assume that our reality is the reality of others. — location: [2130](kindle://book?action=open&asin=B071Z6SQPL&location=2130) ^ref-43004

---
The internal focus of mindfulness can be represented visually as a series of learning events: individual awareness of personal intentions and actions transforms unconscious actions into conscious personal responses in our lives, which leads us to be progressively mindful of how our actions impact our experience, which increases our awareness to allow us to find increased opportunities for new learning, which feeds back into our personal practice of mindfulness, further recalibrating our awareness and — location: [2136](kindle://book?action=open&asin=B071Z6SQPL&location=2136) ^ref-41996

---
allowing for even more skillful intentions. — location: [2140](kindle://book?action=open&asin=B071Z6SQPL&location=2140) ^ref-48276

---
communal awareness of collective intentions transforms unconscious reactions into conscious collective actions within our communities, which leads us to develop mindfulness of how our actions impact all of our experiences, which allows our awareness and new learning to increase, which feeds back into our collective practice of mindfulness and increasing the effectiveness and benefit of our communal intentions. — location: [2142](kindle://book?action=open&asin=B071Z6SQPL&location=2142) ^ref-26785

---
The practice of community mindfulness is the same as individual mindfulness but with its focus expanded from the individual to the refuge and practice of sangha and community. These interwoven practices that cycle over and over again, from left to right and right to left in the diagram, internally and externally, deepen the experiential manifestation of a shared sense of mindfulness — and as that happens, we meet the entirety of our individual lives and all of our collective lives as they are with kindness and understanding. This is the experience of collective love and being able to collectively love each other. When we are meeting each other’s communities and loved ones with tender understanding — as opposed to judging assumptions or detached indifference — we are loving each other already within the vision of the beautiful and Beloved Community. — location: [2146](kindle://book?action=open&asin=B071Z6SQPL&location=2146) ^ref-1841

---
It is a crazy-making situation when teachers who espouse awareness are seemingly unaware. — location: [2180](kindle://book?action=open&asin=B071Z6SQPL&location=2180) ^ref-61354

---
I often wonder whether I might be the one who was crazy and not the situation: was I delusional to feel how I was feeling? — location: [2180](kindle://book?action=open&asin=B071Z6SQPL&location=2180) ^ref-7458

---
I did not feel safe enough (even among Dharma teachers!) to comment to the larger group about the experience. — location: [2183](kindle://book?action=open&asin=B071Z6SQPL&location=2183) ^ref-40535

---
The ensuing discussions included the feelings of white teachers who really did not want to move through life “walking on eggshells.” — location: [2186](kindle://book?action=open&asin=B071Z6SQPL&location=2186) ^ref-31937

---
as so very precious and worthy of respect and caring that it deserves as much care as eggshells? — location: [2188](kindle://book?action=open&asin=B071Z6SQPL&location=2188) ^ref-41559

---
Being mindful means moving with delicacy around everyone’s experience. That is the loving nature of awareness. — location: [2189](kindle://book?action=open&asin=B071Z6SQPL&location=2189) ^ref-10767

---
The group didn’t pay attention to some of its members’ experience. — location: [2193](kindle://book?action=open&asin=B071Z6SQPL&location=2193) ^ref-9967

---
marginalization. — location: [2194](kindle://book?action=open&asin=B071Z6SQPL&location=2194) ^ref-36221

---
unconscious group dynamics in the twenty-first century still usually allow men in the room to speak longer, more often, and with greater perceived credibility than women or other genders. — location: [2198](kindle://book?action=open&asin=B071Z6SQPL&location=2198) ^ref-52292

---
People of the dominant mainstream culture still tend to overpower people of other cultures and take up space, time, resources, and energy. — location: [2199](kindle://book?action=open&asin=B071Z6SQPL&location=2199) ^ref-39505

---
We rarely consider people with different or restricted ranges of physical ability in how we move through the world; — location: [2202](kindle://book?action=open&asin=B071Z6SQPL&location=2202) ^ref-47676

---
“walking” meditation instructions that are truly accessible to those who have difficulty walking or moving in the world? — location: [2203](kindle://book?action=open&asin=B071Z6SQPL&location=2203) ^ref-24540

---
The more we become aware of each other, as individuals and as groups, the more we begin to sense, feel, and live the reality that we are all interconnected despite any differences between us. — location: [2206](kindle://book?action=open&asin=B071Z6SQPL&location=2206) ^ref-44822

---
Our needs are not solely an individual matter, even though we might feel them personally. It is the practice of sangha to naturally take care of others with grace and ease — to share our joys and sorrows together in communion with the full range of our collective experience. Likewise, while the needs of each community might seem different and specific to that particular community, the Dharma is about being aware of the needs of all communities, not just our own. — location: [2208](kindle://book?action=open&asin=B071Z6SQPL&location=2208) ^ref-37866

---
“It requires a shift in consciousness from all of us.” — location: [2217](kindle://book?action=open&asin=B071Z6SQPL&location=2217) ^ref-14398

---
Again, the deep exploration of practice through different identity groups is not the end of the path, the final goal — but for many practitioners the experience of identity can be a threshold, an invitation to walk through a doorway or gate into practice. — location: [2830](kindle://book?action=open&asin=B071Z6SQPL&location=2830) ^ref-3940

---
And the continuing invitation is not to be attached to the “door” of identity. — location: [2832](kindle://book?action=open&asin=B071Z6SQPL&location=2832) ^ref-64014

---
As we explore what is beyond the door of identity using our spiritual practice, we begin to directly enter a landscape of experience that is expansive and not dependent upon how we identify in our lives. — location: [2832](kindle://book?action=open&asin=B071Z6SQPL&location=2832) ^ref-15899

---
actions and behaviors that actualize the intentions of multiculturalism. — location: [2838](kindle://book?action=open&asin=B071Z6SQPL&location=2838) ^ref-45540

---
multicultural — location: [2840](kindle://book?action=open&asin=B071Z6SQPL&location=2840) ^ref-30876

---
awareness, — location: [2840](kindle://book?action=open&asin=B071Z6SQPL&location=2840) ^ref-47352

---
multicultural — location: [2840](kindle://book?action=open&asin=B071Z6SQPL&location=2840) ^ref-30876

---
mindfulness, — location: [2840](kindle://book?action=open&asin=B071Z6SQPL&location=2840) ^ref-40920

---
understanding the dynamics and impact of current and previous patterns of oppression; — location: [2846](kindle://book?action=open&asin=B071Z6SQPL&location=2846) ^ref-38043

---
understanding and changing current practices that are discriminatory; — location: [2847](kindle://book?action=open&asin=B071Z6SQPL&location=2847) ^ref-26552

---
initiating restorative rebuilding of trust and relationships due to previous injury or harm caused; — location: [2847](kindle://book?action=open&asin=B071Z6SQPL&location=2847) ^ref-35354

---
dealing with resistance and denial of the importance and reality of diversity and culture; — location: [2848](kindle://book?action=open&asin=B071Z6SQPL&location=2848) ^ref-55489

---
dismantling systems in place that keep white hetero-normative values and assumptions in control; — location: [2849](kindle://book?action=open&asin=B071Z6SQPL&location=2849) ^ref-13006

---
progressively revealing layers of unexamined privilege and entitlements of members of the dominant culture; — location: [2849](kindle://book?action=open&asin=B071Z6SQPL&location=2849) ^ref-2620

---
recalibrating power and authority that are not accountable and often hidden, which can reinforce unconscious privilege; — location: [2850](kindle://book?action=open&asin=B071Z6SQPL&location=2850) ^ref-5132

---
developing tangible strategies of inclusivity across all levels of leadership and participation (including teachers and governance); — location: [2851](kindle://book?action=open&asin=B071Z6SQPL&location=2851) ^ref-49722

---
transforming attitudes and behaviors to recalibrate, value, and incorporate different cultural experiences in living together as a community. — location: [2852](kindle://book?action=open&asin=B071Z6SQPL&location=2852) ^ref-25011

---
balance the demographic numbers of our diverse communities in the meditation hall for any one event. — location: [2860](kindle://book?action=open&asin=B071Z6SQPL&location=2860) ^ref-9053

---
more income and more visibility, — location: [2866](kindle://book?action=open&asin=B071Z6SQPL&location=2866) ^ref-32788

---
