A human being is a part of the whole, called by us, “Universe,” a part limited in time and space. He experiences himself, his thoughts and feelings as something separated from the rest—a kind of optical delusion of his consciousness. This delusion is a kind of prison for us, restricting us to our personal desires and to affection for a few persons nearest to us. Our task must be to free ourselves from this prison by widening our circle of compassion to embrace all living creatures and the whole of nature in its beauty. Nobody is able to achieve this completely, but the striving for such achievement is in itself a part of the liberation and a foundation for inner security. (New York Times, March 29, 1950, p. 1)

#delusion
#separateness
