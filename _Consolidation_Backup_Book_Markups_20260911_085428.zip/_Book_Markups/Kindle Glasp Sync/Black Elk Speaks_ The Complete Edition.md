# Black Elk Speaks: The Complete Edition

![](https://m.media-amazon.com/images/I/91Uyml8DgDL.jpg)

### Metadata

- Title: Black Elk Speaks: The Complete Edition
- Author: Your Kindle Notes For:
- Book URL: https://www.amazon.com/dp/B00INIXBP2
- Open in Kindle: [kindle://book/?action=open&asin=B00INIXBP2](kindle://book/?action=open&asin=B00INIXBP2)
- Last Updated on: 

### Highlights & Notes

> It is the story of all life that is holy and is good to tell, and of us two-leggeds sharing in it with the four-leggeds and the wings of the air and all green things; for these are children of one mother and their father is one Spirit.

> There is a story about the way the pipe first came to us. A very long time ago, they say, two scouts were out looking for bison; and when they came to the top of a high hill and looked north, they saw something coming a long way off, and when it came closer they cried out, &ldquo;It is a woman!,&rdquo; and it was. Then one of the scouts, being foolish, had bad thoughts and spoke them; but the other said: &ldquo;This is a sacred woman; throw all bad thoughts away.&rdquo; When she came still closer, they saw that she wore a fine white buckskin dress, that her hair was very long and that she was young and very beautiful. And she knew their thoughts and said in a voice that was like singing: &ldquo;You do not know me, but if you want to do as you think, you may come.&rdquo; And the foolish one went; but just as he stood before her, there was a white cloud that came and covered them. And the beautiful young woman came out of the cloud, and when it blew away the foolish man was a skeleton covered with worms. Then the woman spoke to the one who was not foolish: &ldquo;You shall go home and tell your people that I am coming and that a big tepee shall be built for me in the center of the nation.&rdquo; And the man, who was very much afraid, went quickly and told the people, who did at once as they were told; and there around the big tepee they waited for the sacred woman. And after a while she came, very beautiful and singing, and as she went into the tepee this is what she sang: &ldquo;With visible breath I am walking. A voice I am sending as I walk. In a sacred manner I am walking. With visible tracks I am walking. In a sacred manner I walk.&rdquo; And as she sang, there came from her mouth a white cloud that was good to smell. Then she gave something to the chief, and it was a pipe with a bison calf carved on one side to mean the earth that bears and feeds us, and with twelve eagle feathers hanging from the stem to mean the sky and the twelve moons, and these were tied with a grass that never breaks. &ldquo;Behold!&rdquo; she said. &ldquo;With this you shall multiply and be a good nation. Nothing but good shall come from it. Only the hands of the good shall take care of it and the bad shall not even see it.&rdquo; Then she sang again and went out of the tepee; and as the people watched her going, suddenly it was a white bison galloping away and snorting, and soon it was gone.5

> Hetchetu aloh!

> daybreak star 14 was rising,

> I saw that the sacred hoop of my people was one of many hoops that made one circle, wide as daylight and as starlight, and in the center grew one mighty flowering tree to shelter all the children of one mother and one father. And I saw that it was holy.23

> Also, as I lay there thinking of my vision, I could see it all again and feel the meaning with a part of me like a strange power glowing in my body; but when the part of me that talks would try to make words for the meaning, it would be like fog and get away from me.

> Then the head man of the advisers went around picking out the best hunters with the fastest horses, and to these he said: &ldquo;Good young warriors, my relatives, your work I know is good. What you do is good always; so to-day you shall feed the helpless. Perhaps there are some old and feeble people without sons, or some who have little children and no man. You shall help these, and whatever you kill shall be theirs.&rdquo; This was a great honor for young men.

> Crows

> Shoshones

> &ldquo;Take courage, boy! The earth is all that lasts!&rdquo;

> we remembered and they forgot.11

> only crazy or very foolish men would sell their Mother Earth.

> How could men get fat by being bad, and starve by being good?

> &ldquo;My Father is with me, and there is no Great Father between me and the Great Spirit.&rdquo;4

> Little Big Man,

> It does not matter where his body lies, for it is grass; but where his spirit is, it will be good to be.6

> it seemed that everything was listening hard to hear something.

> &ldquo;Behold! A sacred voice is calling you! All over the sky a sacred voice is calling!&rdquo;

> I wish and wish my vision could have been given to a man more worthy. I

> lament9

> First he told me to fast four days, and I could have only water during that time. Then, after he had offered the pipe, I had to purify myself in a sweat lodge, which we made with willow boughs set in the ground and bent down to make a round top. Over this we tied a bison robe. In the middle we put hot stones, and when I was in there, Few Tails poured water on the stones. I sang to the spirits while I was in there being purified. Then the old man rubbed me all over with the sacred sage. He then braided my hair,10 and I was naked except that I had a bison robe to wrap around me while lamenting in the night, for although the days were warm, the nights were cold yet. All I carried was the sacred pipe. It is necessary to go far away from people to lament, so Few Tails and I started from Pine Ridge toward where we are now.52f We came to a high hill close to Grass Creek, which is just a little way west from here. There was nobody there but the old man and myself and the sky and the earth. But the place was full of people; for the spirits were there. The sun was almost setting when we came to the hill, and the old man helped me make the place where I was to stand. We went to the highest point of the hill and made the ground there sacred by spreading sage upon it. Then Few Tails set a flowering stick in the middle of the place, and on the west, the north, the east, and the south sides of it he placed offerings of red willow bark tied into little bundles with scarlet cloth. Few Tails now told me what I was to do so that the spirits would hear me and make clear my next duty. I was to stand in the middle, crying and praying for understanding. Then I was to advance from the center to the quarter of the west and mourn there awhile. Then I was to back up to the center, and from there approach the quarter of the north, wailing and praying there, and so on all around the circle. This I had to do all night long.

> O Great Spirit, accept my offerings! O make me understand!&rdquo;

> You have noticed that the truth comes into this world with two faces.2 One is sad with suffering, and the other laughs; but it is the same face, laughing or weeping.

> It is a bad way to live, for there can be no power in a square.

> You have noticed that everything an Indian does is in a circle, and that is because the Power of the World always works in circles, and everything tries to be round.

> In the old days when we were a strong and happy people, all our power came to us from the sacred hoop of the nation, and so long as the hoop was unbroken, the people flourished.

> The flowering tree was the living center of the hoop, and the circle of the four quarters nourished it. The east gave peace and light, the south gave warmth, the west gave rain, and the north with its cold and mighty wind gave strength and endurance.

> The sky is round, and I have heard that the earth is round like a ball, and so are all the stars. The wind, in its greatest power, whirls. Birds make their nests in circles, for theirs is the same religion as ours. The sun comes forth and goes down again in a circle. The moon does the same, and both are round.1 Even the seasons form a great circle in their changing, and always come back again to where they were. The life of a man is a circle from childhood to childhood, and so it is in everything where power moves. Our tepees were round like the nests of birds, and these were always set in a circle, the nation&rsquo;s hoop, a nest of many nests, where the Great Spirit meant for us to hatch our children.

> Well, it is as it is. We are prisoners of war while we are waiting here. But there is another world.

> daybreak-star herb,

> four-rayed flower of understanding. On

> It is from understanding that power comes;

> the power in the ceremony was in understanding what it meant;

> for nothing can live well except in a manner that is suited to the way the sacred Power of the World lives and moves.

> The woman is the life of the flowering tree, but the man must feed and care for it.

> One of the virgins also carried the flowering stick, another carried the pipe which gives peace, a third bore the herb of healing and the fourth held the sacred hoop; for all these powers together are women&rsquo;s power.9

> nothing can live well except in a manner suited to the way

> the Power of the World lives and moves to do its work.

> They had forgotten that the earth was their mother.

> Afterwhile I could see nothing but water, water, water, and we did not seem to be going anywhere, just up and down; but we were told that we were going fast.

> We could not fight this that was going to kill us, but we could die so that our spirit relatives would not be ashamed of us.

> We could not eat lies, and there was nothing we could do.

> Wanekia,

> Jack Wilson,

> Wovoka.

> If they did this, they could get on this other world when it came, and the Wasichus would not be able to get on, and so they would disappear.

> Hetchetu aloh!

> paezhuta sapa:

> The Lakotas recognized four fundamental virtues: bravery, generosity, fortitude (endurance), and integrity (Walker, &ldquo;Sun Dance,&rdquo; 62).

> hąbl&eacute;cheyapi



