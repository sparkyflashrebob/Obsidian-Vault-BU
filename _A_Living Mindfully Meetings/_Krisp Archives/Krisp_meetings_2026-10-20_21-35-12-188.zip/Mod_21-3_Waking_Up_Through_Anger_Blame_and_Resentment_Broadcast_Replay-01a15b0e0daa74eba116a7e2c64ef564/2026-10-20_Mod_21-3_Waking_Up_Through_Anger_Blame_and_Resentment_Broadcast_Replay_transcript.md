---
title: "Mod 21-3 Waking Up Through Anger Blame and Resentment Broadcast Replay"
date: 2026-10-20T20:44:28.683Z
duration: "01:36:32"
participants: []
tags: []
folders:
  - "MMTCP"
meeting_id: "01a15b0e0daa74eba116a7e2c64ef564"
meeting_url: "https://app.krisp.ai/m/Mod%2021-3%20Waking%20Up%20Through%20Anger%20Blame%20and%20Resentment%20Broadcast%20Replay--01a15b0e0daa74eba116a7e2c64ef564"
---

# Transcript
**Christy Akulian | 00:00**
Hello, welcome. Everyone. Do this session of our MMTCP teacher training, My name is Christy and it's so nice to see you all here. We are going to allow just a couple of minutes for everyone to get into the room. As always, I want to invite you to get your pencil and paper ready. If you have any questions or thoughts that come up that you'd like to share with Tara at the end of this. There's going to be a lot of rich information on hand and I just want to Say welcome. Max Leanne. Judy. Pauline. Welcome. Jade Hi, everybody. Hello. Hello. Just give it a little bit more time here. Judith. Laura, Krista, Corinna. Tatyana. Nice to see you, Floor. Yeah. Welcome. Welcome, everybody. So as I said, my name is Christy. You know me by this time. I want to invite you into this very special broadcast. Today, Tara is going to be offering a teaching on the topic. Of waking up through anger, lame and resentment. And afterward, we're going to open up the conversation with an opportunity to ask any questions that you have on the topic. And so we have some pre-submitted questions that we might be moving to, and I'm going to invite you to raise your hand as well. And we'll promise to get to how many ever we're able to in the time allotted. And so with that, I want to invite Tara into the space. Welcome.

**Tara Brach | 02:05**
Thank you, Christy. Always thank you for being with us. , just looking at you and taking you in and moved and touched and glad to be with you. Yeah. So Before we begin the formal session, I really wanted to start more as and most of you have received communications on some level about this recent really tragic loss in our community. And I want to acknowledge it. It's like I couldn't just start a session in what feels like an extended family and not name that we've lost Janice Gates, a beloved mentor. And So I've been trying to figure out how best to be with each other and have that be part of our reality right now. And what I came up with was we will do our formal session and The theme always is going to be how these teachings and practices help us open to what's going on in the moment. So it's, Same stuff. But we'll be focusing on the theme that we expected to. And we'll make sure to end in plenty of time so that we can extend this time for those that want to. That would like to stay on, it'll be optional just to share what's up for us. You know, if you have questions, if you have something on your heart that you'd like to name. We'll just make as much space as we can. And so What I'd like to ask, if you don't mind, just so I can get a feeling for how many feel that you're going to want to stay on past the hour in community. Can you mind raising your hand just so I can kind of look and see? 
Thank you. That helps me. It helps us in timing and so on. Okay, so now to again welcome you and The theme really for today is how as teachers we guide those who are living with conflict in relationships, with anger, resentment, and it's part of your recent curriculum and profoundly relevant. In current times. In fact, I think of it like whether we're working with individuals or working on a national, international level, The suffering in our world, I mean, when people are asked about the world, they talk about the divided world, and we know it. I mean, superpowers dividing up over Ukraine, you know, China, Russia and Iran against Europe and United States. The terrible violence of civil war, the horrendous suffering in Ethiopia and the armed conflict in so many other parts of the African continent. There's the struggle of Iranian women against male oppression. And then I think of the upcoming elections in this country with more than 40% of Americans anticipating civil war within a decade. So I'm naming all this because this... Strife. This is the air we are breathing. And it has to affect us. And it's rooted in how So many feel separate. Feel disconnected, don't feel belonging. And As you're working with students, conflict. And anger in relationships is going to be one of the most prominent domains they're going to bring in. And this is what we try to hold with mindfulness with our hearts. And so it feels really valuable to dedicate this to exploring that. But what I really want to spend time with. Is not the traumatic kind of anger and conflict but resentment. And I think resentment is a really important word. It's like that the daily resentment. That corrodes relationships in ways that people don't often see. But that we can lose our lives too. And I think you know what I'm talking about. Because it happens to most of us with a sibling we've written off or a partner that we're just locked into like feeling they're not doing their share or don't understand us. So I'm going to review some key themes in teaching about this, what will help, assault and guiding people. And ask you to explore it in your own life. As we do, because we'll do a guided... Practice with it. And then we'll open it to questions like, how do we work with other people? How do we bring it alive in our teachings? This kind of corrosive, domain of resentment. And interestingly, it's the same principles as if you're guiding groups in conflict. And I want to name one resource that's been amazing for me. And that William U-R-Y, URI. And he's well known from being part of the Harvard program on negotiation. He's served in major conflict zones over the decades, South Africa, the Middle East, Colombia. So here's this concept he offers and it's called the third side And what he says is that when there's a conflict, this is between individuals or groups, The third side represents the larger community the collective consciousness that really holds and serves the well-being of all. The third side is really ‫הכתובה. I mean, think of it inwardly for a moment with, for yourself with like personally with conflict where there's a part of you that's angry at somebody for not treating you well, let's say. And then there's another part of you that feels unworthy and says, well, maybe I didn't deserve it. So those are two parts. The third side knows to include both to nourish a deep sense of your basic goodness. And to find ways to meet your needs with the other person. The third side's bigger, it's mindfulness. It's the field of mindfulness. And I find this so useful. You know, when I'm thinking about how to work with people that are having conflicts with others. That to sense the conflict, it means, okay, there's this third side, there's this field of awareness wisdom, love that knows more. Because you know when we're in conflict we're in a kind of trance Does that make sense? That we have a narrowed filter so we're going to look at how to open to the third side or to the field of awareness. And the understanding is just what I said, the aperture of our lens is narrowed when we're in conflict and we're not of accessing what's called the relational neuronal circuitry, you know, empathy, mindfulness, compassion. Identified with a small part of ourself, the victim, you know, the aggressor, the defender, and we're seeing a small part of others. So the healing is in widening the lens. And this is what our dharma, our teachings offer us so that we can experience others from awareness. You know, it's really returning to respect. The Latin word for respect is see again, to be able to see again the human that's there. Versus what the narrow lens sees, to look again, to look anew. Okay, so Again, William Ury, Third Side, wonderful stories that you wouldn't believe the conflicts he describes and what seemed impossible and finding healing. So let me go over a few of the most basic things principles or teachings that you as teachers might include. And talks. In responding to questions about this. And the first one is to honor God. The role of anger. Okay. 
They're expressing an unmet need, something that needs attention. So to honor that You know, in some way anger is trying to protect, to overcome difficulty. Threats to well-being. So it's a message. So we need to honor that. The second basic principle I want to name is And we need to invite our students. Through it. To go beyond. I so often think of friend, teaching colleague, Ruth King, she wrote Mindful of Race and you've been with her. She says anger is not transformative. It's initiatory. So if we stay in the beliefs and the energy of anger, or resentment. We can't respond in a wise way. We need to get to the third side. The next principle is That means... We have to turn inward and shine a light on how we're getting stuck. The key challenge for most people when they're in resentment is they're replaying over and over again what's wrong with you. So it really takes motivation to shift the attention inwardly. And I often think of that wonderful quote from Mahatma Gandhi who said, "I only have three enemies. My favorite enemy, the one most easily influenced for the better, is the British Empire, my second enemy." the Indian people far more difficult but my most formidable opponent is a man named Mohandas K. Gandhi. With him, I seem to have very little influence. So it's like really getting, okay, make that U-turn, turn inward. And that means to really sense how much we're addicted to holding on to our position of being right. And when you work with students, just to begin to look at that. You know, many of you have heard me say that the world is divided into those who think they're right. And that that's the whole saying, right? So we are really wedded to being right. I know in myself that when I start getting that I made a mistake and I'm not right, I know that yuckiness of feeling that. So to turn a light on that, just to see how we've been building a case against another and that something's going on inside us where that needs attention. The next piece I want to name is that as teachers we need to find a way to inspire or motivate students to step out of their side and look towards the third side, to turn inward. Because they won't do the inner work unless there's motivation. Like, it's very gratifying to be angry. You know, it's like we feel puffed up and empowered at times. What's going to motivate us to loosen the grip and look inward? The first thing I think that really helps is to really ask, what has the anger or the resentment done for you? How has it helped? Has it gotten you what you wanted? What's its impact? How has it colored your interactions with this person? How does it affect you? How does it affect your heart, your mind? In other words, get them in touch. With the way that resentment actually increases separation and makes us smaller. פרק אחר is that we can invite a reflection on what really matters. And many of you have heard me do the kind of reflection that takes us right to the end of our life looking back. And if you're right now thinking about a situation of your own in your own life, were a sibling or a friend or a partner or somebody where there's been like some distance and you know you're holding some resentment. What would really matter. You know, what really matters. How do I wish things would unfold? It's a really powerful perspective. So that's something that you might do with students. Or you can just more directly say, you know, in some way, what really matters most about this to you? And I often ask that question, you know, how might this conflict serve more awakening. How might this serve you? Now what might come if you work through this, what might you find? So, getting the inspiration, the energy going to look inward. Okay, so the last piece I want to go over is How do we actually help people to shift. From being stuck on one side or another side to opening to that meta-frame of what we're calling the third side, our consciousness or awareness. And... Here I'm going to be using the mindfulness and compassion of RAIN and exploring that the basic key is to first invite them to do the U-turn N-word. And find out what's underneath the resentment or blame. What's the unmet need? And to offer kindness. That's the RAIN practice inside. And then If they're ready. And I'm going to emphasize this, to then Turn. To see the other person And remember that definition of respect, to see anew. From a larger space. To see the human. To see how they might be vulnerable. But I want to go back to the "if only" only if they're ready. If somebody is actually dealing with a very traumatic kind of anger or resentment. Its roots are really charged. It can take a lot of rounds of doing that U-turn and just working with the inner. And bringing the self-compassion before there's a readiness to really look from a wider lens. Does that make sense? Even more. People can get re-traumatized if you ask them to start holding another person with compassion when they're not ready. Especially if there's trauma, it's not wise. So I really like just even in doing any kind of forgiveness practice. Anything like this before asking people to start befriending the other person. I like to make it really respectful to that person only if you feel ready. Here's the thing that often happens. If you don't do it, They try. They can't feel compassionate. And then they feel shame. Does that connect for you? Trying to forgive and not being able to, and then feeling like I am spiritually falling short. Right. Okay, so only if they're ready, but if they're ready, widen the lens. Look to see the other. Okay, so this is an essential part of the evolution of consciousness, awakening through resentments and conflict. And we have to awaken through inner conflict with each other and conflict in our world. And I'll just say again, the reason it feels so relevant right now is that our world is in such a crisis technology is not going to do it. It's going to be the capacity of humans to find that third side, that larger awareness. And begin to see each other for who we really are. It's the only way. And that's what you as teachers can guide people towards. So it feels profound to me. Okay. Took more time than I meant on that. I hope it's helpful, those principles. Let's do a brief practice and then I want to open it to you, whatever you've got on your mind. And this is a practice of bringing Reign to blame. Which It doesn't matter how many times you do it. It's one of those practices that keeps going deeper. And the invitation right now is in your own life. Where Have you been experiencing a separation, knowing that you're holding resentment. And don't pick something that's supercharged because it won't serve for doing a very brief rain on blame, okay? Okay, friends, so just take a few moments to... Let your attention go inward. Breathe. To arrive if you haven't felt like you really arrived. Arrive with your body. Feel the sensations that are here. Let your breath help to collect attention. 
Feel the movement of your heart. Breath. A heart. Whatever's here. 
And scanning and sensing. Where there might be some separation, a place you'd be curious about שתביאו את התקדם that aspiration to have more connection. To not live in one side, in the resentment. 
And feel the sincerity of your aspiration. For connection, for love, for understanding. 
And then bring to mind a particular incident ‫שעכשיו, Eats resentment. Get real. Let it be there. You can actually see the person see their face, Maybe remember the words exchanged, tone of voice. 
Breezing at the frame where you feel triggered in some way. That sense of something's wrong with how you're acting or being. And then make that U-turn. Turn the attention inward. And begin with the aura of RAIN of recognizing Just notice what's the most predominant feelings going on inside you. איך נמלך? Mental whisper of maybe it's anger or blame, fear, frustration. 
Whatever your name. As if it's possible to allow, to have the space for that, to let it be without adding anything, adding any judgment or trying to fix it or make it different. For now, let be. Space of letting be allow you to bring your interest, your curiosity into investigating. You might just start by saying, well, when this is going on, what am I believing about that person? About how they're relating to me, or about myself. About what's going to happen what is your background belief that's feeding things. 
"That person doesn't care. They don't respect me." if they cared they'd be doing da-da-da-da. But mostly sense what's the worst part of this, what's most disturbing, most hurtful. And let yourself feel in your body. The feelings that are there with whatever you're believing. 
You might let your face express it. And even shift your posture a little so your body is expressing it. Sensing maybe what you were hoping for, what you were wanting that didn't happen. And just feel it in your body. And sense, what does the upset or vulnerable place feel like? Maybe put your hand where you feel experience, throat, chest, belly. 
As if you could directly address that place in you What does that part need? What does a part want? To feel cared about. Respected special. Understood. Appreciate it. Save. 
Listening. From really the wisest most awake part of your being. Listening. Honoring whatever you sense that's needed. It could include not being sure, just honoring. From that compassionate place, just offering. Whatever in this moment might be comforting. Might be healing. Maybe something like that you're lovable Trust your own goodness. , Maybe simply I'm here, I'm listening, I'm not leaving. If it helps to have somebody else offer some comfort and healing inward you might imagine and bring in. Another person that you trust and love, a spiritual figure, Just offer care. Let it go inward. 
And sense that vulnerable place. Being bathed, being held. Being accompanied. Being understood. Cared about. 
And since the quality of presence that opens up as you bring this attention. Quality of heart space. What we might call the third side the awake awareness. That's who you are right now. And if you're ready. From that place of more spaciousness, more clarity, more tenderness. Begin to sense that you can witness more intimately the other person. With more. Clarity. Or heart. And just recognize the emotions the reactions that person's having. 
The intention to allow, to let be. That you can bring some interest and deepen attention and sense what do you imagine their feeling. In interacting. And relating. How might they feel? They have their leg in a trap. Hurting in some way afraid. What were they hoping for? What were their unmet needs? Are they looking to feel more respected or loved? Important Understood. Appreciate it, Saif. 
To whatever extent you feel capable from that. Space of mindfulness and heart from the third side. Just to offer care. Offer respect, seeing them afresh. 
Maybe imagining ways you might respond in the next encounter with more choices. 
Often quote Rumi when I'm שקחו על this healing of a larger field of connection bigger than either of our sides that we're taking. So you might imagine as you listen again to the words you've heard many times probably, sense the truth of it in your life, what it really meets to meet means to meet another person, this particular person. In the field of loving awareness. Beyond ideas of wrongdoing and right-doing. There is a field. I'll meet you there. When the soul lies down in that grass, the world is too full to talk about. Ideas language even the phrase "each other" doesn't make any sense. 
So I want to invite you to explore in your own life and in leading others how There are many different ways, but that's kind of a classic route of doing the U-turn, paying attention inwardly and then outwardly. How you might support your students in waking up past the narrowness of resentment. Because this is really what we need individually and as a species. Okay, so inviting now any questions, inquiries you might have on really this whole process of waking up through what's difficult and Christy? With you now to bring forward whoever has a question.

**Christy Akulian | 34:26**
Thank you, Tamara. And I want to, yes, just Remind folks using the raise hand function. I want to go to Evelyn DelVal. I hope I've I don't know if I pronounced your name correctly, but please feel free to share your question.

**Evelyn DelVal | 34:48**
Hi. Wow, that was so... Profound and beautiful and I'm so moved by it. 
So I did the practice with my sister. And I'm aware that I want to connect with her and we've always had this difficulty. 
And she said, forget it. And I said, I want to hear what you have to say. And then I noticed my anger came up. So I was aware afterwards. I fell for it again. I could have just witnessed. And anyway, but my question is this. I keep practicing with my sister. She's my teacher, I feel, because I get to continue to or anyone that is, I feel is, harsh or aggressive or I feel they're my teachers because I get to practice expanding the scope or the window, as you said earlier. But my question is this. I have a friend who I recently, for the first time ever, had to practice. Boundaries. Her partner, committed suicide. And I was around them very close up, so I got to witness a lot of what I felt was poor and really unkind behavior towards him. And I'm aware she wasn't responsible, but I researched narcissism and I never really I'm curious, so I researched things, but this was so strong. I felt a strong impulse that I needed to have boundaries and I couldn't be in communication with her. And I've never done that in my life. This was... Six months ago that this happened. Recently, I felt really moved and deep compassion for her because I know that she's alone. She's alienated everyone. And I still feel compassion. I don't feel resentment. But I was hesitant to reach out because So many times I've been, I've tried to have conversation with her And there's a way in which she denies or deflects And once I tried to tell her the truth and I saw that she was almost going to have a psychic breakdown, she couldn't handle it, that something that recently happened wasn't the first time that this has happened in the past. 
So I'm just curious because I'm not shutting her out of my heart. I wanted to reach out, but I thought I don't really have time to manage this person right now? And I was just curious about that. Sometimes needing to have those kinds of boundaries where you say, I am not in a position to help her because I'm not a therapist. And anyway, that sort of thing. I don't feel resentment. But I felt deep compassion and I wanted to reach out. But then I thought, it's too much. I can't handle that.

**Tara Brach | 37:55**
So what I'm hearing is the inquiry of Would it be wise? Would it be wise? And first to name, you know that phrase, strong back and soft front. Right, and I hope many of you are familiar because it's so useful in teaching that you want to have boundaries that take care of yourself and others. Have that clarity, that strength, that's what enables you to keep your heart open and be compassionate. So if you do decide to reach out, it will be with both sensing even within getting together that you're going to have a strong back and a soft front and let that be a kind of I find the image really useful. Really useful. Now let me ask you a question. If you did reach out and get together, what would be your hoped-for outcome?

**Evelyn DelVal | 38:49**
I don't know why that's moving me to tears, but... My greatest... I just want people to have hope and they know she's suffering. No, I don't. I know this probably has something to do with me. I have hope. I feel, you know, in.

**Tara Brach | 39:13**
I don't know. What would you like her to have hope in, Evelyn?

**Evelyn DelVal | 39:19**
That she could experience love and that things can change.

**Tara Brach | 39:27**
Because.

**Evelyn DelVal | 39:33**
When her mother died, she didn't want her at her funeral, like she keeps doing this, alienating people. And that makes me sad. Like I don't, so if I ever can offer something and she would always come to me even when she did awful things and I would roll my eyeballs and say, Okay, so I would keep, you know, trying and.

**Tara Brach | 39:55**
I want people to have hope. Okay, so I want to pause here because that's really beautiful. I mean, it's a beautiful intention. That's really what the Buddha was doing. He wanted הוא ראה אנשים שייכים את המעבר של הלחמת That was to me the greatest thing. I mean, it's like he didn't have to say anything more than it's possible. So that's what I hear from you and I first want to just let you honor that is really beautiful. And then the inquiry is:. 
Can you imagine being in person and that there'd be some way that the overall experience, the felt sense of the experience was that you were kind of being a reminder that she, that there's all sorts of possibility for more love in her life? Do you feel like that? Could happen if you got together with Yes.

**Evelyn DelVal | 40:51**
Her? That if I reached out to her, that would be a possibility of hope. That's beautiful. Yeah.

**Tara Brach | 40:58**
Because if you feel you can get together with her and somehow have your boundaries transmit that. Then beautiful. If you feel that you might better transmit it by handwriting a beautiful card or something, then do that. But sense for yourself what your outcome is. And what's going to be the way that's possible with some people? It's not possible to do it in person. But that's your inquiry. This is my outcome. What's going to best serve it?

**Evelyn DelVal | 41:28**
It's beautiful, thank you.

**Tara Brach | 41:30**
Yeah. Yeah. Thank you for your really beautiful heart, dear. Yeah.

**Christy Akulian | 41:38**
I'd like to go to one of the pre-submitted questions that comes from Yadi Prillinger. Who writes in from Bali, Indonesia and says, When helping someone, In the heat. Of anger and blame where their needs are heavily stuck in wishing for a different past on or old or ongoing patterns, how do you bring them into the present if they have Too much energy and no patience.

**Tara Brach | 42:16**
That's a good one. Can you say the name again?

**Christy Akulian | 42:22**
Yeti.

**Tara Brach | 42:23**
Pralinger. Yeti. Wow, Yeti, so what I'm hearing is when the conditioning is really strong to want things different and to have huge energy driving in that way and it's very hard to invite someone into presence, how do you manage with that? And It's a little difficult to respond bond without you being back and forth so I can ask more questions, but I'll do the best I can. I think that one of the things that actually brings people into the present is to acknowledge with kindness and zero blame what's going on for them at the moment that you're noticing. So you might say, "I can feel so much energy and I'm imagining it's not so comfortable and I really can understand that this is what you're wanting." So you name back, you mirror back what you're seeing with real care and then go for the thing you're seeing that you sense is the stuck place that you're wanting but that's not what you feel is in your life. And once they're feeling the resonance of you getting them, it's easier to invite them to actually feel where it lives in their body. And if they can't do that, at least to feel the quality of presence of sensing, "Okay, this is the place to be attentive." Sometimes the most you can do is have someone know that you're there with them, that you get it and you care. Yeah, so I hope that's helpful. Thank you.

**Christy Akulian | 44:10**
Thank you. And we are I'm noticing that we are at quarter till the top of the hour. Do we have time for one more short question? Or Yeah, maybe two.

**Tara Brach | 44:20**
How do you or maybe two?

**Christy Akulian | 44:23**
Yeah. All right.

**Speaker 4 | 44:23**
So I want to go to.

**Christy Akulian | 44:25**
Sahanya Mariasta. And invite you to please share your question. Sahana. I'm going to ask you to unmute if you are.

**Sahana | 44:44**
Hello.

**Christy Akulian | 44:45**
Hello. Hello. ".

**Sahana | 44:46**
" Hey, thanks for taking this.

**Tara Brach | 44:58**
You're muted.

**Sahana | 44:59**
Dear. Sorry. Thanks for all the awesome classes and the support throughout these two years of the program. I really appreciate you of that. I had this one question about blame and resentment, and I'm experiencing that right now, the anger, blame and resentment. 
I just need to gather myself for a second here. Sorry. When you are facing this systemically, let's say systemic racism, Arr. Maybe systemic oppression, like let's say what is happening in Iran. Or maybe Ukraine, It's actually happening. It's a living reality. It's so difficult. And it's not one person you can pick and choose. It's a whole system. It's insidious. Many people are involved. How I feel at times that In my particular case, it's really difficult to have that large compassionate heart to not to feel blame and resentment. And it's really difficult. - Yeah. How do we, you know, how do we practice? Because for me, you know, The more I practice, it feels like What I'm getting is just more resistance. 
It's just so challenging.

**Tara Brach | 46:24**
Okay, so I want to first really honor this question. Sahana, it's-- it's really important to know that with systemic violence and oppression we can prematurely try to move towards compassion or forgiveness in a way that really violates ourselves and that the anger and the resentment has a really crucial role You know, I think of this, you know, in terms of all the racial injustice, religious oppression, whatever the form is. We're meant to be angry, it's healthy it's what energizes and motivates us to protect ourselves. And so I would never encourage trying to move from that too quickly. We need that energy. And here's the thing: we need to be in an ongoing process of healing inside what's underneath the anger. So it's a both/and. And if you asked yourself, under that the blame and under the anger, what's in your heart? What do you notice?

**Sahana | 47:52**
I think at times it's just, sadness of not being heard or not being respected.

**Tara Brach | 48:00**
- That's right. - You.

**Sahana | 48:01**
Know, for me, I feel even need a simple need for a white person becomes a privilege for a person of color. That's the way, you know, we've I feel that that's the way I get the kind of treatment being in the system. So it's...

**Tara Brach | 48:21**
It's hard. It's totally hard. So what I'm hearing is that underneath the anger and the resentment there's a sadness. That this is happening. That this is happening and keeps going and it keeps going. Yeah. And if you just right now say yes to the sadness to say yes to it. So this belongs. And just tell me what you notice if you just honor the sadness, honor If there's grief, honor that. What do you find? What happens.

**Sahana | 49:05**
Kind of a stillness arises Yeah, just space and stillness.

**Tara Brach | 49:10**
"stillness" Yeah. So let that be for a few moments. And sense as you just allow it. There's that question, you know, how does love want me to be today? How does this stillness want you? To move forward. What's the wisdom in there? What will most serve in all ways?

**Sahana | 50:02**
There's just a space. I'm not getting any particular answer right now.

**Tara Brach | 50:09**
And that tells me that you're actually inhabiting it. You don't need an answer right now. What? For this moment I can best say is that if you allow yourself to go inward and bring a presence to what's underneath the resentment You'll start coming home to something bigger and it doesn't mean that you don't still really get that there's danger out there and that you need to be active because you do or you know we need to take care of ourselves it just means you'll be acting from a more courageous and free part of yourself. There's a bigger place. And that's the invitation to explore. Does that resonate for you right now?

**Sahana | 50:59**
Yes, it does. Yes, but at the same time, It feels a tiring process every time to get engaged and re-engaged. Because the triggers are so much, it's ongoing. It's just not one person, one thing.

**Tara Brach | 51:16**
Of course. Of course. It always It feels like...

**Sahana | 51:18**
Feels this pressure to be continuously in practice.

**Tara Brach | 51:24**
Maybe you might want to change the... Reframe the notion of practice to take a nourishing break for yourself where all you do is breathe and feel what's here and just let yourself quiet because it doesn't have to be an effort filled. You don't have to try to get somewhere. Just let it be nourishing. Does that?

**Sahana | 51:50**
Yeah, it does. It does. Yeah. It's a driving part, I think, yeah.

**Tara Brach | 51:55**
Yeah, it's not a striving to get to some bigger third side. It's really a nourishing that naturally reopens you to more of who you are.

**Speaker 6 | 52:10**
Makes sense.

**Tara Brach | 52:12**
Thank you again, Sahana. That was really important to hear from you. Appreciate it thank you so Yeah, so let's, Christy, one more person.

**Sahana | 52:18**
Much thanks for your time and answer Yeah.

**Tara Brach | 52:26**
Yeah, I love hearing from everyone.

**Christy Akulian | 52:29**
One more Satyani McPherson. I'd like to ask you to unmute and share your question, please.

**Speaker 6 | 52:38**
- Yeah.

**Satyani McPherson | 52:39**
Greetings Tara and Well, I feel like Evelyn and I must be sisters because our sisters are twins.

**Evelyn DelVal | 52:41**
Christy.

**Satyani McPherson | 52:53**
Metaphorically, symbolically. And so I found the practice really just very organic and natural that even before you invited us to sort of These are my words, bathe in consciousness. I was already... Seeing her.

**Speaker 6 | 53:15**
Bathing in light. And then I stepped into that light as well. And that was very beautiful. But then.

**Satyani McPherson | 53:25**
What to do? In person, similar situation. She's estranged herself from Most of the biological family doesn't communicate And even... When I have asked, Would you please help me to understand? How you feel harmed. Well, you just need to admit what you did and you know, "Just own up to it." I'm like, "I don't know what you're talking about." But I feel that even if I said those words, they would be received as a kind of dis. If and when the next time I have an opportunity to be with her, because she has estranged herself for several years, And well, I'll add not only from the family, but even on social media, there's a constant judgment from her of colleagues, neighbors. The person walking down the street, the person who parked their car the wrong way. I'm like my So nothing I can do about that.

**Tara Brach | 54:30**
Goodness.

**Satyani McPherson | 54:35**
But How can I bring that healing presence. In person. Or even from afar, but I aspire to. Reconnect Damn.

**Tara Brach | 54:53**
Well. I love you for it. ", And it's beautiful that your heart has that aspiration satyani. So let me ask you a question. If you look behind her behavior. The Tell me about the wounded person inside. Just a few words to let me know. How is she wounded?

**Satyani McPherson | 55:20**
Yes, she's experienced a lot of trauma.

**Sahana | 55:23**
A lot.

**Satyani McPherson | 55:24**
I'm not sure that I'm going to go into all of.

**Tara Brach | 55:27**
It, right? No. Just describe a very wounded little person. Who do we.

**Satyani McPherson | 55:34**
Someone who was abandoned by her protectors. Yeah. Yeah.

**Tara Brach | 55:39**
- So she's...

**Satyani McPherson | 55:39**
Yeah. - As a child. Literally as a baby even. Yeah.

**Tara Brach | 55:47**
Before she was even really cognitive, she's trying to protect her existence. Yes. She's trying to protect and it's a very unsafe world. I mean, abandonment's the worst. Yeah. So what's your prayer if you could imagine her? In some way receiving really what she needs, what do you imagine?

**Satyani McPherson | 56:24**
Well, first of all, that she's not only okay, but very beautiful just as she is. I think she feels she felt rejected. 
Well, very creative, expressive, energetic, effervescent, Funny. I feel joy and happiness.

**Evelyn DelVal | 56:55**
Yeah.

**Tara Brach | 56:56**
And when you say that, what's your heart feel like when you just sense her goodness?

**Satyani McPherson | 57:03**
Yeah.

**Tara Brach | 57:04**
Okay, so here's what I'd like to invite you to do is don't think about how am I going to be with her then. More actively offer your prayer by sensing both the woundedness and the goodness. Your care for the wounded one and your You're real. Affection and appreciation for that vibrant being. And then that Just cultivate that because that's going to inform you, that's going to energetically inform מה שייכן לנכון אם תצטרפתם, יותר מפני כל פרס. And what I'm not mentioning is the strong back because I think you are really I think you're very wise in that balance. Everything I know about you, and we're friends from the old days, you have both the strong back and the soft front. But this is really cultivating a more energetic attunement to her.

**Satyani McPherson | 58:04**
So resonating with the goodness that I know is there.

**Tara Brach | 58:09**
And letting your heart feel the woundedness. Yeah. Thank you. Thank you. Really? Blessings, dear.

**Satyani McPherson | 58:21**
Blessings to.

**Sahana | 58:22**
You too.

**Tara Brach | 58:22**
Tara. Yeah. So, Christy, I think that's time for this. We've come upon the hour and love the questions. I want to thank you for holding space for each other because those were beautiful. Yeah. A lot of gratitude for that. We're going to take a pause here. And it's a way of closing and inviting those that do not want to Continue on beyond the hour to bow out. And those that want to stay, it gives you a chance just to arrive again in presence. But first just to look at each other for a moment, see each other. You're a beautiful community and I feel the deepening each time I'm with you. So just a namaste and bow to all of you. Yeah, and we'll just take a moment of quietness while those that are ready to leave can leave. 
As we shift to directly bring our attention to this recent loss. That for some of you Who? New Janice may feel incredibly raw knowing that all the different feelings in the world can come up, anything from Reef. To anger, to confusion, to doubt So I just want to Just say that whatever you feel is welcome. Please send that message inwardly. Some of you don't know Janice at all but perhaps a to have somebody in your life that took their own life. Have struggled yourself with suicidal ideation Amen. This brings up so much for so many of us that I just want to start by saying that this truly is a space that can include whatever's here. To breathe and just feel What is here for you in your heart? Stay with yourself. And with each other. 
In a few moments, Christy will I'll call on someone who may want to ask a question or share briefly. We'll keep it brief so that there's a number of people, if you want to be able to speak Yes, a briefful matter, a kind of sensitivity to time. If you say something and you feel you don't want it recorded, just let us know at some point, the beginning or end, and we'll make sure that it does not get recorded. I really want you to feel I just want you to feel safe. And like you can speak from your heart. So. With that, my friends, Christy, as we go. Here we are.

**Christy Akulian | 01:02:35**
Okay, thank you Tara and I just want to add to that It might not be possible to stop the recording during this session, but if you Acknowledge to us that you don't want to be carried forward for people who might be watching the replay, then it can definitely be edited out. So I want to go to Monica and ask you to this year.

**Tara Brach | 01:03:12**
You're still muted, dear.

**Monica | 01:03:18**
Hey, can you hear me now? - Yes, good. So it was on the wrong speaker, I apologize. I just want to name that I have a lot of sadness. Janice was my mentor. I really respected and adored her. So it's been waves. And I just wanted to name that I'm surprised the waves. I've only known her through the internet, but it's Yeah, just start. She really touched me and just the sadness that She had so much to offer. You know, I know she can still live in my heart, but that's gone. I wanted to name that. And I'm really appreciative of my peer group and all of the program and all that is being done to support.

**Tara Brach | 01:04:16**
Thank you. Blessings.

**Christy Akulian | 01:04:19**
Kathleen. McLeod, please.

**Speaker 6 | 01:04:27**
Hey everyone, it's nice to see So many people who have Yeah.

**Evelyn DelVal | 01:04:29**
You.

**Speaker 6 | 01:04:33**
And touched my best friend. Excuse me. I too, Janice was my mentor. I am. I'm really quite surprised by The amount of emotion that I feel around this. I feel exactly the same way about Janice, Monica described There's some level of just I absolutely disbelieve it. She somehow couldn't. Manage this in some way, like the suffering just seems so - Absolutely unbearable. I guess my question is, And many of us, I'm sure, are feeling a huge range of emotions. And really what I want to I'm looking for what kind of practice to do. And I feel like that reference to the strong back, soft front, I don't know if this is actually a really great but I feel like I don't have a strong back right now. I feel really fragile. And it's like, I just feel really fragile and they want to feel resilient and strong. So what might that I want to build up resources around this. What might that look like? Thank you.

**Tara Brach | 01:05:52**
You can stay on for a moment just so we can talk. Yeah, I hear you and I think that that's what this does to us, is that it shakes the ground so deeply that it kind of we do a dive into real fragility and so the first piece is just what you're doing is just to name it saying okay really fragile season I mean, this... This is putting us right on the edge of the mystery of fear of love, of not understanding, of confusion. It's so hard. So just to like even say, "Okay, This is fragile. And if you look around you're going to see a lot of us that, you know, I feel that quaking. The one thing I can offer that helps in terms of the practices. Is to not sense that you're holding it alone actually in some daily way, sense that there's you know, the heart of the universe, there's love that's big and I literally just say, "May this be held in that." And I'm not getting rid of it, I'm just offering it into, it's like the river into the ocean, I'm offering it into something larger. And that belonging is the real healing to fragility. Everything else is kind of a nice story. Do you know what I mean? I do. I know I can tell you do. I do. And that's a practice. It's like, Somebody might hear me say, "Well, offer it off into the Infinite Divine Beloved," and say, "What?" But it's actually It's really going through it over and over again that there's some truth in it that we find out in a very embodied cellular way that we do belong just by going through the motions.

**Speaker 6 | 01:08:07**
- If I could say one thing, I understand all of this. It all makes sense, I guess, It's tea. It's the doubt that creeps in. - The doubt that there is that that there's something that there is, that awareness that universal love it's that it's the doubt and that feels It's scary.

**Tara Brach | 01:08:29**
The doubt that what?

**Speaker 6 | 01:08:50**
I know I can do this practice. It's that sense of doubting that makes me so... Ugh. Afraid, I guess. I haven't.

**Tara Brach | 01:09:01**
Yeah, so Kathleen, It's really good that we're right here, right now naming doubt. Because if we did a hand raise we'd find that is in a huge number of us. It's like, wow, if this could happen to a Dharma teacher, can the Dharma really work? It's big. It's deep. It's like the most, the deepest thing you want is to trust. Like if we can trust, we can relax. And so it shakes that trust. And the first part of doubt, of working with doubt, And this is, you know, doubt is one of the big five, right? Yeah, you're with me? There's a reason it's one of the big five, is that it paralyzes us. And that fear you're talking about. The first step is to do what you're doing now is to name it. It's like let's all name it together. Here we are. We are in Sangha, we are in community. Okay, doubt. Let's just... Say that's there. And to feel our shared mindfulness naming doubt as a force that is natural, it comes up, It can paralyze us. And then just to ask you, When in your life have you found something that helped you with deepening trust? What was it? Bye.

**Speaker 6 | 01:10:33**
Well, being in nature for sure. You know, being outside and in nature, absolutely. I was raised a Catholic. I'm not a practicing Catholic. Church typically has been a place where I've been able to go to and find some solace and comfort, but probably primarily being out in nature. Thank you. - Or and community. - Beautiful. Being with people. And certainly today being with this group of people who've all been touched by.

**Tara Brach | 01:11:05**
This. Do you feel right now a sense of that? That there's something larger as we're all together. Can you feel the field that is here that's bigger than an individual body-mind, that's a kind of tender, awake field?

**Speaker 6 | 01:11:20**
I do. I do. I see the numbers of people that are present. And the faces certainly helps with that a lot.

**Tara Brach | 01:11:31**
You know, again back to the Buddha, you know, what the Buddha did was touch the ground and call on you know, Call on the whole natural world to bear witness. And that's exactly what you do. You go outside and you touch the ground in some way. And we're part of the natural world and you're doing that, I think each of us has to have a way to touch the ground when we hit doubt. I go out into nature and literally lean against a tree You know, I listen to the birds and sense they're my friends. I listen to the flow of the river. And then in some way I call on the beloved that lives through all of that. You know, and I take refuge, I wanted to be with you today. I really did. I feel it, you know, you can probably sense it. This is part of what deepens my trust. In what we are beyond these body-minds. So... Just to say, keep naming doubt and keep touching the ground. There'll be many more rounds of doubt. And I can tell you understand. I can tell you feel it right now. Yeah. Thank you for the stuff. We all needed it. We did. Thank you. Okay. Thank you. Take good care, Kathleen.

**Speaker 6 | 01:12:50**
Thank you so.

**Tara Brach | 01:12:50**
Much. Yeah.

**Christy Akulian | 01:12:54**
Thank you, Kathleen. I want to go now to Mariana. Amos. I invite you to Unmute. And share your question if you're still there.

**Speaker 6 | 01:13:08**
Yes. Can you see me? Yes. Yes. Yeah. Well, thank you Tara for taking the time to spend with us. Our regular time together. I was, very moving because I had this fan. Janice was my mentor and I had so many text messages with her. 
I was trying to meditate yesterday. And it was the guided meditation because I'm doing a week so wellness, cultivating wellness through mindfulness and I signed up before this happened. And. One of the practices every day is a guided meditation. For each week and this particular teacher's voice It's very similar. Good job, guys. 
Just like her. I had to take my earphones off. Stop. I Man, I fell. You Healthy. Feeling that way.

**Tara Brach | 01:15:09**
Let me just make sure I'm following you, Mariana, that you said that you feel angry and hurt and then guilty about feeling that. Yeah. אוקיי, אז מה אם felt the anger right now and let yourself sense it right here the hurt And no. That Others feel that too. That's part of what happens. I mean, in some way you've been abandoned. You've been left ‫השפעה שהיא נורשת ‫היא נרשת ונחלת, ‫היא מאוד נתרלית. And I wonder what it would take for you just to forgive that this natural experience is happening. What would you have to believe? What would you have to trust just to forgive? Okay, there's anger. Okay, there's hurt. What would you need?

**Speaker 6 | 01:16:14**
Just need to... Understand that she didn't want to do this to herself. I just can't comprehend.

**Tara Brach | 01:16:31**
So you need to understand that she didn't want to do this to herself. So maybe Just to say a little bit more, which is You know, people... When they self-destruct " The Janet we know. Something was malfunctioning in her brain. She would never have wanted to destroy herself.

**Speaker 6 | 01:17:09**
I know.

**Tara Brach | 01:17:11**
All of us that know her know that. So... It wasn't a choice. It was a malfunction that's a tragedy. A real tragedy.

**Speaker 6 | 01:17:27**
That's what I need to understand because Every time I think of her and I think of Her voice and her words. I get real confused. So... I just need to understand it. It wasn't her choice.

**Tara Brach | 01:17:52**
There was no agency, no choice. And you can see it, you know, I'll share with you all, and maybe I'll share this again, and we're going to do another session next week, but... I've had friends, I had one friend who was one of the most kind-wised people I ever knew. She was a mentor for me. And she got a brain tumor. And she wasn't kind and wise anymore. What came out She had a she got you know when people would visit and stuff there was a meanness and that wasn't her. It's like her brain wasn't functioning. And so I just-- totally remember her, the purity of who she was, not what happened when the brain was malfunctioning. It's not our fault. Janet's spirit is still Janet's spirit and it's still right here. You can feel it if you just kind of like open up, you can feel her.

**Speaker 6 | 01:18:53**
- I think what I need is to, remember her with kindness and which it really was. That's, thank you. That's it. That particular SNO.

**Tara Brach | 01:19:07**
Yeah, if we hitch our idea of people to one act, then we're deluded. You can trust what you really knew.

**Satyani McPherson | 01:19:17**
Yeah. Yeah.

**Speaker 6 | 01:19:19**
Thank you.

**Tara Brach | 01:19:20**
Tara. Thank you, dear. Again, you're bringing up something that is living through all of us. Yeah. Blessings.

**Speaker 6 | 01:19:29**
Yes, thank you.

**Christy Akulian | 01:19:32**
Thank you. I'd like to go to Debbie Germino, please. I'm going to ask you to unmute.

**Tara Brach | 01:19:45**
Thank you.

**Debbie Germino | 01:19:47**
Thank you, Tara. I really just wanted to express my deep gratitude for you holding the space for us and for us away.

**Speaker 6 | 01:19:58**
Giving.

**Debbie Germino | 01:20:01**
Sorry, my dog is talking to me right now if you're hearing that. - Just really modeling for us how to H and le really difficult situations and really heartbreaking tragedies. And it's so, missing in our culture of how to handle these things. And it really just touches me that you're able to acknowledge something like this and bring it forward and give us space to really feel it and model how to do this for our students because it's not an easy thing to do and certainly in these past two years of this program. You've had more than your share of having to do this over and every time you and everyone else and Christie and everyone in MMTCP has really handled it. In a way that I think we can model and that we can try to bring into our own practice and bring with our students as well. So I just really appreciate that. And I just wanted to say that to you out loud and really bring that forward. And I did just recommend a book that is really helpful in this time that I just happened to be reading and it's called the wild edge of sorrow. And it's just wow, just really beautiful and dealing with grief and sorrow and So I just wanted to name that too.

**Tara Brach | 01:21:55**
Thank you. Well, Debbie, thank you. And thank you for your wisdom because We are all learning to be an apprentice to sorrow. You know, and you're right, a lot's happened with this cohort and what's working, because there's something working, is that we're all showing up together. It's like, We're all doing this together and being real and I don't know any other way through, so Blessings, dear. Thank you for naming. Thank you.

**Christy Akulian | 01:22:29**
Tara, do we have time maybe Mary Ann, I'd like to come to you and invite you to share, please.

**Tara Brach | 01:22:32**
For one more? Time for one more. Yeah, thank you, Christy. You tuned in exactly right. Yeah. Okay.

**Speaker 4 | 01:22:47**
Hi, Tara.

**Tara Brach | 01:22:48**
Hi, Chester. Hey, hi there.

**Speaker 4 | 01:22:50**
First want to thank you For being there, for holding us for everything. I'll keep that one short... I am just Yeah, I don't see you, but I don't know why. This I can see.

**Speaker 6 | 01:23:12**
Yeah.

**Speaker 4 | 01:23:13**
So I don't know the person who just left us. She wasn't my mentor. But what I do know is like I have been, I lost a lot of people in my life. That have taken their lives. I lost my father when I was 11. He was sick, but then I lost one brother. Who raised me, who took his own life and then two others, only last year. So this has been something really ongoing for me and I find that sometimes when I hear it from people outside of me, of my circle, I kind of freeze to the situation instead of being..... Taken by the emotions, I kind of put like an armor around me. And come back to what we talked in our talk before the resentment I was wondering like I sometimes hold resentment to my partner husband that I've known for more than 40 years and I will equivalent like really not really important things and with him and I'm just wondering If I sometimes go into and stay in that resentment in order to numb and freeze what's really going on inside of me. He doesn't make a difference between " you're angry" or "you're sad" and so like I hang on to that resentment rather than while feeling what's really going on inside of me. So I don't know if It's clear what I'm saying, but like, What I'm coming from is like really instead of feeling the sadness when I hear something like it just happened to this teacher. I will freeze and I don't think that's a healthy thing, so yeah, I was just wondering if you can.

**Tara Brach | 01:25:41**
Well, first I'm really sensing how you know, wisely attentive your being to what your reactions are. And that's always the opening of the door that you're noticing, you know, you're noticing the freezing, you're noticing the cutting off. Let's say it's true. That there is A grief. That feels so that you might feel devastated by if you really opened to what was under and that it's easier to feel resentment and it's easier to shut down than to open to that. Let's say that's true. Okay. Then What do you imagine is your wisest path to healing?

**Speaker 4 | 01:26:51**
Well, now that I know the rain and I have Au revoir. Some years of practice. I actually try and stay with it. When I'm aware of it. But I have to be aware I have to get out of my ego. Like when I'm into it, I don't see it, but then when I touch the sadness, Then I realize it and then I will try and stay with it and practice RAIN for instance or just be with it. I used to now. Now I just try and stay with it. When my last brother passed away, I couldn't sit, but I would just walk in the streets and walk, but just stay with the feelings.

**Tara Brach | 01:27:39**
And what helps you stay? Is there something that you know just... It can make it easier for you to actually stay with and open and feel.

**Speaker 4 | 01:27:58**
I don't know, there was so much anger and... Not understanding and then just I think it's the practice that makes me now capable of staying. Because I've קראתי את זה ו... So I know that there's a door there. I know it.

**Tara Brach | 01:28:18**
When you feel comforted by something, what is comforting you? Like is there a sense of does nature comfort you? Is there another person who's comforting? Is there a sense of a deity or awareness or love? Is there anything that's a comforting presence?

**Speaker 4 | 01:28:40**
I have nature, the trees for me, nature. My dog.

**Tara Brach | 01:28:46**
Yeah.

**Speaker 4 | 01:28:54**
And then sometimes I have. I'm raised Catholic, but I... Somehow I know Archangel Michael, some words might be silly, but I know I've been protected as a child. I will call on that.

**Tara Brach | 01:29:10**
Well, let me just ask you to check something out right now, if you will. And this is really for all of us, just to close your eyes for a moment or lower your gaze. And sense what the presence is that where you feel protected, comforted, held. And it may be for you feeling, just sensing the trees that you're familiar with, that you love. Or the energy of your dog, just sensing your dog looking at you. And for others, there may be a particular person that you just trust loves you. Or it may be a sense of the field That's your... That tender feel, the belonging, or it may be the heart of the universe, the goddess, Love it. But just since what it is that feels true that you belong to. And invoke it, imagine it, feel it. This is a form of metta, of loving-kindness. Just feel it. If your hand is on your heart, just feel that larger presence that you belong to filling you holding you. Red fuel. All of us here are doing that. So that we're all tapping into a larger belonging, as Rumi talked about it, that field that we meet each other in. The loving presence. And just sense that if you invite that in that it's possible to open to the waves of grief. Of confusion, of hurt, of whatever's there. That there's space for it. It's possible. And each time you invite that sense of the field that we belong to you can open more fully. לסביב את חייכם Just checking with you, Marianne. How are you doing?

**Speaker 4 | 01:31:27**
I like the feel. I have When you talk about field, I often call it my gang. It's like, okay, Buddha, Jesus, Michael. Every one of you like, I just... Put them in one big because I can't just name one.

**Tara Brach | 01:31:48**
Beautiful.

**Speaker 4 | 01:31:53**
There's Kuan Yin, there's... Depending on... It doesn't really matter. I kind of have a feeling of their It's life. More than life. Yeah. In a sense. And I know I can't happen to that. I have to sit and do aspiration.

**Tara Brach | 01:32:15**
It. Exactly, let that be your That's the takeaway.

**Speaker 4 | 01:32:23**
Coming back to my little self and then snapping like the little dog.

**Tara Brach | 01:32:30**
You're naming it just right. It's a remembrance of a larger truth.

**Speaker 4 | 01:32:37**
Thank you, Tara.

**Tara Brach | 01:32:40**
And in that spirit, I want to invite all of us to gallery view. Just take a moment Feel what's right here. Being intimate with what is inside you. 
Feeling a sense of As you kind of look around and open your eyes, that this tenderness and aliveness and emotion and consciousness that's living through each of us. An ocean coming through many wells but it's the same ocean. Since the field is here. And kind of feel into it. Bill. Janet. Janus, the consciousness the spirit, the heart, as part of that field. 
Again, just sense these words. Out beyond ideas of wrongdoing and right doing, there is a field. I'll meet you there. When the soul lies down in that grass, the world is too full to talk about. And ideas, language, even the phrase "each other." doesn't make any sense. And so before we and just to feel our prayers. Our care. Sending a lot of metta to Janice and her family. Our loved ones and all of us who are in some way touch. This loss I have a candle here, I'm just gonna offer it to us as a way to just sense that light that's living through us all, just to feel your prayers. And to feel your heart holding each person here. And feel your heart holding all of us. Infinite numbers of beings. You are infinitely tender. Loving. The awareness that holds us all. 
Namaste, friends. Thank you so much for your hearts, your good hearts, and I'd like to invite you to be able Say goodbye to each other if you'd like to unmute.

**Speaker 6 | 01:36:04**
Thank you so much. Thank you, Sarah. Thank you, Tara. Thank you so much. Thank you, Tara. Bless each one of you.

**Speaker 4 | 01:36:28**
Thank.

**Speaker 6 | 01:36:29**
You. Blessings to everyone. Let's go.

