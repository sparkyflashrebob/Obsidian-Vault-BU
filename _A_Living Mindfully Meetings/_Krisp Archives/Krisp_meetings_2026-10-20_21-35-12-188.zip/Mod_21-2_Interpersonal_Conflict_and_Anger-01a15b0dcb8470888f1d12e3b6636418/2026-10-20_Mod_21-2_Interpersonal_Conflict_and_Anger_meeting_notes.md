# Mod 21-2 Interpersonal Conflict and Anger - Oct, 20

### Mod 21-2 Interpersonal Conflict and Anger
📅 October 20, 2026
👥 Andy McGuire (Main Teacher), {{Speaker_2}} (Co-facilitator/Contributor)
Tags: Interpersonal Conflict, Anger, Mindfulness, Compassion, Nonviolent Communication, Emotional Intelligence, Relationships, Spiritual Practice, Psychology, Men's Movement, Peacemaking
### Outline
### The Universality and Inevitability of Conflict in Relationships

- Conflict and anger are presented as universal and inevitable aspects of human relationships, not as signs of failure or dysfunction.

- Illustrated through the porcupine parable, the dynamic of closeness causing pain while distance causes isolation reflects the fundamental tension in all intimate relationships.

- Surviving together requires accepting the wounds that come from closeness, with the warmth of connection outweighing the pain of occasional harm.

- Human relationships involve an ongoing dance of misunderstandings, withdrawal, attachment, and lashing out, driven by differing needs seeking fulfillment.

- Reactivity between people is described as evolutionarily natural, rooted in the limbic system, while the frontal cortex enables the capacity to perceive others' deeper intentions and vulnerabilities.

- Despite humanity's evolved capacity for collaboration, collective challenges such as nuclear threat and environmental destruction demonstrate that limbic reactivity remains a significant force.

### Anger as a Natural and Intelligent Signal

- Anger is framed as a necessary and intelligent emotional signal that alerts individuals to obstacles preventing their basic needs from being met.

- Suppression of anger, often enforced by dominant cultural messages, is identified as harmful, with the example of African Americans being conditioned to conceal anger in order to be perceived as safe and successful.

- Unacknowledged anger can manifest as chronic anxiety and depression, as illustrated by the case of a young woman unable to set boundaries with her abusive father until she allowed herself to experience her rage.

- Gradually opening to the energy of rage, without labeling it as bad, was shown to carry an intelligence that guided the individual toward establishing healthy boundaries.

- Unprocessed anger can harden into victimhood narratives and be projected onto subsequent relationships, indicating the need for deeper emotional work to access the grief beneath the rage.

- Like weather systems, anger has a natural function within the human psyche, and the problem arises not from its presence but from being possessed or overwhelmed by it in ways that create separation.

### Recognizing Patterns and Strategies of Anger Expression

- A key initial step in teaching about anger is helping individuals become aware of their own control strategies, since unconscious strategies perpetuate reactive cycles and limit freedom of response.

- Direct aggressive expressions of anger, including verbal attacks, physical aggression, and punitive behavior, represent one common pattern, often resulting in regret and unmet needs.

- Passive-aggressive strategies, such as withdrawal, indirect put-downs, silent manipulation, and guilt-inducing behavior, represent another common pattern that equally undermines genuine connection.

- Acting out of anger consistently fails to meet the underlying needs that triggered the reaction, making awareness of one's anger style a foundational step toward change.

- Recognizing the suffering produced by reactive anger, including the diminished sense of self and the damage to relationships, builds motivation for developing a more conscious response.

### The Principle of 100 Percent Responsibility

- Taking 100 percent responsibility for one's experience is presented as a liberating and empowering attitude that underpins all effective work with anger and conflict.

- This principle does not imply responsibility for another person's behavior, but rather the full capacity to respond wisely and kindly to what arises internally.

- Fixating on blame and self-justification is identified as deeply disempowering, as it externalizes the source of suffering and prevents genuine inner healing.

- Eliminating triggers by leaving relationships or dropping friendships is described as an avoidance strategy that never addresses the internal emotional wounds requiring healing.

- The emotional source of suffering is located within the individual, even when another person appears to be the trigger, making the inner response the primary site of transformation.

### The Practice of Pausing and the U-Turn

- Developing the habit of pausing before reacting is described as a trainable skill that interrupts automatic limbic responses and creates space for a wiser reply.

- The U-turn is introduced as a practice of redirecting attention inward, taking full responsibility for one's emotional state, and getting in touch with the feelings and needs beneath the surface anger.

- Pausing long enough to reconnect with one's deeper intention, such as the desire for understanding, connection, or closeness, allows a more authentic and effective response to emerge.

- Andy's personal account of a conflict with his son illustrates how a timeout and inward inquiry revealed grief beneath rage, and how expressing that vulnerability shifted the relational dynamic more powerfully than confrontation would have.

- Self-compassion is identified as essential during the U-turn process, particularly when accessing painful emotions such as grief or hurt that lie beneath anger.

### Communicating Anger Through Nonviolent Communication

- Nonviolent Communication is introduced as a framework that is deeply aligned with mindfulness and compassion, making it a natural complement to the broader teaching approach.

- The basic formula involves objectively describing the triggering event without added interpretation or judgment, followed by naming the feeling experienced and the underlying need that was unmet.

- Objective observation requires stating what occurred factually, for example describing a tone of voice or a specific action, rather than characterizing the other person's behavior with evaluative language.

- Expressing feelings and needs in the first person, such as stating "I felt angry because I need to feel respected," avoids communicating blame and reduces the likelihood of a defensive reaction.

- Andy's account of a conflict with Jonathan demonstrates that technically correct use of the NVC formula without genuine inner contact with one's feelings and needs produces no real empathy or connection.

- Only after both individuals separately completed their own U-turn processes and accessed their authentic emotional states did the same NVC language succeed in bridging the distance between them.

- Mirroring the other person's expressed feelings and needs back to them is noted as an additional practice within NVC that supports mutual understanding.

### Conflict as Connection and the Role of Community in Holding Conflict

- Conflict is recognized as sometimes serving as the primary mode of connection in relationships where other forms of intimacy are unavailable, as observed in family systems where warring was the dominant relational pattern.

- Establishing physical comfort and appropriate distance before attempting vulnerable conversation is described as a necessary precondition for productive conflict work in therapeutic settings.

- Giving voice to the fear or hurt beneath anger is identified as transformative, as it invites a qualitatively different quality of listening from the other person.

- Spiritual communities are noted as frequently conflict-avoidant, often using spiritual practice as a bypass to avoid the messiness of interpersonal difficulty rather than as a tool for engaging it.

- Men's movement retreats led by figures such as Robert Bly, Michael Mead, and Malidoma Somé are cited as environments where conflict was actively welcomed, practiced, and used as a vehicle for communal learning.

- Dedicated conflict sessions within those retreat communities, including structured insult practices drawn from West African initiation traditions, served to desensitize participants to shame and fear around being seen and challenged.

- The same principles of mindful listening, naming feelings, and articulating needs for safety are described as foundational to peacemaking efforts in conflict zones such as Burma and Israel-Palestine.

- Humanity's continued reliance on violence as a means of resolving collective conflict is framed as an outdated pattern, with the interpersonal tools of mindfulness and compassion holding broader implications for global transformation.

### Next Steps

- Future sessions are planned to explore wise communication in greater depth as a continuation of the current module on anger and conflict.

- Participants are encouraged to apply the U-turn practice and the principle of 100 percent responsibility in their own relationships as an ongoing personal inquiry.

- The integration of Nonviolent Communication principles into mindfulness-based teaching contexts is affirmed as a direction worth continuing to develop and refine.


### Key Points, Subjects and Themes
- Conflict and anger are universal and inevitable in close relationships
- The porcupine parable as a metaphor for the necessity of closeness despite the pain it causes
- Anger as a natural, intelligent, and necessary signal of unmet needs
- The concept of being 100% responsible for one's own experience and responses
- The limbic hijack — reactive versus responsive behavior
- Recognizing personal anger styles: direct aggression versus passive-aggressive withdrawal
- The U-turn: pausing and turning inward before responding outwardly
- Nonviolent Communication (NVC) as a framework for expressing anger constructively
- The gap between knowing the tools and embodying them with genuine feeling
- Conflict as a form of connection, particularly in families where it was the primary mode of relating
- Spiritual communities as often conflict-avoidant, engaging in spiritual bypass
- The men's movement as a space where conflict was welcomed and worked with directly
- Collective peacemaking using the same principles of mindfulness, listening, and expressing needs
- The role of grief underneath anger
- The importance of self-compassion in processing anger
### Detailed Subject Matter
**The Porcupine Parable**
- Porcupines in the coldest winter faced a choice: stay apart and die alone, or come together and endure the wounds from each other's quills
- They chose togetherness, learning to live with the wounds in exchange for the warmth that allowed survival
- Used to illustrate that conflict and hurt are inherent to close relationships, and the choice is whether to remain present despite that
**Anger as Natural and Necessary**
- Anger signals that an obstacle to meeting basic needs has been encountered
- Without anger, there would be no awareness of such obstacles
- Ta-Nehisi Coates cited as noting that African Americans are culturally conditioned to suppress anger in order to be safe and prosper — a message from the dominant culture
- Suppressing anger leads to anxiety and depression, as illustrated by the case of a young woman with an abusive, alcoholic father
- As the young woman gradually acknowledged her rage through mindfulness and self-compassion, the anger provided intelligence that guided her in setting boundaries
- Unprocessed rage can harden into victimhood and be carried into future relationships, requiring deeper work to reach the grief underneath
**The Limbic Hijack**
- When triggered, the initial response is typically blame, defensiveness, and aggression
- The frontal cortex enables the capacity to see past reactivity and perceive another's deeper intention and vulnerability
- The question posed: how quickly do we react, and do we have a habit of pausing to call on mindfulness and compassion?
- Acting out of a limbic hijack typically results in needs not being met and a diminished sense of self
**Control Strategies and Anger Styles**
- Everyone has strategies for controlling themselves or others when anger arises
- These strategies operate below awareness and must be identified before they can be interrupted
- Direct aggression: lashing out physically, verbally, or punitively
- Passive-aggressive: withdrawing, indirect put-downs, not responding, subtle manipulation and guilt
- Recognizing the form of anger is a step toward understanding its underlying suffering
**100% Responsibility**
- Defined not as responsibility for the other person's behavior, but as the full capacity to respond wisely and kindly to what arises within oneself
- The corollary: fixating on blame disempowers the self
- Framed as an empowering and liberating attitude
- The source of emotional suffering is located inside oneself, not in the external trigger
**The U-Turn**
- When triggered, the practice is to turn attention inward rather than outward
- Pausing allows reconnection with deeper intention: the desire for understanding, connection, and met needs
- Andy's personal story with his son Narayan: pausing during a moment of rage over dishonesty, discovering grief underneath, and communicating from that place rather than from anger
- This shift in communication changed the dynamic significantly
**Nonviolent Communication (NVC)**
- Drawn from the NVC framework, presented as synergistic with mindfulness and compassion
- Basic formula: "When [objective description of event], I felt [emotion] because I need [need]."
- Emphasis on describing events objectively without added judgment or interpretation
- Example: "When I heard that you discussed my mistake at a meeting I hadn't attended, I felt angry because I need to feel trust and understanding and respect."
- Andy and Jonathan's story: correctly applying NVC language without embodying the underlying feeling produced zero empathy and a sense of distance; only after each did their own internal U-turn and got in touch with real feelings did the communication bridge the gap
- Conclusion: unless the pause and inward process happen first, the words alone cannot bridge the gap; energy of blame pushes people apart
**Conflict as Connection**
- {{Speaker_2}} noted that for some families, conflict was the primary or only mode of connection
- Conflict, though distorted, is still a form of connection
- In couples therapy, {{Speaker_2}} would begin by having partners find a physically comfortable distance before attempting to speak about vulnerability or upset
**Spiritual Communities and Conflict Avoidance**
- {{Speaker_2}} observed that spiritual communities are almost universally conflict-avoidant
- Spirituality is often used as a bypass to avoid the messiness of interpersonal conflict
- Spiritual communities are not recommended as models for learning to work with conflict
**The Men's Movement Approach**
- {{Speaker_2}} described work with Robert Bly, Michael Mead, Luis Rodriguez, Maladoma, and others
- Conflict was welcomed; dedicated time was set aside for people in conflict to come forward and speak
- Only rule: no physical contact, but anything could be said
- Maladoma's initiation ritual: placed in a circle of ash for three days and nights while village members were invited to insult him
- Insult contests at men's retreats: standing in the center and inviting insults, described as liberating in facing shame and fear of exposure
- Framed as learning to deal with the energy of conflict and play with it
**Collective and Global Peacemaking**
- {{Speaker_2}} referenced peacemaking work in Burma, Palestine, and Israel
- Effective peacemakers use the same principles: sitting down, listening, expressing what was felt and what is needed for safety
- The notion that war is an acceptable way to resolve conflict was described as old
- The acceptance of slavery internationally has declined, cited as evidence of collective moral evolution
- The tools of mindfulness and compassion are seen as relevant both intimately and collectively
### Spiritual and Societal Insights
**Anger, Suppression, and Cultural Conditioning**
- Dominant cultures often send the message that anger — particularly from marginalized groups — must be suppressed for safety and acceptance
- Ta-Nehisi Coates highlighted the specific burden placed on African Americans to be twice as good and not show anger
- This suppression runs counter to the natural human response to violation of basic needs
**The Evolutionary and Neurological Context**
- The development of the frontal cortex represents an evolutionary capacity for collaboration, empathy, and perceiving others' deeper intentions
- Despite this, limbic reactivity remains, as evidenced by ongoing global threats such as nuclear risk and environmental destruction
- The work of managing anger is framed as part of humanity's ongoing evolutionary challenge
**Anger as Weather**
- Anger is described as a weather system — it has intelligence and function within the human being
- Like weather, it is not inherently good or bad; it is information
- The problem arises when one becomes possessed by it, leading to projection and separation
**The Distance Created by Anger**
- The master-disciple teaching: people shout when angry because their hearts have distanced; the greater the distance, the louder the shout
- In contrast, people in love speak softly because their hearts are close
- Teaching is framed as guiding students from reacting from a small, contracted sense of self to responding from a more whole sense of being
**Spiritual Bypass**
- Spiritual communities frequently use spiritual practice to avoid engaging with conflict and emotional messiness
- This is named as a pattern to be aware of rather than emulated
**Collective Responsibility and Peacemaking**
- The same interpersonal tools — mindfulness, compassion, expressing feelings and needs — are applied by peacemakers in conflict zones globally
- The work done in intimate relationships is connected to the larger work of collective peace
### Quotes
- "The coldest winter ever... they learned to live with the wounds that were caused by the closest relationships with their companion, but the most important part of it was the heat that came from the others that enabled them to survive together the coldest winter ever." — Andy McGuire
- "Speak when you're angry and you'll make the best speech you'll ever regret." — Andy McGuire, attributing Lawrence Peter
- "Getting angry with another person is like throwing hot coals with bare hands. Both people get burned." — Andy McGuire, attributing the Buddha
- "An eye for an eye makes the whole world blind." — Andy McGuire, attributing Gandhi
- "When two people are angry at each other, their hearts distance a lot. So to cover that distance they must shout to be able to hear each other." — Andy McGuire, from a master-disciple teaching
- "I bark at everything, you can't go wrong that way." — Andy McGuire, from a cartoon
- "My grandkids were relieved to hear that I was on my way today to a temper modification program called meditation... Sitting in silence I reconnect life's scattered pieces." — Andy McGuire, quoting a grandmother's poem
- "If you yell, if you're demeaning, if you're drinking when I'm around, I'm gone." — Andy McGuire, quoting a young woman client
- "Is this a private fight or can anybody join?" — {{Speaker_2}}, quoting Michael Mead
- "Anger and conflict was the main way that my parents connected... conflict is a form of connection. It might be distorted, but it is." — {{Speaker_2}}
- "In spiritual communities they are almost universally conflict avoidant... people kind of do the bypass and go to spirituality so that they don't have to deal with the messiness of the world." — {{Speaker_2}}
- "The notion that killing people in war is an acceptable way of solving conflict is old." — {{Speaker_2}}
### Stories
**The Porcupine Parable**
- Shared by Andy McGuire as an opening teaching story
- Porcupines facing the coldest winter choose between isolation and death or togetherness and the pain of each other's quills; they choose togetherness and learn to live with the wounds for the sake of the warmth
**The Grocery Store Mother**
- Shared by Andy McGuire
- A man observes a mother calmly talking a child named Ellen through a grocery store, repeatedly soothing the child through cookie, candy, and gum aisles; at the end the mother clarifies her daughter's name is Tammy — she herself is Ellen
- Used to illustrate personal self-control strategies
**The Young Woman and Her Abusive Father**
- Shared by Andy McGuire from his own clinical work
- A woman in her mid-twenties was unable to create distance from her alcoholic and abusive father and was re-traumatized repeatedly; through mindfulness and self-compassion she gradually acknowledged her rage, which gave her the intelligence to set clear boundaries; unprocessed rage later hardened into victimhood in her next relationship, requiring deeper work to reach the grief underneath
**Andy and His Son Narayan**
- Shared by Andy McGuire about his own personal experience
- Andy was triggered by his son's dishonesty, recognized that acting from rage would not help, gave them both a timeout, checked in with himself, discovered grief underneath the anger about the distance dishonesty creates, and communicated from that place; his son was thrown off balance by the vulnerability and the dynamic between them changed significantly; Andy confirmed the story with his son two weeks before the session
**Andy and Jonathan — NVC Practice**
- Shared by Andy McGuire about his relationship with Jonathan
- Early in their relationship they had established morning check-ins; Jonathan scheduled something that cut into that time, triggering Andy; they attempted NVC but both still felt distant and blamed each other despite using correct language; after a 24-hour timeout and individual U-turns, each got in touch with their real underlying feelings and needs, and when they repeated the NVC from that embodied place, they were able to bridge the gap
**The Couples Therapy Safe Distance Exercise**
- Shared by {{Speaker_2}} from his years as a therapist doing couples work
- He would ask warring couples to find a physically comfortable distance before speaking; one woman left the room, slammed the door, and cracked it open just enough to see her partner — that was her safe distance
**{{Speaker_2}}'s Parents**
- Shared by {{Speaker_2}} about his own family of origin
- Conflict was the primary way his parents connected; they often could not connect any other way
**Maladoma's Initiation**
- Shared by {{Speaker_2}}, referring to Maladoma Somé, a West African elder from Burkina Faso
- During his elder's initiation, Maladoma was placed in a circle of ash and was not allowed to leave for three days and nights while village members were invited to come and insult him
- Used as context for the insult contests held at men's retreats
**Insult Contests at Men's Retreats**
- Shared by {{Speaker_2}} from his work with the men's movement with Robert Bly, Michael Mead, Luis Rodriguez, and Maladoma
- Participants could voluntarily stand in the center and invite others to insult them freely; described as liberating in confronting shame, fear, and the terror of being truly seen
**Michael Mead and Conflict Hour**
- Shared by {{Speaker_2}}
- At intense multi-year retreats, time was set aside called conflict hour where anyone in conflict could come to the center and speak; the only rule was no physical contact; Michael Mead, who grew up as a street tough in Brooklyn, actively welcomed and was interested in conflict
### Physical, Mental Challenges, Affects on Practice
- Limbic reactivity described as an ongoing challenge even for those with mindfulness training; the frontal cortex capacity does not eliminate reactive patterns
- The young woman client experienced anxiety and depression as a result of suppressed rage and repeated re-traumatization by her father; gradual exposure to the rage through mindfulness was necessary because the feelings were experienced as dangerous
- Deep cultural and personal conditioning around anger — particularly the belief that it is dangerous to feel or show anger — is identified as a significant barrier to working with it skillfully
- The belief "I'm not lovable" identified by Andy as an underlying core wound surfacing during conflict with Jonathan, triggered by the fear of lost closeness
- {{Speaker_2}} noted that fear of being seen, shame, and embarrassment are common responses to the prospect of conflict or exposure
- Spiritual bypass — using spiritual practice to avoid emotional and relational messiness — identified as a pattern that impedes genuine engagement with conflict and anger

