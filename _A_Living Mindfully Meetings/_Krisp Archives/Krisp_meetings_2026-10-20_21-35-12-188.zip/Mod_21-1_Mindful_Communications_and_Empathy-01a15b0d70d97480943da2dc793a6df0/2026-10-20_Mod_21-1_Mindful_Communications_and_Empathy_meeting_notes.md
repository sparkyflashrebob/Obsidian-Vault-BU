# Mod 21-1 Mindful Communications and Empathy - Oct, 20

### Mindful Communications and Empathy
📅 October 20, 2026
👥 Main Teacher: Andy McGuire (Tara), Co-Teacher: Jack Kornfield
Tags: Mindful Communication, Wise Speech, Empathy, Shadow Work, Gossip, False Speech, Compassion, Limbic System, Attend and Befriend, Mirror Neurons, Presence, Interpersonal Relationships, Spiritual Practice
### Outline
### Overview of Mindful and Heartful Communication

- This session focuses on recognizing and undoing patterns of communication that create separation, as well as cultivating empathy in interpersonal interactions.

- Explored alongside previous sessions on group-level communication, generosity, and gratitude, this topic is presented as an interrelated and equally valuable domain of practice.

- A central question addressed is how practitioners can bring presence and kindness into their relationships, especially under stress, after training in mindfulness and compassion in silent or protected settings.

- Deeply grooved patterns of communication mirror deeply grooved thought patterns, and both require dedicated attention and training to transform.

### The Role of Attitude in Approaching Wise Speech

- Wise speech is best introduced not as a rigid set of rules or a domain for self-judgment, but as an adventure that opens unexpected possibilities for connection and creativity.

- Rather than creating self-consciousness or reducing spontaneity, bringing mindful attention to communication actually makes genuine spontaneity possible.

- Pema Chodron's teaching is cited to illustrate that the goal is not to save the world, but to wonder how others are doing and reflect on how one's actions affect other people's hearts.

- Rumi's teaching is offered as a guiding frame, suggesting that instead of seeking love, one should seek and find all the barriers created against it, and then embrace them with kindness.

### The Impact of Words and the Quality of Presence

- Two core teachings organize the approach to mindful communication, the first being an awareness of how words carry power to invoke either harm or healing.

- The second teaching holds that the impact of words is ultimately determined by the quality of presence from which they are spoken.

- When communication arises from the ego's fight-flight-freeze mode of protecting and furthering the self, it tends to perpetuate separation.

- Shifting toward a state of attend-and-befriend, rooted in a sense of interbeing, allows speech to serve life and express genuine care.

### False Speech and the Pervasiveness of Deception

- False speech encompasses all the ways people exaggerate, omit information, pretend, or mislead, and it operates largely below the threshold of conscious awareness.

- Research indicates that small lies are embedded even in ordinary conversations where deception would seem unnecessary, reflecting how deeply ingrained this behavior is.

- Deception is identified as one of the most primitive evolutionary survival tools, observable across species through camouflage, mimicry, and misdirection.

- In human behavior, deception most commonly serves the purpose of gaining approval and concealing what one fears will bring disapproval, creating a persistent mechanism of self-presentation over authentic being.

- Each moment spent presenting a curated version of oneself in order to elicit a desired response generates separation rather than genuine connection.

### Reflection on Self-Presentation and the Creation of Distance

- A guided reflection invites participants to bring to mind someone whose opinion matters to them and to notice what they want that person to see and what they wish to conceal.

- Attention is directed toward how communication is shaped to manage impressions and what quality of connection or separation arises from that shaping.

- Imagining entering the same interaction without those protective behaviors opens a sense of what becomes possible when authentic presence is allowed.

- Robert Johnson's concept of shadow vows is introduced to illustrate how naming and unmasking the shadow behaviors in relationships can place people ahead of the game in navigating them honestly.

### Compassion as a Foundation for Changing Communication Patterns

- Teaching wise speech requires cultivating tremendous compassion for all the unwise ways people navigate their interactions, because without that compassion, access to real presence is blocked.

- The second arrow, meaning the self-judgment layered on top of reactive behavior, is identified as a significant obstacle to growth in communication.

- Gossip is examined as a deeply ancient and widespread human behavior that has historically served social functions such as building trust and sharing information about safety.

- Jack Kornfield adds that gossip exists on a spectrum, with some forms being genuinely harmful and others serving a legitimate social bonding function, and that mindfulness requires discernment rather than a blanket judgment.

- Adrienne Rich's reflection on honorable relationships is cited to frame authentic communication as a process of deepening the truths two people can tell each other, which breaks down self-delusion and isolation.

### Steps for Shifting Communication Patterns Toward Authentic Presence

- The first practical step in shifting communication patterns is to pause whenever a familiar reactive pattern is sensed, and to meet it with compassion rather than judgment.

- Setting an intention before engaging in a conversation, such as noticing a tendency to impress or to keep distance, is offered as a preparatory practice.

- Reviewing a past interaction after the fact, recognizing the pattern that played out, and mentally redoing it to explore how it could have unfolded differently is presented as a valuable training method.

- Deepening attention involves investigating both the active intention in a moment of unwise speech and the actual outcome or impact it produced.

- From there, the practice moves to identifying one's deepest intention and the outcome genuinely desired, which then informs how one might re-enter a similar situation more authentically.

- When a person cannot access their deepest intention, it is a signal that an unhealed wound or unresolved emotion requires attention first, and staying with that anger or pain is the necessary step before moving forward.

### Cultivating Empathy Through Listening Presence

- Empathy is described as a natural human capacity rooted in mirror neurons and the relational functions of the frontal cortex, which allow for attunement, emotional resonance, and sensing another's inner state.

- What disrupts this natural empathic capacity is the grip of self-concern, fear, and wanting, which pulls attention away from the other person and back into protective self-focus.

- All communication training is grounded in the prerequisite of deepening presence, as described through the example of a social worker whose patient listening and willingness to wait created the conditions for a homeless veteran to choose recovery.

- Jack Kornfield emphasizes that the ability to listen and wait in conversation, trusting silence rather than filling it with words, is one of the most powerful gifts a teacher or companion can offer.

- Empathy can be conveyed non-verbally through facial expression and posture, and does not always require words or action to be felt by another person.

- Henri Nouwen's reflection is cited to articulate that the people who matter most in one's life are often those who chose to share pain and sit in silence rather than offer advice or solutions.

- Expressing empathy verbally also carries significant power, as the moment another person feels genuinely heard and understood can shift the entire quality of an interaction, a principle recognized even in high-stakes contexts such as FBI hostage negotiation.

### Next Steps

- The session is positioned as a foundation for expanding the exploration from undoing patterns that create distance toward actively cultivating the presence that enables empathy.

- Andy McGuire signals a transition to the next phase of teaching, inviting Jack Kornfield to contribute further reflections on the patterns of distance before moving into the empathy component.

- The reflective exercises introduced, including the self-presentation inquiry and the intention-and-outcome review, are framed as teachable practices that participants can bring into their own group facilitation and instruction.


### Key Points, Subjects and Themes
- Recognizing and undoing patterns of communication that create separation
- Teaching mindful, heartful communication as a practice and training
- The acronym WAIT — Why Am I Talking — as a tool for mindful speech
- The challenge of bringing retreat-level presence into everyday relationships
- Deeply grooved communication patterns and how they reconfigure after retreat
- Reverence for life as the ground level of mindful communication
- Limbic patterning — fear and wanting — as the root driver of unwise speech
- False speech: exaggeration, omission, pretense, and lying as survival mechanisms
- Deception as an ancient evolutionary tool embedded in human and animal behavior
- Seeking approval and covering disapproval as primary motivations for false speech
- Shadow vows and the importance of shining light on unconscious communication patterns
- The second arrow — self-judgment for having reactive communication patterns
- Gossip: its ancient social function and its role in creating distance
- Steps for shifting communication patterns: pause, notice with compassion, investigate intention and outcome
- The distinction between active intention and deepest intention
- Empathy as a natural capacity rooted in mirror neurons and the relational frontal cortex
- Non-verbal empathy: presence, facial expression, posture
- The power of listening, waiting, and trusting silence in conversation
- Feeling heard as a transformative moment in relationships and negotiations
- Healthy versus unhealthy gossip as a nuanced distinction
### Detailed Subject Matter
**Bringing Mindfulness into Communication**
- The session focuses on mindful, heartful communication and how to recognize and undo patterns that create separation
- A common question from students coming out of retreat is how to bring presence and kindness into relationships, especially under stress
- Mindfulness training typically occurs in silent, protected settings and is rarely challenged by interactive stressors
- Communication patterns are as deeply grooved as thought patterns and reconfigure quickly when returning to ordinary life
- The birthday candle metaphor illustrates how personality reasserts itself after retreat
**Attitude Toward Wise Speech**
- The first step in teaching wise speech is addressing attitude — framing it as adventure rather than encumbrance
- Wise speech is not a rigid set of rules or a domain for self-judgment
- Bringing attention to communication patterns frees unexpected possibilities for connection and creativity
- Mindful communication increases rather than diminishes spontaneity
**False Speech and Deception**
- False speech includes exaggerating, omitting information, pretending, and lying
- Much deception operates below the line of consciousness and is pervasive even in ordinary conversation
- Research shows many small lies are embedded in everyday conversations where lying seems unnecessary
- Deception is one of the earliest and most primitive evolutionary survival tools
- Animal examples cited: viruses and insects camouflaging, cats raising hair, butterfly fish with false eyes, garter snakes emitting false pheromones to attract warmth from mating balls
- Human deception most commonly functions to gain approval and cover what might bring disapproval
- Presenting a curated self to get a desired response creates separation in the moment it occurs
**Shadow Work in Communication**
- Robert Johnson's Shadow Vows essay illustrates how unconscious relational patterns surface inevitably in close relationships
- Recognizing and naming the shadow puts people ahead of the game
- The second arrow — judging oneself for reactive or unwise communication — must be addressed with compassion
- Teaching wise speech requires teaching tremendous compassion for all the unwise ways people navigate
**Gossip**
- Gossip has played a key role in human societies from earliest times as a way of sharing and controlling information
- In more complex societies, gossip helped people determine who could be trusted
- Gossip creates distance and can be hurtful, but it is deeply embedded in human communication
- One person's experiment of eliminating all talk about absent others revealed that approximately 95% of his communication was cut off
- Jack Kornfield noted that healthy gossip exists — for example, warning others about unsafe individuals — and that a nuanced, attentive approach is needed rather than a blanket judgment
**Steps for Shifting Communication Patterns**
- Set intention before engaging in contact by noticing tendencies in advance
- Practice noticing patterns during conversation, though this is difficult
- Most commonly, patterns are recognized after the fact; mentally redoing the exchange builds new inclinations
- Steps: pause when sensing patterning, notice the pattern with compassion, investigate active intention and outcome, identify deepest intention, listen
- If a person cannot access their deepest intention, it signals an unhealed wound or unresolved emotion that needs attention first
- The process is not cut and dry; sometimes a real tangle requires more time before re-entry is possible
**Empathy**
- Empathy is a natural capacity rooted in mirror neurons and the relational part of the frontal cortex
- The brain is wired to attune to others, sense intentionality, and resonate emotionally
- What blocks empathy is self-concern, fear, and wanting
- Empathy can be expressed non-verbally through facial expression and posture — it does not require words or doing
- The prerequisite for expressed empathy is a listening presence
- FBI hostage negotiators confirm that everything turns on the moment a person feels heard
- Feeling understood or heard changes everything in a relationship or negotiation
### Spiritual and Societal Insights
**Reverence for Life as the Foundation**
- The ground level of mindful communication is a reverence for life, a desire to serve understanding and connection, and a real honoring of the life present
- Most communication is torqued on some level by fear and wanting, making dedicated attention necessary
**Evolutionary and Societal Context of Communication**
- The shift from fight-flight-freeze to attend-and-befriend represents a movement from ego-protective communication to communication that serves life and expresses love
- Deception is not a moral failing unique to individuals but a deeply embedded evolutionary mechanism shared across species
- Gossip has served genuine social functions throughout human history and requires discernment rather than blanket condemnation
**The Path from Separation to Connection**
- Rumi's teaching: instead of seeking love, seek and find all the barriers created against it, then embrace them
- Pema Chödrön: we do not set out to save the world; we set out to wonder how other people are doing and reflect on how our actions affect other people's hearts
- Adrienne Rich: an honorable human relationship is a process of deepening the truths two people can tell each other, which breaks down self-delusion and isolation
- Mark Nepo describes authentic communication as taking the exquisite risk — beautiful, raw, tender, and vulnerable, yet increasingly motivating as connection deepens
**Empathy as Spiritual Practice**
- The four-year-old child who sat with a grieving neighbor and said he just helped him cry illustrates that empathic presence requires no words
- Henri Nouwen's reflection identifies those who share pain and touch wounds with a warm hand — who can be silent in despair, tolerate not knowing, not curing — as the friends who truly care
- Listening and waiting, trusting silence, and not hurrying the other person or oneself is described as a great gift in conversation
### Quotes
- "Why am I talking?" — Andy McGuire, on the acronym WAIT
- "We don't set out to save the world. We set out to wonder how other people are doing and to reflect on how our actions affect other people's hearts." — Andy McGuire, quoting Pema Chödrön
- "Instead of seeking for love, seek and find all the barriers we've created from it. And then embrace them." — Andy McGuire, quoting Rumi
- "An honorable human relationship — that is, one in which two people have the right to use the word 'love' — is a process of deepening the truths they can tell each other. It's important to do so because it breaks down human self-delusion and isolation." — Andy McGuire, quoting Adrienne Rich
- "When we honestly ask ourselves which person in our lives means the most to us, we often find that it is those who instead of giving advice or solutions or cures have chosen rather to share our pain and touch our wounds with a warm and tender hand. The friend who can be silent with us in a moment of despair or confusion, who can stay with us in an hour of grief and bereavement, who can tolerate not knowing, not curing, not healing, and face us with the reality of our powerlessness, that is a friend who cares." — Andy McGuire, quoting Henri Nouwen
- "I didn't say anything, mama. I just helped him to cry." — Andy McGuire, quoting a four-year-old child in a story
- "Yes, I understand, it must have felt awful." — Andy McGuire, recounting words spoken to her as a child of five or six
### Stories
**The Book Signing and the Name — Andy McGuire**
Andy shares a personal story about struggling to remember names, a pattern that worsens with anxiety. During a book signing tour for True Refuge, he developed a strategy of asking people how to spell their name to avoid revealing he did not know it. At a signing in Bethesda, a woman he knew well and cared for deeply stood before him and he went completely blank. He asked how she spelled her name and she replied J-A-N-E. They laughed and he confessed his strategy. Intending to write a loving inscription, he then accidentally wrote Dear Bob. He uses this story to illustrate how covering up creates distance and to invite reflection on what genuine connection might have been possible without the pretense.
**The Shadow Vows — Andy McGuire, sourcing Robert Johnson**
Andy recounts a short essay by Robert Johnson in which a couple, the night before their wedding, holds a ritual to speak their shadow vows aloud. The groom vows to give the bride an identity and make the world see her as an extension of himself. The bride vows to be compliant and sweet on the surface while holding real control underneath, and to take his money and house if things go wrong. They drink champagne and laugh at their foibles, knowing these shadow figures will inevitably emerge. Andy uses this to illustrate that naming the shadow puts people ahead of the game.
**The Gossiping Sheep — Andy McGuire, attributed to Jack Kornfield or Jeff**
Andy recounts a cartoon or story involving sheep. Two sheep are off in a corner gossiping about a third sheep out in the field. They are saying that every time she comes back from being sheared, she cannot stop talking about how vulnerable she feels. Andy uses this to illustrate how gossip functions to create a sense of superiority and to bond with the person one is speaking with.
**The Homeless Veteran — Jack Kornfield**
Jack shares a story of a social worker's encounter with a homeless army veteran who was cold, hungry, and smelled of alcohol despite having tried to clean up before coming to the social services department. The veteran asked only for a few dollars and bus tickets to get sober enough to enter a shelter with 50 beds in a city of nearly 1,000 homeless people. The social worker listened, waited, and watched his face as he considered the offer of rehab, noting a flicker of hope followed by a shadow of doubt. She asked simply, Shall I? and he barely nodded yes. Six months later he returned to her office tall, handsome, smelling like the outdoors, and holding a large bouquet of flowers. Jack uses this story to illustrate the power of listening, waiting, and trusting silence rather than filling space with words.
**The Four-Year-Old and the Grieving Neighbor — Andy McGuire**
Andy tells the story of a four-year-old child who noticed his elderly next-door neighbor sitting on his porch crying after losing his wife. The child climbed up beside the man and sat with him. When his mother asked what he had said to the neighbor, the child replied that he had not said anything — he just helped him to cry. Andy uses this story to illustrate that empathy can be expressed entirely through non-verbal presence.
**Andy's Childhood Fight and the Empathic Mother — Andy McGuire**
Andy recalls an early memory from age five or six of getting into a regular fight with another girl in her apartment building. When mothers pulled them apart, Andy was upset and kept explaining why she had been wronged. One mother repeatedly said, Yes, I understand, it must have felt awful. Andy recalls knowing even at that age that these words were calming her down, and sensing that even if she was not sure the mother fully meant it, the caring act of saying it made a significant difference. She uses this to illustrate the transformative power of feeling heard.
### Physical, Mental Challenges, Affects on Practice
- Andy McGuire openly discusses a personal challenge with remembering names, describing it as something that has been getting worse over time and that causes anxiety
- The anxiety about forgetting names creates a freeze response, causing Andy to blank even on names of people known for years, including board members and long-term acquaintances
- Andy describes this as embarrassing and connected to a fear of offending people, since having one's name known matters to people and forgetting it can create hurt and distance
- The pattern of covering up the name difficulty is offered as a direct example of how fear-driven concealment creates separation in communication
- Andy notes that coming out publicly about the challenge has removed the option to continue hiding it, framing this as a step toward authenticity
- The broader teaching acknowledges that when people cannot access their deepest intention during reflection, it is a sign of an unhealed wound or unresolved emotion that requires attention before moving forward

