# 20260905-DawnMauricio-SR-morninginstructionsrainwithemotionsandthoughtsretreatatspiritrock-99266 - Oct, 02

Please click the link to download the recording. If it does not work, please copy the link and open it in your browser.

# Recording Download Link

**File:** recording.mp3
**Valid for:** 7 days

[Download Recording](<https://files.krisp.ai/downloads/?f=Xq0qbmf6y2mQcPTOGnhUmBygHWWzDczlQTD6jjvKf2wYzDylEMJJvmscZ4xjOyx9qEtjRwmJUW%2FCiM0aW5GNhhe5qDlw2ejb5CaeTXk8MzM18T23FVX1PpJE5L3QZWmr9QtRwOwUf9zjvH71kF99Q5tf7Sgi%2B%2BU%3D&Expires=1791619575&Key-Pair-Id=K4KB1ESSQ567P&Signature=sghlbdUXQ1pJRZ3okB7x5CHO67MoQOvYvK6w-JlL7A2jJj63zaoI5uB9WjQO8HmdO2CnJLEs746eELeocAIkOwIpZObBUFgICI1t6J7~dovT7z-A0nxRA-IoKFtpjAALZhCipq2cOB7mE8nOhGNhNXiy3HjczG5YbK3nmFzTZEY2v2JwKeApgqiWpbIYDhplph~~C7-5p4ryp~sT9xXPbSjZ6XK7USptqueRs0uYG0M5cc5GQ5Rcw0b6nHzaTef9ev4PUktUjEDn4TMQHKAT5uS6YlPr9BWDUVr31c4jK2EMYnXhwXiFN6eQqc~zIhFvnGmNnkWM6ltQbTo11akqJw__>)