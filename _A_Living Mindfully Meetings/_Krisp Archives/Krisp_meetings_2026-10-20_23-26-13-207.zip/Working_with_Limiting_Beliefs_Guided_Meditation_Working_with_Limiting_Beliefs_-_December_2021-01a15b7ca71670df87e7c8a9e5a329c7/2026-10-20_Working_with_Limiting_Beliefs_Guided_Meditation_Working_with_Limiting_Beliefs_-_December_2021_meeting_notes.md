# Working with Limiting Beliefs  Guided Meditation Working with Limiting Beliefs - December 2021 - Oct, 20

### Working with Limiting Beliefs — Guided Meditation
📅 October 20, 2026
👥 Main Teachers: Tara Brach, Jack Kornfield
Tags: Limiting Beliefs, Mindfulness, RAIN Practice, Compassion, Fear-Based Thinking, Identity, Meditation, Teacher Training, Conflict Resolution, Inner Inquiry
### Outline
### Introduction to the Mindfulness Teacher Training Podcast Series

- Created as a special podcast series, this collection draws from the best wisdom teachings of previous years of the teacher training program.

- Listening without watching a screen is presented as an effective way to open, receive, and learn, as the wisdom shared is described as timeless.

- References to time within the recordings are acknowledged, with the assurance that the truths being shared remain universally relevant.

### The Nature of Thoughts and the Capacity for Witnessing Awareness

- A foundational concept introduced is that humans have a natural tendency to continuously generate thoughts, alongside an equally natural capacity to recognize and witness that process.

- Resting in a larger space of presence, rather than being consumed by thought, is described as the essential skill of stepping out and reconnecting with what is actually here.

- A brief reflective exercise is offered in which participants are guided to recall a recent pleasant conversation and then observe the thoughts and mental imagery that arose from it.

- Recognizing mind movies, and sensing the awareness that witnesses them, is presented as relatively accessible when the thoughts carry no emotional charge.

### How Charged Thoughts and Core Beliefs Create Identification

- When a thought carries emotional valence or charge, identification with it becomes much stronger, making it significantly harder to access witnessing awareness.

- Deep identification with a thought is described as a signal that a core belief is present, representing a fundamental way a person has made sense of reality and their own identity.

- These core beliefs are understood to feed and sustain the ongoing stream of fear-based thinking that keeps individuals mentally and emotionally trapped.

- Humans are described as highly tenacious about their views, with a strong attachment to being right that makes it difficult to acknowledge when one's perspective may be mistaken.

### The Role of Teachers and Conscious Leaders in Relieving Belief-Based Suffering

- Mindfulness teachers and conscious leaders are positioned as uniquely capable of addressing the suffering caused by beliefs that create deep internal and interpersonal division.

- Two primary categories of harmful belief are identified, namely the belief that something is wrong with oneself and the belief that something is wrong with others.

- Much of human life is described as organized around a background sense that something is fundamentally wrong with the self, and relieving that suffering is framed as central work.

- Increasingly polarized times, marked by toxicity and violence rooted in divisive beliefs, are cited as the broader context that makes mindfulness and compassion practices urgently needed.

- Bringing practices that unpack fear-based beliefs is described as an extraordinary service to the world, particularly in the context of conflict between peoples of difference.

### The Building Bridges Story as an Illustration of Waking Up from Beliefs

- A group called Building Bridges is described as bringing different peoples together to have conversations that allow genuine mutual understanding to emerge.

- In one example, twenty-two teenage girls from Israel and Palestine were brought to a rural camp in New Jersey to examine the beliefs central to their identities that had fueled cycles of estrangement and violence.

- A Palestinian girl shared how Israeli soldiers had wrongly entered her family's home, beaten everyone, and left without apology, and an Israeli teen was then asked to retell the story in the first person, including the feelings of rage and terror.

- After hearing her story retold, the Palestinian girl wept and said "my enemy has heard me," and the two girls cried together and became close friends.

- One Israeli participant summarized the insight by saying that if she does not know someone, it is easy to hate them, but if she looks into their eyes, she cannot.

- This story is presented as capturing the essence of how waking up from delusional beliefs requires looking directly into the truth of the other or into the truth within oneself.

### The Origins and Function of Core Beliefs

- Beliefs are normalized as an evolutionary feature of human cognition, with the survival brain oriented toward protecting and promoting, and the frontal cortex constructing maps to navigate reality.

- The brain is described as designed to predict the future based on the past and biased toward encoding experiences of endangerment, which means many core beliefs grow from fear.

- Memory is characterized as Velcro for painful experiences and Teflon for pleasant ones, which helps explain why fear-based beliefs tend to dominate.

- Core beliefs about the self and the world are said to originate from earliest hurts and fears, as well as from the cultural milieu passed down through generations.

- An example is given of a young child whose attempts to get needs met are repeatedly frustrated, leading to adult beliefs such as "I am too needy," "people won't love me," or "no one wants to spend time with me."

- Although these beliefs originate in the past, they are experienced as entirely current and immediate, and the behaviors they generate tend to produce responses that reaffirm them, creating self-reinforcing loops.

### The Looping Relationship Between Beliefs, Thoughts, Emotions, and Behavior

- Fear-based beliefs are described as generating fear thoughts such as worrying, planning, and obsessing, which in turn keep stirring up physical feelings in the body.

- Emotions, when left on their own, are noted to last approximately ninety seconds according to neuroscientist Jill Bolte-Taylor, following a trajectory of arising, peaking, and dissipating.

- Continued thinking prevents emotions from completing their natural cycle, locking individuals into prolonged moods rather than allowing feelings to pass.

- Gandhi's formulation is cited to illustrate the chain in which belief creates thought, thought creates feeling, feeling and thought together create behavior, and behavior creates destiny.

- Hildegard de Bingen's concept of the "interpreted world" is introduced, with the observation that an interpreted world is not a home, pointing to the alienation caused by living inside mental constructions.

- The phrase "all sickness is homesickness," drawn from Diane Connolly's book, is offered as a poetic expression of the suffering that arises when fear-based thoughts imprison awareness in a virtual reality.

### Experiential Exercise on the Power of Words and Thought Environments

- A guided exercise is offered in which participants are invited to let the word "trouble" appear on a mental screen, whisper it internally, and notice what arises in the body, particularly in the throat, chest, and belly.

- After clearing that word, participants are then invited to let the word "kindness" appear and notice how that word lives differently in the body.

- The exercise is designed to illustrate that whatever one practices gets stronger, and that the core beliefs present in a person generate a particular kind of mental and physical environment.

- The observation is made that much of ordinary mental life resembles a television switching uncontrollably between channels, with a disproportionate amount of content resembling worry rather than gratitude or appreciation.

### The Distinction Between the Map and Reality

- Students are noted to commonly ask whether beliefs and mental representations are necessary, and the answer given is that they are, as they enable human creativity, navigation, and continued evolution.

- For consciousness to evolve and for freedom from suffering to be possible, knowing the difference between the map and the reality is described as essential.

- Sogyal Rinpoche's phrase "real but not true" is introduced as a particularly helpful framework, conveying that thoughts and feelings are real in the sense that they are genuinely occurring, but they are not the truth of what is actually present.

- Even good maps are acknowledged as not being the living truth, since any mental representation necessarily reduces a dynamic, living reality to a fixed concept.

- Many maps, especially those arising from fear, are described as attempts to grasp certainty and make the world feel secure and reliable, rather than accurate reflections of reality.

- A cultural belief that aggression and willingness to fight are what make leaders effective is cited as an example of a map that is widely held but not necessarily true, with mindfulness and acceptance mistakenly equated with passivity and weakness.

### Using the Question "What Are You Believing?" as a Teaching Tool

- When someone is suffering, asking "what are you believing right now?" is presented as a powerful way to begin inserting a wedge between the person and their identification with the belief.

- Anything outside of awareness is described as having the power to hook a person, and there is always a belief operating when suffering is present.

- A beliefs inventory is referenced as a practical resource for students to examine which cluster of beliefs may be most confining their lives.

- Commonly occurring beliefs listed include needing to work hard for approval or love, not being worthy of love, not deserving happiness, expecting to be hurt by those one gets close to, and needing to be different in order to be good enough.

- Examining family and cultural beliefs is recommended as a way of tracing the origins of one's own beliefs, including beliefs about what makes a person good or bad, and about the relative worth of different categories of people.

### The U-Turn Practice and Sensing the Difference Between Thought and Reality

- The U-turn is described as a practice of redirecting awareness from outward-facing thought and mental movies back to the lived, immediate experience of the body and senses.

- This metaphor is noted as particularly resonant for students because it provides a visual and kinesthetic sense of returning to what is right here.

- Repeated rounds of coming back through the U-turn are said to build a felt sense of the difference between thought and vivid immediate reality, which begins to free students from identification with their beliefs.

- A guided exercise is offered in which participants bring to mind someone they know and care about, first noticing the thoughts, images, and associations that arise, and then making the U-turn to sense the aliveness of the body and the presence behind the thoughts.

- The reflection is offered that the person being contemplated may be more like a changing, unfolding expression of presence than any fixed idea one holds about them, illustrating the principle of real but not true.

### Applying RAIN to Stuck Beliefs

- When beliefs are emotionally charged, the U-turn alone is described as insufficient, and a more applied meditation practice is needed to work with the tangle directly.

- RAIN, standing for recognizing, allowing, investigating, and nourishing, is presented as the framework for bringing mindfulness and compassion to a stuck belief.

- A case example is shared of a successful doctor and popular medical conference presenter who came seeking help for chronic anxiety, stress, and acid reflux that intensified when he was traveling and approaching presentations.

- The RAIN process began with recognizing the anxiety and allowing it to be present as a distinct fear, with the guiding question being "what is asking for attention."

- During investigation, the doctor's core belief emerged as "at some point I am going to fail," accompanied by fears of not being prepared enough, falling short, and being humiliated, which was identified as imposter syndrome.

- Asking "is this really true, or might this be real but not true?" is described as powerful because the very act of questioning introduces doubt into the belief's claim to be absolute truth.

- Asking how the belief feels in the body is emphasized as a critical step because it brings the person into direct contact with the suffering the belief is causing, rather than keeping the inquiry purely cognitive.

- The doctor described a clutch in the gut, a sinking feeling, a sense of shame, and a stabbing fear of being exposed as the physical experience of living with the belief.

- Widening the lens to ask how living with this belief has affected one's life over time is described as producing a kind of soul sadness when the person begins to see the full landscape of what has been lost or constrained.

- The question "what does this vulnerable place most need?" is identified as the gateway to the nourishing phase, where healing and care are brought to the most tender part within.

- For the doctor, what was needed was trust in his own goodness and the sense that his heart genuinely wanted to be helpful in the world, which he offered to himself through the image of his wise self placing hands on the shoulders of his frightened self.

- After completing RAIN, resting in the presence that has been activated is described as essential, because that open, clear, tender awareness is identified as who one truly is.

- The question "who would you be if you didn't believe there was anything wrong with you?" is offered as a powerful closing inquiry, with the doctor responding with words such as buoyant, spacious, light-filled, and vibrant.

### The Alchemy of Compassion and Why Cognitive Argument Cannot Loosen Beliefs

- Cognitively arguing against a fear-based belief is described as counterproductive, as it tends to increase the grip of the belief rather than loosening it.

- Bringing a person into their body while they are stuck in a fear-based belief is identified as the necessary condition for beginning to loosen identification, because the body is where the suffering is actually being held.

- When a person can sense how much the body and heart are suffering under a belief, sadness naturally arises, which often unfolds into grieving and then into natural compassion toward the vulnerable self.

- This movement from recognition of suffering to compassionate response is described as the alchemy of compassion, the transformative process that makes genuine loosening of identification possible.

### Working with Beliefs in Group Settings

- The same inquiry process used with individuals is described as equally applicable in group settings, including conflict resolution, reconciliation work, and efforts to address implicit racial bias.

- Working with one person in front of a group is noted as a particularly powerful technique, because as that individual opens and softens, others in the group tend to recognize themselves in the process and experience a parallel shift.

- The concept of the "unreal other" is introduced to describe how not knowing someone makes it easy to project fear and hostility onto them, while genuine encounter dissolves that sense of otherness.

- Getting people together to talk to each other is described as essential for dissolving the beliefs that create separation, both within individuals and between groups.

- Undoing the belief that something is wrong with the other, whether in interpersonal or collective contexts, is described as requiring intentionality and sustained practice.

### The Evolutionary and Spiritual Framing of Waking Up from Beliefs

- Evolution is described as having intended for humans to get caught in beliefs as part of the developmental trajectory of consciousness.

- The longing to wake up from limiting beliefs is framed as the awakened heart calling the individual forward, making the intentionality of the practice an expression of something deep and genuine within human nature.

- Nisargadatta Maharaj's statement that illusion exists because it is not investigated is cited to underscore why intentional inquiry is indispensable.

- Elizabeth Lesser's prayer, asking to have the veils removed so as to see what is really happening without being intoxicated by stories and fears, is offered as a poetic expression of the aspiration underlying the entire practice.

- Rumi's verse, in which he describes losing track of the pearl of his soul in the ocean of purling currents after ceasing to believe in himself, is offered as a closing image of what becomes possible when identification with limiting beliefs dissolves.

### Guided Meditation on Limiting Beliefs for Trainee Teachers

- A full guided meditation is offered specifically oriented toward trainee teachers, inviting them to scan for any limiting belief about themselves in the teaching role.

- Participants are guided to make the situation evoking the belief vivid and immediate, seeing their surroundings, who is present, and what they are thinking and feeling.

- The RAIN framework is applied step by step, beginning with recognizing what is happening inside, then allowing it to be as it is, then investigating the core belief and asking whether it is really true or might be real but not true.

- Investigation deepens by asking what it is like to live with the belief, what it feels like in the body, what emotions accompany it, and how it has affected relating to others, to oneself, and to the desire to serve and be creative.

- The inquiry moves to asking what the vulnerable place under the belief most needs, with participants invited to bring hands to the heart or to inhabit their wisest and kindest self and offer whatever care, message, or quality of presence is most needed.

- The meditation closes with the question of who one would be or what life would be like without the belief, followed by a period of resting in the open presence that remains.

### Next Steps

- Trainee teachers are encouraged to continue working with the RAIN framework as a personal practice, particularly when anxiety or self-doubt arises in relation to teaching.

- Reviewing the beliefs inventory provided in the handouts is recommended as a way of identifying the cluster of beliefs most confining one's own life.

- Exploring the work of Byron Katie is suggested as a complementary resource for deepening inquiry into beliefs, with the note that the somatic and compassion dimensions of RAIN extend beyond what that work alone provides.

- Applying the group inquiry process is planned for those who will be working in conflict resolution, reconciliation, or implicit bias contexts, with the understanding that collective belief work requires the same intentionality as individual practice.

- Continuing to develop the capacity to work with individuals within group settings is identified as a key skill, using the presence and opening of one person to catalyze shifts across the whole group.


### Key Points, Subjects and Themes
- The nature of thoughts and how we become identified with them
- Limiting beliefs as core constructs that shape identity and filter reality
- The difference between "real" and "true" in relation to beliefs
- RAIN practice applied to stuck or fear-based beliefs
- The survival brain's role in generating and reinforcing beliefs
- How beliefs loop into emotions, behaviors, and destiny
- The "U-turn" as a practice of returning to lived experience
- Waking up from beliefs that create division between self and others
- The role of mindfulness teachers in relieving belief-based suffering
- Collective and cultural beliefs as sources of division and conflict
- Compassion as the alchemical agent for loosening identification with beliefs
- The importance of embodied inquiry over cognitive argument
- Working with beliefs individually and in group settings
### Detailed Subject Matter
**Thoughts and Identification**
- Thoughts are continuously generated and we have a natural capacity to witness them
- When thoughts carry emotional charge, identification increases and witnessing awareness becomes harder
- Deep identification with a thought signals a core belief is operating
- The phrase "I am not my thoughts" carries significant liberating power
**The Nature and Genesis of Beliefs**
- Beliefs are mental representations or maps of reality, not reality itself
- The survival brain encodes experiences of endangerment; memory is described as Velcro for painful experience and Teflon for pleasant
- Core beliefs originate from earliest hurts, fears, and cultural/family transmission
- Beliefs generate fear-based thoughts such as worrying, planning, and obsessing
- Emotions, if left on their own, last approximately 1.5 minutes; continued thinking prolongs and loops them into moods
**Common Limiting Beliefs**
- "I need to work hard for approval or love"
- "I am not worthy of being loved"
- "I don't deserve to be happy"
- "Anyone I get close to will hurt me"
- "I will hurt anyone I love"
- "I need to protect myself or I'll get hurt"
- "I need to be different — more attractive, more intelligent, more confident — to fit in or be good enough"
**The Map and the Territory**
- Beliefs function as maps for navigating reality but are not the living truth
- Even good maps are not the territory; the finger pointing to the moon is not the moon
- Sogyal Rinpoche's phrase "real but not true" distinguishes the reality of a felt belief from its truth
- Fake news thinking, especially fear-based, produces maps that do not serve us
**RAIN Applied to Beliefs**
- Recognize: Acknowledge what is happening inside, what belief is present
- Allow: Pause and let the reality be as it is, creating space for deeper attention
- Investigate: Ask "What am I believing?", "Is this really true?", "Might this be real but not true?", "What is it like to live with this belief?", "How does it affect my body?", "How has it affected my life?"
- Nourish: Identify what the vulnerable place most needs — a message, reassurance, quality of kindness — and offer it from the wisest, kindest self
**The Alchemy of Compassion**
- Bringing people into their bodies when stuck in fear-based beliefs is essential; cognitive argument alone tightens the grip
- Sensing the body's suffering with a belief opens the door to sadness, grieving, and natural compassion
- Asking "What does this vulnerable place need?" delivers healing to the core wound
**The U-Turn Practice**
- Typically awareness is directed outward; the U-turn brings attention back to lived, immediate experience
- Repeated rounds of returning to present experience build the capacity to distinguish thought from reality
- This distinction is foundational to freeing students from belief-based suffering
**Working with Groups**
- The same RAIN inquiry can be applied in group settings
- Working with one individual in front of a group often produces a collective "me too" resonance
- Bringing different peoples together to genuinely hear each other begins to dissolve beliefs that create separation
- Undoing implicit racial bias and conflict between peoples requires intentional collective inquiry
**Gandhi's Formulation**
- Belief creates thoughts; thoughts create feelings; thoughts and feelings create behavior; behavior creates destiny
**Byron Katie's Work**
- Referenced as a powerful resource for belief inquiry, with the addition of somatic awareness and compassion as complementary elements
### Spiritual and Societal Insights
**The Interpreted World**
- Hildegard de Bingen's concept: we live in an interpreted world, and an interpreted world is not a home
- Diane Connolly's book title "All Sickness is Homesickness" is offered as a resonant expression of this condition
- When lost in fear-based thoughts, we inhabit a virtual reality that functions as a prison
**Evolution and Awakening**
- Getting caught in beliefs is described as part of human evolutionary design
- The trajectory of consciousness is to discover who we are beyond our beliefs
- The longing to wake up from limiting beliefs is framed as the awakened heart calling us home
**Societal Division and the Role of Teachers**
- Beliefs of "something's wrong with me" and "something's wrong with you" are identified as root causes of personal suffering and collective violence
- Mindfulness teachers are positioned to relieve the suffering caused by beliefs that create division
- Increasing polarization and toxicity in society make this work urgent
- The practice of truly hearing another person begins to dissolve the "unreal other" — the enemy we have not met
**The Unreal Other**
- "If I don't know you, it's easy to hate you. If I look into your eyes, I can't."
- Genuine listening and empathic retelling of another's experience can transform enmity into friendship
- This is identified as the essence of waking up from delusional beliefs that cause suffering
**Consciousness and World Change**
- Skillful thinking includes the belief that changing consciousness can change the world
- Aggression as a cultural belief about leadership and safety is identified as a map that does not serve
**Rumi and Elizabeth Lesser**
- Rumi's verse points to the dissolution of self-belief as the gateway to beauty and presence
- Elizabeth Lesser's prayer: "Remove the veils so I might see what is really happening here and not be intoxicated by my stories and my fears"
### Quotes
- "Stop imagining." — Tara Brach, recounting a story about a mother and son
- "If I don't know you, it's easy to hate you. If I look into your eyes, I can't." — Tara Brach, quoting an Israeli camp participant
- "Real but not true." — Tara Brach, attributing the phrase to Sogyal Rinpoche
- "An interpreted world is not a home." — Tara Brach, attributing the phrase to Hildegard de Bingen
- "Our belief creates our thoughts and our thoughts creates our feelings and the thoughts and feelings create our behavior and our behavior creates our destiny." — Tara Brach, attributing the formulation to Gandhi
- "Illusion exists because it is not investigated." — Tara Brach, attributing the statement to Sri Nisargadatta Maharaj
- "What are you believing right now?" — Tara Brach, as a key inquiry question for working with suffering
- "Who would you be if you didn't believe there was anything wrong with you?" — Tara Brach
- "Remove the veils so I might see what is really happening here and not be intoxicated by my stories and my fears." — Tara Brach, quoting Elizabeth Lesser
- "There is nothing to believe. Only when I quit believing in myself did I come into this beauty." — Tara Brach, quoting Rumi
- "Never underestimate the capacity that people have in the end for letting go." — Jack Kornfield
- "Me too." — Jack Kornfield, describing the group resonance when one person opens during inquiry
- "My enemy has heard me." — Tara Brach, quoting a Palestinian girl at a Building Bridges camp
### Stories
**The Tigers Story**
- Shared by Tara Brach
- A woman recounts a conversation with her son: he asks what she would do if surrounded by ten fierce hungry tigers; after she gives up, he says "Stop imagining" — illustrating the power of stepping out of the thought-generated scenario
**The Two Creation Stories**
- Shared by Tara Brach
- A little girl asks her mother how the human race appeared and is told God made Adam and Eve; she asks her father and is told humans evolved from monkeys; confused, she returns to her mother, who explains she told her about her side of the family and the father told her about his — illustrating how tenaciously we hold our own views as correct
**The Building Bridges Camp**
- Shared by Tara Brach, referring to an organization called Building Bridges
- Twenty-two teenage girls from Israel and Palestine were brought to a rural camp in New Jersey to examine beliefs central to their identities; a Palestinian girl described Israeli soldiers barging into her family's home, beating everyone, and leaving without apology; an Israeli teen was asked to retell the story in the first person including the feelings; after hearing her story retold, the Palestinian girl wept and said "My enemy has heard me"; the two girls cried together and became fast friends
**The Magician and the Parrot**
- Shared by Tara Brach
- A magician on a cruise ship has a parrot that continually exposes his tricks; the ship sinks and they end up on a life raft together; after several days of silence the parrot says "Okay, I give up. What did you do with the ship?" — illustrating how our maps can be rendered useless by circumstances
**The Congressman and Mindfulness**
- Shared by Tara Brach
- During mindfulness classes offered on Capitol Hill, a congressman privately shared that a colleague dismisses mindfulness on the grounds that people respect aggressive leaders; the colleague believes aggression creates impact and change, and views mindfulness and acceptance as passive and weak — illustrating a cultural belief that aggression equals safety and control
**The Successful Doctor — RAIN Case Study**
- Shared by Tara Brach, referring to a former client
- A successful doctor and popular medical conference presenter came to Tara Brach suffering from anxiety, stress, acid reflux, and imposter syndrome; through RAIN inquiry his core belief emerged as "I am going to fail, I'll be humiliated, I am pretending to be competent"; investigation revealed how chronically he was unable to relax or savor life; the nourishing step involved his wise self placing hands on the scared imposter's shoulders with the message "Trust yourself, you are basically good"; his practice became handing over anxious worries to a larger sky or caring presence, and over time the sense of failure no longer defined him
**The Doctor on Vacation — Poem**
- Shared by Jack Kornfield, poem by Ellen Bass
- A doctor filling in for a colleague on vacation receives a call from a man on a window ledge twenty stories up; after exhausting every argument, the doctor asks if the man could postpone until Monday when his regular doctor returns; in the silence the doctor matches his breath to the man's; the motion reverses and the man agrees — illustrating the power of presence, breath-matching, and a single gentle invitation to shift a moment of crisis
**The Mother's Three Possibilities**
- Shared by Tara Brach, referring to a friend's mother
- Whenever a child said something judgmental about another person, the mother would pause everything and say "Okay, three possibilities" — prompting the children to consider alternative explanations for the other person's behavior, opening the heart to empathy
### Physical, Mental Challenges, Affects on Practice
- Anxiety and chronic stress are identified as manifestations of fear-based limiting beliefs operating in the body
- The successful doctor case illustrates physical symptoms including acid reflux and digestive disturbance arising from chronic belief-driven anxiety
- Imposter syndrome is described as huge and pervasive, affecting even clearly successful individuals
- Emotions stirred by beliefs can become locked moods when thinking continuously re-stimulates physical feelings
- Living chronically with a limiting belief is described as rarely being able to relax or truly savor life
- The body is identified as the essential site of inquiry: without bringing awareness into the body, cognitive work alone cannot loosen a fear-based belief
- Tension in the body is addressed directly in the guided meditation through breath and softening attention
- Soul sadness is described as arising when a person sees the full landscape of how a limiting belief has confined their life over time
- Fear, embarrassment, self-hatred, and irritation with oneself are named as emotions commonly accompanying limiting beliefs during investigation

