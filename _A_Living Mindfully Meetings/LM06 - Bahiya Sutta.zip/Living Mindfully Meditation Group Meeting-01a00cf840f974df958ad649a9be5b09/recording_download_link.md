# Living Mindfully Meditation Group Meeting - Aug, 23

Please click the link to download the recording. If it does not work, please copy the link and open it in your browser.

# Recording Download Link

**File:** recording.mp3
**Valid for:** 7 days

[Download Recording](<https://files.krisp.ai/downloads/?f=lpEoB4jpDVU8VPHL000qYABL9egjSnk9NGY1PNrgrkDKXPe3XV1bPxc%2B6vbuCZrqux8NWaQie3ukaRSoy6rjqrbA70mrkZWlRkvzJGmbHyMBAQQmiKxMc9VuchOSjCEydeiA2DmZc2Jyxgas3o2RxUl7G%2FZK4lM%3D&Expires=1788216733&Key-Pair-Id=K4KB1ESSQ567P&Signature=mLvD83qKYHg6iBdfJxyvRdjkK7SOzJf2zKs8NJTx7VF~YkocxHXZVIpKqPLi0dHfazxHzBHRe0htZP4Jmuf5VnQtZ1Gv-wKFPznheKzN3UZVC7hvvGSbb5Ym1RTaS0Ju3lP2OuiXTI888P6XxdE3OApHDZ63jLdJWLSByyKv8o-PbEc-ZbgyegD0hBgzGz1G7~4HKZj1D3vIuxOqI3TJjZXHrZ3KYAkN8WjOJzbzE24csYFqiwTprC-MzjO-5XaC74liON6vFNsH1nQouKgpvx1M6LqX7PXdOS4pYhDJTLE6Tu1fJu8rrIMKVwvcVdG2kA~pwa3SnnskCi~vqP1B9g__>)