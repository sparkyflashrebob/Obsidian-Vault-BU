---
tag: samadhi, absorbtion
---
