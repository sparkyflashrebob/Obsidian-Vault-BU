# Ajahn Sumedho - Reflect Again and Again until the Penny Drops - 19052025.md

Of course. Your note's repetition is powerful—it isn't just a request, it

the very instruction. Here is a summary of Ajahn Sumedho's core teaching, framed by this central principle.

--------------------------------------------------------------------------------

Summary: The Teaching is the Method

At its heart, Ajahn Sumedho's teaching is not a set of beliefs to be adopted, but a direct and practical method for realizing truth for oneself. The instruction

"reflect again and again until the penny drops"

perfectly encapsulates this approach. It is a process of patient, sustained investigation into the nature of our own experience.

The Core Practice: Reflect Again and Again

This isn't intellectual analysis. It is a gentle, persistent turning of the mind towards direct experience. The tools for this reflection are often the Buddha's core teachings, used not as philosophy but as practical lenses:

#### The Four Noble Truths:

Instead of just learning them, you apply them.

"This is suffering."

You don't just agree with it; you look at your present anxiety, restlessness, or physical pain and reflect, "Ah,

is the feeling of suffering. What is it like?" You sit with it, observe it, and get to know it without judgment.

"This is the cause of suffering (craving)."

When suffering is present, you look for the grasping, the pushing away, the wanting things to be different. You reflect, "Where is the wanting? What does it feel like to desire or resist?" You see this process in action, again and again.

"This is the end of suffering."

You notice the moments when the craving ceases, even for an instant. That moment of letting go, of peace. You reflect, "What is this moment of non-grasping like? It's possible."

"This is the path."

You recognize that this very act of mindful reflection

#### The "Sound of Silence":

Ajahn Sumedho famously encourages listening to the "sound of silence"—the background of awareness itself. It is the unborn, uncreated knowing that is always present before thoughts, sounds, and feelings arise. You don't try to create it; you simply turn your attention towards it, again and again. You notice the noisy thoughts and emotions, and then you notice the silent awareness in which they appear.

#### Investigate, Don't Assume:

The reflection is a process of questioning. "What is this? Is this thought really me? Is this feeling permanent? Who is it that is aware?" You hold these questions gently, not to find a quick verbal answer, but to open the mind to a deeper seeing.

The Goal: Until the Penny Drops

"The penny drops" is the moment of insight (vipassanā). It is not a thought or a conclusion. It is a direct, intuitive realization where a fundamental truth is suddenly seen and felt on a profound level.

You’ve reflected on the impermanence of your moods a thousand times. Then, one day, in the middle of a wave of anger, the penny drops:

"This is not me. It's just a conditioned energy that comes and goes."

In that moment, the identification with the anger breaks, and there is freedom.

You’ve been watching your thoughts, noting them again and again. Then, the penny drops:

"The thinking mind is just a natural phenomenon, like the weather. I don't have to believe it or be controlled by it."

You’ve been sitting with discomfort, reflecting on it again and again. Then, the penny drops:

"The resistance to the pain is a greater suffering than the pain itself."

This is the essence of the practice: a relentless, yet gentle, return to the present reality. You don't force the penny to drop. You simply create the conditions for insight by

reflecting again, and again, and again.

--------------------------------------------------------------------------------

Based on the summary provided, here are the key points of Ajahn Sumedho's teaching, as framed by the principle "reflect again and again until the penny drops":

#### The Teaching Is the Method Itself:

The core message isn't a belief system to be learned, but a practical process to be undertaken. The instruction to "reflect again and again"

#### Reflection is Experiential, Not Intellectual:

This isn't about deep thinking or philosophical debate. It is a gentle but persistent turning of your attention toward your direct, present-moment experience—what you are seeing, hearing, and feeling right now.

#### Use Teachings as Practical Lenses:

Foundational concepts like the Four Noble Truths are not meant to be memorized, but actively applied. For example, when you feel anxious, you reflect, "Ah,

is suffering. What does it actually feel like?" You investigate it directly.

#### Awareness is the Foundation:

A key practice is to tune into the "sound of silence"—the underlying, ever-present awareness in which all thoughts, emotions, and sensations appear and disappear. This shifts focus from the

of the mind to the

of awareness itself.

#### The "Penny Drop" is Direct Insight (Vipassanā):

The goal is not a new thought or a clever conclusion. It is a moment of sudden, intuitive seeing where a fundamental truth is realized on a gut level. For example, you don't just

"anger is not me," you suddenly

it as an impersonal energy passing through, and in that moment, you are free from it.

#### Patience and Repetition are Essential:

You cannot force insight. The practice is about patiently creating the conditions for the "penny to drop" by consistently and gently returning your attention to reflection, over and over again.

--------------------------------------------------------------------------------

Excellent question. Ajahn Sumedho’s perspective on effort is nuanced and central to his teaching. It is a direct counterpoint to the Western idea of effort as forceful striving or "gritting your teeth."

He frames effort within the Buddhist principle of

"Right Effort" (Samma Vayama)

, which is about wisdom and balance, not brute force.

#### Here’s what he says about effort:

1. The Wrong Kind of Effort: Striving and Becoming

Ajahn Sumedho points out that most of our effort is driven by desire and aversion. It’s the effort to

something we want (like enlightenment, peace, or a quiet mind) or to

something we don’t want (like anxiety, pain, or distracting thoughts).

This kind of effort creates tension, frustration, and restlessness.

It's based on the deluded belief that "I" need to become something better in the future.

He would call this

, and it is a form of suffering itself. Forcing the mind to be quiet is just another form of violence and agitation.

2. The Right Kind of Effort: Wise and Gentle

Right Effort is not about trying harder, but about applying energy wisely. It's more about attention and allowing than it is about forcing.

#### The Effort to Be Aware:

The primary effort is simply to

remember to pay attention

. It’s the gentle but persistent effort of bringing the mind back when it wanders. It is the effort in "reflect again and again." You aren't forcing a conclusion; you are making the effort to keep looking.

#### The Effort to Let Go:

This is a crucial and seemingly paradoxical point. A significant part of Right Effort is the effort required to

stop making the wrong kind of effort

. When you notice you are tense, striving, or fighting with your experience, the wise effort is to consciously

relax and let go

of that struggle. It takes effort to release tension.

#### The Effort of Balance (The Middle Way):

#### Ajahn Sumedho constantly emphasizes a middle path between two extremes:

#### Too much effort:

Leads to restlessness and striving. The mind becomes tight and agitated.

#### Too little effort:

Leads to sloth, torpor, and dullness. The mind becomes slack and sinks into daydreams.

#### Right Effort:

Is like tuning a guitar string. It's not too tight and not too loose. It's a state of

alert relaxation

—an energy that is calm, bright, and receptive.

Summary Analogy

#### Think of holding a small bird in your hand:

Squeeze too hard (too much effort), and you kill it.

Hold it too loosely (too little effort), and it flies away.

You must apply just the right amount of gentle, attentive pressure (Right Effort) to hold it safely.

In short, for Ajahn Sumedho,

effort is the patient, persistent energy you apply to being mindfully present and to letting go of the struggle.

It is the wise intention to return your attention to the here and now, again and again, without demanding a specific result.

--------------------------------------------------------------------------------

It's the effort of opening, not the effort of grasping.

--------------------------------------------------------------------------------

https://youtu.be/6ApAvRanQVo?si=XgvhJb\_dfvhWLF1-&t=9

The more hate \[Music\] \[Music\] to the one to sat. This afternoon the opportunity again arises to reflect on the way it Yes. And this is a important kind of opportunity because the way it is as we generally assume is very worldly. We think of the news of the day, the political situation, family problems, and we think that's the way it is. A kind of a kind of resignation to condition

https://youtu.be/6ApAvRanQVo?si=XgvhJb\_dfvhWLF1-&t=125

phenomena. But that's not what I'm pointing at. I'm not pointing to the the way it is as as a worldly experience but as Dhhammer because whatever your experience might be your mental state your emotional state at this moment you know to see well that's way it is is still the ego operating from the sense of a kind of well it's just karma it's my karma or I just have to get get on with life and when tragedy happens and disappointments arise in our lives we can just say well that's the way it is and uh that's not what I mean when I'm using these words that's the way it is because this is a reflection on the dharma aspect of whatever you're thinking and experiencing intellectually, emotionally, physically

https://youtu.be/6ApAvRanQVo?si=XgvhJb\_dfvhWLF1-&t=201

is all conditions are impermanent. So playing each other. So this is different. It's non grasping. It's not grasping a kind of idea. Well, it's my karma or my problem or blaming somebody else for the situation you're experiencing. It's realizing whatever you're experiencing whether it's blaming somebody else, blaming yourself, blaming the political system that whatever that the blame itself is impermanent. You know the experience is what it is. Some are pleasant, some are unpleasant. But the way it is is that whether what their quality might be good or bad, pleasant or unpleasant, that they are impermanent. This is very

https://youtu.be/6ApAvRanQVo?si=XgvhJb\_dfvhWLF1-&t=279

important to keep assuring yourself of the impermanency of the world that we tend to have been told is the real world. So this is is a wisdom. It's not just Buddhist ideas. It's not Buddhist philosophy. It's actually a wise a wisdom teaching that is to be reflected upon again and again till it the penny drops. Do you really understand that all conditions physical, mental, emotional, intellectual are very nature impermanent. They're they're and they're not they're not a person, a real person. Dharma is not a person. Even the dumbest of eyes, ears, nose, tongue, body,

https://youtu.be/6ApAvRanQVo?si=XgvhJb\_dfvhWLF1-&t=352

brain, they're the they're still not personal. They're empty phenomena and we keep reminding ourselves that we have this reflection on reflecting upon it again and again till it actually register. Suddenly you you're not just it's no longer a technique that you've been advised to use or believe in, but it actually you realize it. You know it not because of believing or grasping but because wisdom is guiding you rather than the conditioning social conventional religious conditioning that you've received in your life. So how much effort does it take to do this you know so we've been we've been given advice we must put a lot of effort

https://youtu.be/6ApAvRanQVo?si=XgvhJb\_dfvhWLF1-&t=437

into our practice and uh get sami really get concentrated we've been given all kinds of advice meditation what is essential at the beginning. So like with anapanosati as a beginning technique mindfulness of the breath you know from my own experience I was told my f first endeavor at mindfulness of breath was to watch the rise and fall of my stomach. It's called the Mahasi Siad tradition, a Burmese tradition. So I put a lot of effort in to concentrate on my the the rise and fall of my my stomach and sometimes I'd get very concentrated and other times things would interfere. I'd have some kind of emotional upheaval in my mind which I

https://youtu.be/6ApAvRanQVo?si=XgvhJb\_dfvhWLF1-&t=518

couldn't concentrate on my the rise and fall anymore. And so then this was like I've mentioned many times bad meditation versus good meditation because the conditions are not always convenient or available for a good meditation or what we call quote a good meditation. So then exploring investigating effort what's right effort in the eight-fold path and uh this is you know what what what do you mean by right effort. How much effort is right effort? So you you try to figure it out you know right effort and is there is it

https://youtu.be/6ApAvRanQVo?si=XgvhJb\_dfvhWLF1-&t=592

the beginning period or is it samati is it janna and we start thinking about it right effort is something we want to get because it's part of the eight-fold path fourth noble truth So right effort is still sounds like a lot of effort or really refined special kind of refined effort that we apply to our what we call meditation or bana. So right effort always uh at least in my karmic experience always meant very refined effort that takes quite a while to to develop right effort is something you have to develop through concentration practices. So that's just how my mind works. It's it's a the my intellect is

https://youtu.be/6ApAvRanQVo?si=XgvhJb\_dfvhWLF1-&t=672

is based on course and refinement and good and bad heaven and hell god and the devil. So and then right effort is sounds you know interpreted in the finally full path series must be really refined very special takes ages to get refined effort. So those are the thinking habits of that that I had towards the subject of right effort. Then as I've said before I had so in my beginning years as a monk I put forth a lot of effort. I was very, you know, I just wanted live in a nice couti and a quiet place where I could apply a lot of effort to samadei

https://youtu.be/6ApAvRanQVo?si=XgvhJb\_dfvhWLF1-&t=749

concentration. Then I feel frustrated when the conditions changed and they didn't go the way I wanted. noise or remember in Thailand when radios became common amongst the villagers and they put radios on the water buffaloos that plow the rice fields and you'd hear all this kind of Thai pop music which could I just develop aversion to it you know because what banana was surrounded by rice fields so was one so um so you feel aversion to the rice farmers the water buffalo the radio because they're they're disrupting my samati my concentration

https://youtu.be/6ApAvRanQVo?si=XgvhJb\_dfvhWLF1-&t=819

So exploring effort I began when I asked one time about meditation. I've referred to this many times before when I said what what how would you define meditation he said holiday of the hearts and um Jai and Thai puckborn is like a rest relaxed holiday of the heart. So then I thought I don't see meditation as any holiday of the heart. I see it as hard work and and I, you know, have to develop this and develop that and it's a lot of effort to to really get anywhere and get all the right levels of concentration. Well, holiday of the

https://youtu.be/6ApAvRanQVo?si=XgvhJb\_dfvhWLF1-&t=889

heart which I translate which is in Thai is pakorn. I translated as holiday of the heart. I thought well that made an impression because it's coming from a wise monk a teacher that I highly regarded and respected. So I began to investigate right effort or effort and I could see how how meditation was hard work because I put so much effort into it trying to hold my attention. First it was on the with the mahasi method the rise and fall of the stomach and then with lra was at the tip of the nose. So inhale noticing the sensation at the tip of the nose. So I put a lot of effort in trying to sustain an inhalation at the tip of the nose and and exhaling at the tip of the nose

https://youtu.be/6ApAvRanQVo?si=XgvhJb\_dfvhWLF1-&t=958

and and just that whole idea of tip of the nose or the rise and fall of the belly, you know, how did that affect you? Can you really concentrate on the tip of your nose for one inhalation? Or then I began to realize on the inhalation it was I was fairly easy to sustain effort and but on the exhalation I noticed my mind always wandered that my my mind would wander always on the on exhaling and I could see that this is because the inhalation is It's the inspiring side of life. Inhalation is inspiring. It rises up and then it reaches a peak where you can't inhale anymore and you can only exhale. And

https://youtu.be/6ApAvRanQVo?si=XgvhJb\_dfvhWLF1-&t=1028

that's the other side of life, the unpleasant side. Old age, sickness, death, loss of loved ones, all that. We don't want the boredom, the disillusionment, the doubt, the worry that we produce in our minds. That life itself when you're young is is inspiring. For many most people, youth is a kind of hope, an expectation, an inspiration. And then as you get older and you have more experience with life and there's more despair, depression, disillusionment, boredom. Things that used to interest you or excite you or fascinate you certainly become

https://youtu.be/6ApAvRanQVo?si=XgvhJb\_dfvhWLF1-&t=1090

boring. no longer find them interesting or exciting. So to have a holiday of the heart isn't about trying to be inspired through an exhalation or just to seek inspiration as your refuge because inspiration is impermanent. Worldly inspiration is impermanent as well as expiration. Disillusionment, despair, doubt, worry, they're impermanent. So they all share whether it's inspiring or depressing they all share the same reality of impermanence and not self. So it's explained very well in the Buddhist teaching that that all conditions are impermanent. All dhamas

https://youtu.be/6ApAvRanQVo?si=XgvhJb\_dfvhWLF1-&t=1167

are not personal. So don't take life personally. So then uh to have a holiday, you know, when you put a lot of effort into something, you need a lot of effort. When you lift a heavy object onto a table or a lorry, you can't just relax. When you're lifting a log onto a lorry, you have to put a lot of effort, strength into your body to lift a heavy log up to get it on on the back of a lore. Well, that's right for the situation because or holiday of the heart is not appropriate for that experience. But that experience itself is impermanent. So then way we become obsessed with

https://youtu.be/6ApAvRanQVo?si=XgvhJb\_dfvhWLF1-&t=1246

meditation. We got to meditate. I remember just watching my mind saying, you know, I'm wasting my time. I've got to meditate. And so I began just watching that, you know, about the guilt about wasting time. What I would call wasting time and to just reflect on who is wasting time? What is wasting time about? Having a cup of tea in the afternoon or going to a movie or having a holiday wasting time when you should be involved in trying to get your samadei trying to get something that you imagine. So listening to my mind, this is what I recommend. This listening to the ego, no matter what it

https://youtu.be/6ApAvRanQVo?si=XgvhJb\_dfvhWLF1-&t=1321

says, good or bad, nonsense, intelligence, being reasonable or unreasonable, it's all empty phenomena. It arises and ceases and it's not self. So that insight into the way it is is that some uh a right effort is relaxing because that you know to relax is a holiday. We we go on holidays to relax. Go to the seaside to relax. So relax is another word that we can think of is we become obsessed with relaxing. So that's where it's important to listen to your mind the way you you receive

https://youtu.be/6ApAvRanQVo?si=XgvhJb\_dfvhWLF1-&t=1396

even wisdom teachings like relax, let go. These are wisdom teachings, but then we we interpret it as in a very personal way. I've got to relax. I've got to let go. Well, that's because of the conditioning, the thinking way we've been conditioned to think in in a very personal way. That relaxing is something I I've got to de develop relaxation or letting go. But when you listen to your ego, this I've got to relax. I've got to learn how to relax is words. You know, it's just empty phenomena that you're taking very personally is who has to relax. And then

https://youtu.be/6ApAvRanQVo?si=XgvhJb\_dfvhWLF1-&t=1462

um when I think of it in personal terms, oh, I have to relax. I'm too tense. I'm too obsessed. or I've got to let go of everything. And then when I see attachments, I think I I should let go of everything. I'm attached to this and I shouldn't be. We feel guilty because attachment is a cause of suffering. So we can explain it in dharma terms. But the important message in this reflection is to be the watcher, not the person relaxing or trying to relax. But then there's the word being. Just being here and

https://youtu.be/6ApAvRanQVo?si=XgvhJb\_dfvhWLF1-&t=1528

now. Well, that's really good advice. Just being, just be, you know, that's state of you don't have to be anybody or do anything. Just just be here and now because whatever we're doing, we're always here. Whatever place you're in, it's you're always here. And the time is always now. Whatever time the the clock may provide. So be here and now is why wisdom. But when we take it personally, I've got to be here and now. We listen to that. Just listen to all the things you've got to do to be a good meditator. Just listen and watch these words arise and

https://youtu.be/6ApAvRanQVo?si=XgvhJb\_dfvhWLF1-&t=1597

cease because I noticed that so much of my attention in early years of meditation was the compulsiveness of it. I put a lot of effort into meditating and and it became a compulsion. So then just so this is what we call reflecting not judging or trying to figure it out intellectually. It's not an intellectual process. It's just being here and now. The the state of being relaxed here is like this. And then notice even if your body isn't relaxed or there's all kinds of tension and just the attitude of letting go, just accepting the the tension, not trying to get rid of it or what you think you you know being

https://youtu.be/6ApAvRanQVo?si=XgvhJb\_dfvhWLF1-&t=1673

tense or obsessed. You shouldn't be obsessed. As long as you feel you shouldn't get obsessed with things, that's another sense of a self. It's meant to be obsessed by anything. It's true. This is where Lunga would always say, "True, but not right." Right? But not true. I shouldn't be obsessed by worldly conditions. But rather than trying to not be obsessed as a person, trying to let go and relax as a personal effort doesn't work. That's good advice. It's true, but not right. Right, but not true. But just this sense of open attention, being here and now, relaxed. And then you can be aware of

https://youtu.be/6ApAvRanQVo?si=XgvhJb\_dfvhWLF1-&t=1746

the tensions in your body that that compel you to to do do things that you've got to get something, do something, go somewhere, go somewhere. All these kind of compulsive messages we get through the body and we're the witness the bu the witness of this rather than the judge we're not it's not as soon as I start judging it as right or wrong then I'm back into ssara I'm on tomato passing judgment on something on some condition rather than recognizing it's apparent here and now is it is like this at this time but it changes nothing stays permanently bad or

https://youtu.be/6ApAvRanQVo?si=XgvhJb\_dfvhWLF1-&t=1816

Good. So then my insight into the eight-fold path, right? Effort is actually no effort. It's effortless. It's natural. It's not created by me as a person, me as a Buddhist monk. Through using all kinds of meditation techniques, I've been introduced to it is a holiday of the heart. So then life becomes much more pleasant. Monastic life is a very pleasant way to live. You know, there's a special opportunity that we have that most of us who weren't born into Buddhist families never expected or

https://youtu.be/6ApAvRanQVo?si=XgvhJb\_dfvhWLF1-&t=1892

thought would happen. It never was an option in our lives. So then if I say just relax right effort is no effort then you you can the ego says well you don't have to do anything anymore listen to that you know relaxing letting go and the ego will jump onto that saying I don't have to meditate. I don't have to let go of anything. I just relax and be here and now. It sounds the ego knows all the words. But listen to that ego. It's arises and ceases. I don't right effort is relaxation. No effort. And then those are words, English words. And we listen to the words without judging them as good advice or bad advice, but just witnessing they are they arise and

https://youtu.be/6ApAvRanQVo?si=XgvhJb\_dfvhWLF1-&t=1979

cease. And through just the being the pau rather than the person, the physical person, a man or woman, a monk or a nun or a lay person. These are all adopted identities. But when we become a senior monk, you know, then just that word being senior. I'm now a you we call a 10 wasa monk and a and aadar become a after 10 pas and then we're a so listen to that how you you you know how you can feel more important more proud of being an agon because that's a rather nice title means teacher I'm a

https://youtu.be/6ApAvRanQVo?si=XgvhJb\_dfvhWLF1-&t=2057

teacher So some monks become obnoxious when they become a because they kind of take it so personally. So these hierarchical structures are not for grasping. They're just conventions to use to reflect on the emptiness of thoughts, emotions, physical bodies, eyes, ears, nose, tongue, body, brain because that's their true nature. They're impermanent. The word ajan is made up with a Thai kind of expression for acharia which is a poly word the Sanskrit word and then like some of us become per cruise that's even a better

https://youtu.be/6ApAvRanQVo?si=XgvhJb\_dfvhWLF1-&t=2133

than an And then we become jun that's higher than a pru you know and then there's different levels of jcoons and so you know if you take it personally you you can be a real pain in the neck because holding on to these these titles. It's not the path. It's not wisdom. It's not letting go. It's grasping status in a in a conventional system. And that's not wisdom. Wisdom is very, you know, it's so well exemplified in just those two phrases. All conditions are impermanent. That is not just a kind of philosophy, Buddhist philosophical statement or

https://youtu.be/6ApAvRanQVo?si=XgvhJb\_dfvhWLF1-&t=2214

theology or a metaphysical ideal. It's a reality that we can see for ourselves through what we call bana or meditation, through observing. Try to find a condition that's permanent. The other encouragement is to observe space because space is apparent here and now. So space is is an element that we exist in all the time. If there was no space, how could we be here and now? But space is not, you know, we can say this is a good space or a bad space, a big space or a small space. But space is, you know, everything's in space. The sun, moon and

https://youtu.be/6ApAvRanQVo?si=XgvhJb\_dfvhWLF1-&t=2288

stars, the whole universe is in space. So space is here and now you can actually perceive it. But what you cannot perceive is consciousness. It's impossible to perceive consciousness which is apparent here and now and timeless. It's dharma. And if there were no consciousness, there wouldn't be any space because space comes emanates through consciousness and forms arise in space. So that whole sequence of consciousness and space and the four elements earth, fire, water and air and suddenly the whole thing becomes quite even intellectually it's superb

https://youtu.be/6ApAvRanQVo?si=XgvhJb\_dfvhWLF1-&t=2357

paradigm that's worthy of reflection upon. So you know they're trying to perceive consciousness because consciousness is the perceiving mechanism. It allows us to perceive space to perceive forms. Space allows us to perceive forms. So in terms of a sequence that I found incredibly beautiful, just the six elements, consciousness, space, earth, fire, water, and air. Then suddenly the whole sense of the universe the the uh the problems that we have in families and societies arise and cease and we we as people we always want

https://youtu.be/6ApAvRanQVo?si=XgvhJb\_dfvhWLF1-&t=2433

to solve the problems. We want answers to questions. We don't like to doubt. We don't like to be bored. We want a purpose and meaning to our life. What is the purpose of a human life? What is the does does it have any meaning? our intellectual questions, existential questions. We ask ourselves, is there a meaning to my life being a monk all these years? Is is it meaningful? And just that wanting to is there a purpose for an ancient institution like Buddhist monasticism? Old religion thousands of years old. Does it

https://youtu.be/6ApAvRanQVo?si=XgvhJb\_dfvhWLF1-&t=2499

really have any mean or purpose in modern high-tech society? So listening to the to the mind that purpose and meaning as a person, you know, you realize that it it doesn't make sense anymore because the opportunity unity we have as human beings to witness the way it is to reflect on the way it is all conditions are impermanent all dhamma is not personal not self there's no kind of deity up in the sky a god or goddess that created all this we can imagine that you know we can create all kinds of images of different forms for deities and

https://youtu.be/6ApAvRanQVo?si=XgvhJb\_dfvhWLF1-&t=2573

gods, but they're still conditioned phenomena that that we imagine. Imagination is a condition. Thinking is a condition is a sankara is a phenomenon. So consciousness then is suddenly just that word is a word whenana you know is a consciousness through the senses is very impermanent but consciousness itself An undone sapo pab consciousness without feature without end and dharma are the same thing both words. But what is we take refuge in

https://youtu.be/6ApAvRanQVo?si=XgvhJb\_dfvhWLF1-&t=2659

dharma? Is it a condition that we take refuge in something called dharma? What is it in terms of apparent here and now? What is the dharma? The ninth consciousness without feature without end apparent here and now. And that we begin to realize it's like what Bollywood budget time to be realized individually by through wisdom. So I offer this for this afternoon's reflection.

