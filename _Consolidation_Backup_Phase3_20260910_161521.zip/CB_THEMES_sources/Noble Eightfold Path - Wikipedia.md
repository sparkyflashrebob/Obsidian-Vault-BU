# Noble Eightfold Path - Wikipedia

https://en.wikipedia.org/wiki/Noble\_Eightfold\_Path

Jump to content

Main menu    Navigation

Current events

Random article

About Wikipedia

Learn to edit

Community portal

Recent changes

Upload file

Special pages

Create account

Create account

Pages for logged out editors

https://en.wikipedia.org/wiki/Help:Introduction

Contributions

https://en.wikipedia.org/wiki/Help:Introduction

https://en.wikipedia.org/wiki/Help:Introduction

https://en.wikipedia.org/wiki/Help:Introduction

1   Etymology and nomenclature

https://en.wikipedia.org/wiki/Help:Introduction

2   The eight divisions

https://en.wikipedia.org/wiki/Help:Introduction

2.1   Origins: the Middle Way

https://en.wikipedia.org/wiki/Help:Introduction

2.2   Tenfold path

https://en.wikipedia.org/wiki/Help:Introduction

2.3   Short description of the eight divisions

https://en.wikipedia.org/wiki/Help:Introduction

2.4   Right view

https://en.wikipedia.org/wiki/Help:Introduction

2.4.1   Sequences in the suttas

https://en.wikipedia.org/wiki/Help:Introduction

2.4.2   Theravada

https://en.wikipedia.org/wiki/Help:Introduction

2.4.3   A-ditthi

https://en.wikipedia.org/wiki/Help:Introduction

2.5   Right resolve

https://en.wikipedia.org/wiki/Help:Introduction

2.6   Right speech

https://en.wikipedia.org/wiki/Help:Introduction

2.7   Right action

https://en.wikipedia.org/wiki/Help:Introduction

2.8   Right livelihood

https://en.wikipedia.org/wiki/Help:Introduction

2.9   Right effort

https://en.wikipedia.org/wiki/Help:Introduction

2.10   Right mindfulness

https://en.wikipedia.org/wiki/Help:Introduction

2.11   Right samadhi (unification of mind)

https://en.wikipedia.org/wiki/Help:Introduction

2.11.2   Dhyana

2.11.3   Concentration

2.11.4   Development into equanimity

2.12   Liberation

3   Practice

3.1   Order of practice

3.2   Sila-samadhi-prajna

4   Schools of Buddhism and their views of the Eightfold Path

4.1   Theravada presentations of the path

4.2   Mahayana presentations of the path

4.2.1   East Asian Buddhism

4.2.2   Indo-Tibetan Buddhism

5   Cognitive psychology

6   See also

8   References

9   Sources

9.1   Primary sources

9.2   Secondary sources

10   External links

Noble Eightfold Path

Беларуская (тарашкевіца)

Bahasa Indonesia

Lëtzebuergesch

Bahasa Melayu

Norsk bokmål

Simple English

Slovenščina

Српски / srpski

Srpskohrvatski / српскохрватски

Tools    Actions

View history

What links here

Related changes

Upload file

Permanent link

Page information

Cite this page

Get shortened URL

Download QR code

Print/export

Download as PDF

Printable version

In other projects

Wikimedia Commons

Wikidata item

From Wikipedia, the free encyclopedia   Buddhist practices leading to liberation from saṃsāra   "Eightfold Path" redirects here. For other uses, see

Eightfold Path (disambiguation)

https://en.wikipedia.org/wiki/Eightfold\_Path\_(disambiguation)

The eight spoke

Dharma wheel

https://en.wikipedia.org/wiki/Dharmacakra

symbolizes the Noble Eightfold Path.   Translations of

The Noble Eightfold Path

https://en.wikipedia.org/wiki/Sanskrit

आर्याष्टाङ्गमार्ग   (

https://en.wikipedia.org/wiki/International\_Alphabet\_of\_Sanskrit\_Transliteration

āryāṣṭāṅgamārga

https://en.wikipedia.org/wiki/Pali

अरिय अट्ठङ्गिक मग्ग   (

ariya aṭṭhaṅgika magga

https://en.wikipedia.org/wiki/Bengali\_language

অষ্টাঙ্গিক আর্য মার্গ   (

Astangik ārya mārga   Oșŧangik Azzo Maggo   Oșŧangik Arzo Margo

https://en.wikipedia.org/wiki/Burmese\_language

မဂ္ဂင်ရှစ်ပါး   (

https://en.wikipedia.org/wiki/MLC\_Transcription\_System

mɛʔɡɪ̀ɰ̃ ʃɪʔ pá

https://en.wikipedia.org/wiki/Chinese\_language

https://en.wikipedia.org/wiki/Chinese\_language

https://en.wikipedia.org/wiki/Pinyin

bā zhèngdào

https://en.wikipedia.org/wiki/Japanese\_language

https://en.wikipedia.org/wiki/Japanese\_language

https://en.wikipedia.org/wiki/R%C5%8Dmaji

https://en.wikipedia.org/wiki/Khmer\_language

អរិយដ្ឋង្គិកមគ្គ

https://en.wikipedia.org/wiki/Khmer\_language

https://en.wikipedia.org/wiki/Romanization\_of\_Khmer#UNGEGN

areyadthangkikameak

https://en.wikipedia.org/wiki/Korean\_language

https://en.wikipedia.org/wiki/Korean\_language

https://en.wikipedia.org/wiki/Revised\_Romanization\_of\_Korean

https://en.wikipedia.org/wiki/Mongolian\_language

ᠣᠦᠲᠦᠶᠲᠠᠨᠦ   ᠨᠠᠢᠮᠠᠨ   ᠭᠡᠰᠢᠭᠦᠨᠦ   ᠮᠥᠷ

Найман гишүүт хутагт мөр   (

qutuγtan-u naiman gesigün-ü mör

https://en.wikipedia.org/wiki/Sinhala\_language

ආර්ය අෂ්ඨාංගික මාර්ගය

https://en.wikipedia.org/wiki/Sinhala\_language

https://en.wikipedia.org/wiki/Sinhala\_language

འཕགས་པའི་ལམ་ཡན་ལག་བརྒྱད་པ   (

: 'phags pa’i lam yan lag brgyad pa

https://en.wikipedia.org/wiki/THL\_Simplified\_Phonetic\_Transcription

: pakpé lam yenlak gyépa

https://en.wikipedia.org/wiki/Tamil\_language

உன்னத எட்டு மடங்கு பாதை

https://en.wikipedia.org/wiki/Tagalog\_language

Waluhang Mahal na Landas

ᜏᜎᜓᜑᜅ᜔ᜋᜑᜎ᜔ᜈᜎᜈ᜔ᜇᜐ᜔

https://en.wikipedia.org/wiki/Thai\_language

อริยมรรคมีองค์แปด

https://en.wikipedia.org/wiki/Thai\_language

https://en.wikipedia.org/wiki/Royal\_Thai\_General\_System\_of\_Transcription

Ariya Mak Mi Ong Paet

https://en.wikipedia.org/wiki/Vietnamese\_language

Bát chính đạo

https://en.wikipedia.org/wiki/Vietnamese\_language

Glossary of Buddhism

https://en.wikipedia.org/wiki/Glossary\_of\_Buddhism

https://en.wikipedia.org/wiki/Category:Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Pre-sectarian Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Silk Road transmission of Buddhism

https://en.wikipedia.org/wiki/Buddhism

Decline in the Indian subcontinent

https://en.wikipedia.org/wiki/Buddhism

Later Buddhists

https://en.wikipedia.org/wiki/Buddhism

Buddhist modernism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Four Noble Truths

https://en.wikipedia.org/wiki/Buddhism

Noble Eightfold Path

https://en.wikipedia.org/wiki/Buddhism

Dharma wheel

https://en.wikipedia.org/wiki/Buddhism

Five Aggregates

https://en.wikipedia.org/wiki/Buddhism

Impermanence

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Dependent Origination

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Buddhist texts

https://en.wikipedia.org/wiki/Buddhism

Buddhavacana

https://en.wikipedia.org/wiki/Buddhism

Early Texts

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Mahayana Sutras

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Sanskrit literature

https://en.wikipedia.org/wiki/Buddhism

Tibetan canon

https://en.wikipedia.org/wiki/Buddhism

Chinese canon

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Three Jewels

https://en.wikipedia.org/wiki/Buddhism

Buddhist paths to liberation

https://en.wikipedia.org/wiki/Buddhism

Five precepts

https://en.wikipedia.org/wiki/Buddhism

Perfections

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Philosophical reasoning

https://en.wikipedia.org/wiki/Buddhism

Devotional practices

https://en.wikipedia.org/wiki/Buddhism

Merit making

https://en.wikipedia.org/wiki/Buddhism

Recollections

https://en.wikipedia.org/wiki/Buddhism

Mindfulness

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Sublime abidings

https://en.wikipedia.org/wiki/Buddhism

Aids to Enlightenment

https://en.wikipedia.org/wiki/Buddhism

Monasticism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Buddhist chant

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Vegetarianism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Four Stages

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Pratyekabuddhayāna

https://en.wikipedia.org/wiki/Buddhism

Bodhisattva

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Buddhism by country

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

New Zealand

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Buddhism portal

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Noble Eightfold Path

https://en.wikipedia.org/wiki/Sanskrit\_language

:  आर्याष्टाङ्गमार्ग ,

āryāṣṭāṅgamārga

Eight Right Paths

https://en.wikipedia.org/wiki/Sanskrit\_language

:  अष्टसम्यङ्मार्ग ,

aṣṭasamyaṅmārga

is an early summary of the path of

https://en.wikipedia.org/wiki/Buddhism

practices leading to

https://en.wikipedia.org/wiki/Enlightenment\_in\_Buddhism

https://en.wikipedia.org/wiki/Samsara

, the painful cycle of

https://en.wikipedia.org/wiki/Rebirth\_(Buddhism)

in the form of

https://en.wikipedia.org/wiki/Nirvana

The Eightfold Path consists of eight practices: right view, right resolve, right speech, right conduct, right livelihood, right effort, right mindfulness, and right

('meditative absorption or union'; alternatively, equanimous meditative awareness).

In early Buddhism, these practices started with understanding that the body-mind works in a corrupted way (right view), followed by entering the Buddhist path of self-observance, self-restraint, and cultivating kindness and compassion; and culminating in

, which reinforces these practices for the development of the body-mind.

In later Buddhism, insight (

) became the central

soteriological

https://en.wikipedia.org/wiki/Soteriology

instrument, leading to a different concept and structure of the path,

in which the "goal" of the Buddhist path came to be specified as ending ignorance and

https://en.wikipedia.org/wiki/Rebirth\_(Buddhism)

The Noble Eightfold Path is one of the principal summaries of the

Buddhist teachings

https://en.wikipedia.org/wiki/Dharma\_(Buddhism)

, taught to lead to

https://en.wikipedia.org/wiki/Theravada

tradition, this path is also summarized as

(morality),

(meditation) and

(insight). In

https://en.wikipedia.org/wiki/Mahayana

Buddhism, this path is contrasted with the

Bodhisattva

https://en.wikipedia.org/wiki/Bodhisattva

path, which is believed to go beyond

https://en.wikipedia.org/wiki/Buddhahood

Buddhist symbolism

https://en.wikipedia.org/wiki/Buddhist\_symbolism

, the Noble Eightfold Path is often represented by means of the

dharma wheel

https://en.wikipedia.org/wiki/Dharma\_wheel

dharmachakra

), in which its eight spokes represent the eight elements of the path.

Etymology and nomenclature

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=1

The Pali term

ariya aṭṭhaṅgika magga

https://en.wikipedia.org/wiki/Sanskrit

āryāṣṭāṅgamārga

) is typically translated in English as 'Noble Eightfold Path'. This translation is a convention started by the early translators of Buddhist texts into English, just like

ariya sacca

is translated as '

Four Noble Truths

https://en.wikipedia.org/wiki/Four\_Noble\_Truths

However, the phrase does not mean the path is noble, rather that the path is

of the noble people

https://en.wikipedia.org/wiki/Pali

, meaning 'enlightened, noble, precious people').

) means 'path', while

) means 'eightfold'. Thus, an alternate rendering of

ariya aṭṭhaṅgika magga

is 'eightfold path of the noble ones',

or 'Eightfold Ariya Path'.

All eight elements of the Path begin with the word

(in Sanskrit) or

(in Pāli) which means 'right, proper, as it ought to be, best'.

The Buddhist texts contrast

with its opposite,

The Noble Eightfold Path, in the Buddhist traditions, is the direct means to nirvana and brings a release from the cycle of life and death in the realms of samsara.

The eight divisions

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=2

\]   See also:

Buddhist paths to liberation

https://en.wikipedia.org/wiki/Buddhist\_paths\_to\_liberation

Origins: the Middle Way

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=3

According to Indologist Tilmann Vetter, the description of the Buddhist path may initially have been as simple as the term

https://en.wikipedia.org/wiki/Middle\_Way

In time, this short description was elaborated, resulting in the description of the Eightfold Path.

Tilmann Vetter and historian Rod Bucknell both note that longer descriptions of "the path" can be found in the early texts, which can be condensed into the Eightfold Path.

Tenfold path

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=4

Mahācattārīsaka Sutta

which appears in the Chinese and Pali canons, the Buddha explains that cultivation of the noble eightfold path of a learner leads to the development of two further paths of the

https://en.wikipedia.org/wiki/Arhat

, which are right knowledge, or insight (

), and right liberation, or release (

sammā-vimutti

These two factors fall under the category of wisdom (

Short description of the eight divisions

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=5

#### The eight Buddhist practices in the Noble Eightfold Path are:

Right View: our actions have consequences, death is not the end, and our actions and beliefs have consequences after death. The Buddha followed and taught a successful path out of this world and the other world (heaven and underworld/hell).

Later on, right view came to explicitly include

and rebirth, and the importance of the Four Noble Truths, when "insight" became central to Buddhist

soteriology

https://en.wikipedia.org/wiki/Soteriology

, especially in Theravada Buddhism.

Right Resolve (

samyaka-saṃkalpa

sammā-saṅkappa

) can also be known as "right thought", "right aspiration", or "right motivation".

In this factor, the practitioner resolves to strive toward non-violence (

) and avoid violent and hateful conduct.

It also includes the resolve to leave home, renounce the worldly life and follow the Buddhist path.

Right Speech: no lying, no abusive speech, no divisive speech, no idle chatter.

Right Conduct or Action: no killing or injuring, no taking what is not given, no sexual misconduct, no material desires.

Right Livelihood: no trading in weapons, living beings, meat, liquor, or poisons.

Right Effort: preventing the arising of

unwholesome states

https://en.wikipedia.org/wiki/Four\_Right\_Efforts

, and generating wholesome states, the

Seven Factors of Awakening

https://en.wikipedia.org/wiki/Seven\_Factors\_of\_Awakening

). This includes

indriya-samvara

, "guarding the sense-doors", restraint of the sense faculties.

Right Mindfulness (

Satipatthana

): a quality that guards or watches over the mind;

the stronger it becomes, the weaker unwholesome states of mind become, weakening their power "to take over and dominate thought, word and deed."

vipassana movement

https://en.wikipedia.org/wiki/Vipassana\_movement

is interpreted as "bare attention": never be absent minded, being conscious of what one is doing; this encourages the awareness of the impermanence of body, feeling and mind, as well as to experience the five aggregates (

five hindrances

https://en.wikipedia.org/wiki/Five\_hindrances

, the four True Realities and

seven factors of awakening

https://en.wikipedia.org/wiki/Seven\_factors\_of\_awakening

sampasadana

): practicing four stages of

("meditation"), which includes

proper in the second stage, and reinforces the development of the

, culminating into

(equanimity) and mindfulness.

In the Theravada tradition and the vipassana movement, this is interpreted as

, concentration or one-pointedness of the mind, and supplemented with

meditation, which aims at insight.

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=6

\]   See also:

View (Buddhism)

https://en.wikipedia.org/wiki/View\_(Buddhism)

The purpose of "right view" (

samyak-dṛṣṭi

sammā-diṭṭhi

) or "right understanding"

is to clear one's path from confusion, misunderstanding, and deluded thinking. It is a means to gain right understanding of reality.

Sequences in the suttas

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=7

The Pali canon and the Agamas contain various "definitions" or descriptions of "right view." The

Mahasatipatthana Sutta

Digha Nikaya

https://en.wikipedia.org/wiki/Digha\_Nikaya

22), compiled from elements from other suttas possibly as late as 20 BCE,

defines right view summarily as the Four Noble Truths:

And what is right view? Knowing about suffering, the origin of suffering, the cessation of suffering, and the practice that leads to the cessation of suffering. This is called right view.

In this, right view explicitly includes

https://en.wikipedia.org/wiki/Rebirth\_(Buddhism)

, and the importance of the

Four Noble Truths

https://en.wikipedia.org/wiki/Four\_Noble\_Truths

. This view of "right view" gained importance when "insight" became central to Buddhist soteriology,

and still plays an essential role in Theravada Buddhism.

Mahācattārīsaka Sutta

And what is right view? Right view is twofold, I say. There is right view that is accompanied by

defilements

https://en.wikipedia.org/wiki/Asava

, has the attributes of good deeds, and ripens in attachment. And there is right view that is noble, undefiled, transcendent, a factor of the path.

And what is right view that is accompanied by defilements, has the attributes of good deeds, and ripens in attachment? ‘There is meaning in giving, sacrifice,

and offerings. There are fruits and results of good and bad deeds. There is an afterlife. There are such things as \[serving\] mother and father, and beings \[devas\] that are reborn spontaneously. And there are ascetics and Brahmins who are well attained and practiced, and who describe the afterlife after realizing it with their own insight.’ This is right view that is accompanied by defilements, has the attributes of good deeds, and ripens in attachment.

And what is right view that is noble, undefiled, transcendent, a factor of the path? It's the wisdom—the faculty of wisdom, the power of wisdom, the awakening factor of investigation of principles \[

dhamma vicaya

\], and right view as a factor of the path—in one of noble mind and undefiled mind, who possesses the noble path and develops the noble path. This is called right view that is noble, undefiled, transcendent, a factor of the path.

They make an effort to give up wrong view and embrace right view: that's their right effort. Mindfully they give up wrong view and take up right view: that's their right mindfulness. So these three things keep running and circling around right view, namely: right view, right effort, and right mindfulness.

Other suttas give a more extensive overview, stating that our actions have consequences, that death is not the end, that our actions and beliefs also have consequences after death, and that the Buddha followed and taught a successful path out of this world and

the other world

https://en.wikipedia.org/wiki/Buddhist\_cosmology

(heaven and underworld or hell).

Mahācattārīsaka Sutta

("The Great Forty,"

Majjhima Nikaya

https://en.wikipedia.org/wiki/Majjhima\_Nikaya

gives an extensive overview, describing the first seven practices as requisites of right

. It makes a distinction between mundane right view (

) and noble right view as a path-factor, relating noble right view to

dhamma vicaya

("investigation of principles), one of the

, the "seven factors of awakening" which give an alternate account of right effort and

Alternatively, right view (together with right resolve) is expressed in the stock phrase of

dhammalsaddhalpabbajja

: "A layman hears a Buddha teach the Dhamma, comes to have faith in him, and decides to take ordination as a monk."

Sammādiṭṭhi Sutta

The venerable Sāriputta said to the venerable Mahākotthita: "Just ask, friend, knowing I shall answer." The venerable Mahākotthita said to the venerable Sāriputta: "Having accomplished what factors is a learned noble disciple in this teaching and discipline reckoned to be endowed with \[right\] view, to have accomplished straight view, to have accomplished unshakeable confidence in the Buddha, to have come to and arrived at the right teaching, to have attained this right Dharma and awoken to this right Dharma?"

The venerable Sāriputta said: "Venerable Mahākotthita, \[this takes place if\] a learned noble disciple understands unwholesome states as they really are, understands the roots of unwholesomeness as they really are, understands wholesome states as they really are and understands the roots of wholesomeness as they really are.

"How does \[a learned noble disciple\] understand unwholesome states as they really are? Unwholesome bodily actions, verbal actions and mental actions − these are reckoned unwholesome states. In this way unwholesome states are understood as they really are.

"How does \[a learned noble disciple\] understand the roots of unwholesomeness as they really are? There are three roots of unwholesomeness: greed is a root of unwholesomeness, hatred is a root of unwholesomeness, and delusion is a root of unwholesomeness − these are reckoned the roots of unwholesomeness. In this way the roots of unwholesomeness are understood as they really are.

"How does \[a learned noble disciple\] understand wholesome states as they really are? Wholesome bodily actions, verbal actions and mental actions − these are reckoned wholesome states. In this way wholesome states are understood as they really are.

"How does \[a learned noble disciple\] understand the roots of wholesomeness as they really are? That is, there are three roots of wholesomeness: non-greed, non-hatred and non-delusion − these are reckoned the roots of wholesomeness. In this way the roots of wholesomeness are understood as they really are.

"Venerable Mahākotthita, \[if\] in this way a learned noble disciple understands unwholesome states as they really are, understands the roots of unwholesomeness as they really are, understands wholesome states as they really are and understands the roots of wholesomeness as they really are; then, for this reason, \[a learned noble disciple\] in this teaching and discipline is endowed with right view, has accomplished straight view, has accomplished unshakeable confidence in the Buddha, has come to and arrived at the right teaching, has attained this right Dharma and awoken to this right Dharma."

Likewise, the

Sammādiṭṭhi Sutta

https://en.wikipedia.org/wiki/Samm%C4%81di%E1%B9%AD%E1%B9%ADhi\_Sutta

(Majjhima Nikaya 9), and its parallel in the

Samyukta-āgama

, refer to faith in the Buddha and understanding (

dhamma vicaya

) the path-factors of wholesome bodily actions, verbal actions and mental actions.

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=8

Right View can be further subdivided, states translator Bhikkhu Bodhi, into mundane right view and superior or supramundane right view:

Mundane right view, knowledge of the fruits of good behavior (

). Having this type of view will bring merit and will support the favourable rebirth of the sentient being in the realm of

https://en.wikipedia.org/wiki/Samsara\_(Buddhism)

Supramundane (world-transcending) right view, the understanding of the Four Noble Truths, leading to awakening and liberation from rebirths and associated

https://en.wikipedia.org/wiki/Dukkha

in the realms of samsara.

According to Bhikkhu Bodhi, this kind of right view comes at the end of the path, not at the beginning.

According to Theravada Buddhism, mundane right view is a teaching that is suitable for lay followers, while supramundane right view, which requires a deeper understanding, is suitable for monastics.

Mundane and supramundane right view involve accepting the following doctrines of Buddhism:

: Every action of body, speech, and mind has

https://en.wikipedia.org/wiki/Karma

results, and influences the kind of future rebirths and realms a being enters into.

Three marks of existence

https://en.wikipedia.org/wiki/Karma

: everything, whether physical or mental, is impermanent (

), a source of suffering (

), and lacks a self (

Four Noble Truths

https://en.wikipedia.org/wiki/Four\_Noble\_Truths

are a means to gaining insights and ending

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=9

Gombrich notes that there is a tension in the suttas between "right view" and 'no view', release by not clinging to any view at all.

According to Chryssides and Wilkins, "right view is ultimately non-view: though the Enlightened One sees things as they really are, 'he has a "critical awareness" of the impossibility of giving full and final expression to his conviction in fixed conceptual terms'. One therefore cannot cling to any particular formulation in a rigid and dogmatic manner."

Right resolve

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=10

Right Resolve (

samyak-saṃkalpa

sammā-saṅkappa

) can also be known as "right thought", "right aspiration", or "right motivation".

In this factor, the practitioner resolves to leave home, renounce the worldly life and dedicate himself to an ascetic pursuit.

In section III.248, the Majjhima Nikaya states,

And what is right resolve? Being resolved on renunciation, on freedom from ill will, on harmlessness: This is called right resolve.

Like right view, this factor has two levels. At the mundane level, the resolve includes being harmless (

https://en.wikipedia.org/wiki/Ahimsa

) and refraining from ill will (

) to any being, as this accrues karma and leads to rebirth.

At the supramundane level, the factor includes a resolve to consider everything and everyone as impermanent, a source of suffering and without a Self.

Right speech

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=11

\]   Part of

Theravāda Abhidhamma

https://en.wikipedia.org/wiki/Theravada\_Abhidhamma

https://en.wikipedia.org/wiki/Mental\_factors#Theravāda\_Abhidhamma\_tradition

Theravāda Buddhism

https://en.wikipedia.org/wiki/Mental\_factors#Theravāda\_Abhidhamma\_tradition

7 universal  (

sabbacittasādhāraṇa

Jīvitindriya

6 occasional  (

14 unwholesome  (

4 universal unwholesome  (

akusalasādhāraṇa

3 greed-group  (

4 hatred-group  (

other unwholesome:

25 beautiful  (

19 universal beautiful  (

sobhanasādhāraṇa

Tatramajjhattatā

Kāyapassaddhi

Cittapassaddhi

Cittalahutā

Cittamudutā

Kāyakammaññatā

Cittakammaññatā

Kāyapāguññatā

Cittapāguññatā

Cittujukatā

3 abstinences  (

Sammākammanta

Sammā-ājīva

2 immeasurables  (

1 faculty of wisdom  (

paññindriya

Buddhism portal

Right speech (

) in most Buddhist texts is presented as four abstentions, such as in the Pali Canon thus:

And what is right speech? Abstaining from lying, from divisive speech, from abusive speech, and from idle chatter: This is called right speech.

Instead of the usual "abstention and refraining from wrong" terminology, a few texts such as the

Samaññaphala Sutta

https://en.wikipedia.org/wiki/Sama%C3%B1%C3%B1aphala\_Sutta

and Kevata Sutta in

Digha Nikaya

explain this virtue in an active sense, after stating it in the form of an abstention.

For example, Samaññaphala Sutta states that a part of a monk's virtue is that "he abstains from false speech. He speaks the truth, holds to the truth, is firm, reliable, no deceiver of the world."

Similarly, the virtue of abstaining from divisive speech is explained as delighting in creating concord.

The virtue of abstaining from abusive speech is explained in this Sutta to include affectionate and polite speech that is pleasing to people. The virtue of abstaining from idle chatter is explained as speaking what is connected with the Dhamma goal of his liberation.

Abhaya-raja-kumara Sutta

, the Buddha explains the virtue of right speech in different scenarios, based on its truth value, utility value and emotive content.

, states Abhaya Sutta, never speaks anything that is unfactual or factual, untrue or true, disagreeable or agreeable, if that is unbeneficial and unconnected to his goals.

Further, adds Abhaya Sutta, the

speaks the factual, the true, if in case it is disagreeable and unendearing, only if it is beneficial to his goals, but with a sense of proper time.

Additionally, adds Abhaya Sutta, the

, only speaks with a sense of proper time even when what he speaks is the factual, the true, the agreeable, the endearing and what is beneficial to his goals.

The Buddha thus explains right speech in the Pali Canon, according to Ganeri, as never speaking something that is not beneficial; and, only speaking what is true and beneficial, "when the circumstances are right, whether they are welcome or not".

Right action

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=12

Right action (

samyak-karmānta

sammā-kammanta

) is like right speech, expressed as abstentions but in terms of bodily action. In the Pali Canon, this path factor is stated as:

And what is right action? Abstaining from killing, abstaining from stealing, abstaining from sexual misconduct. This is called right action.

The prohibition on killing precept in Buddhist scriptures applies to all

living beings

https://en.wikipedia.org/wiki/Sentient\_beings\_(Buddhism)

, states Christopher Gowans, not just

human beings

https://en.wikipedia.org/wiki/Human\_beings\_in\_Buddhism

Bhikkhu Bodhi agrees, clarifying that the more accurate rendering of the Pali canon is a prohibition on "taking life of any sentient being", which includes human beings, animals, birds, insects but excludes plants because they are not considered sentient beings. Further, adds Bodhi, this precept refers to

intentional

killing, as well as any form of intentional harming or torturing any sentient being. This moral virtue in early Buddhist texts, both in context of harm or killing of animals and human beings, is similar to

precepts found in the texts particularly of Jainism as well as of Hinduism,

and has been a subject of significant debate in various Buddhist traditions.

The prohibition on stealing in the Pali Canon is an abstention from intentionally taking what is not voluntarily offered by the person to whom that property belongs. This includes taking by stealth, by force, by fraud or by deceit. Both the intention and the act matters, as this precept is grounded on the impact on one's karma.

The prohibition on sexual misconduct in the Noble Eightfold Path refers to "not performing sexual acts".

This virtue is more generically explained in the

Cunda Kammaraputta Sutta

, which teaches that one must abstain from all sensual misconduct, including getting sexually involved with someone unmarried (anyone protected by parents or by guardians or by siblings), and someone married (protected by husband), and someone betrothed to another person, and female convicts or by

For monastics, the abstention from sensual misconduct means strict celibacy while for lay Buddhists this prohibits adultery as well as other forms of sensual misconduct.

Later Buddhist texts state that the prohibition on sexual conduct for lay Buddhists includes any sexual involvement with someone married, a girl or woman protected by her parents or relatives, and someone prohibited by

conventions (such as relatives, nuns and others).

Right livelihood

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=13

Right livelihood (

samyag-ājīva

sammā-ājīva

) precept is mentioned in many early Buddhist texts, such as the

Mahācattārīsaka Sutta

Majjhima Nikaya

as follows:

And what is right livelihood? Right livelihood, I tell you, is of two sorts: There is right livelihood with effluents, siding with merit, resulting in acquisitions; there is right livelihood that is noble, without effluents, transcendent, a factor of the path.

And what is the right livelihood with effluents, siding with merit, resulting in acquisitions? There is the case where a disciple of the noble ones abandons wrong livelihood and maintains his life with right livelihood. This is the right livelihood with effluents, siding with merit, resulting in acquisitions.

And what is the right livelihood that is noble, without effluents, transcendent, a factor of the path? The abstaining, desisting, abstinence, avoidance of wrong livelihood in one developing the noble path whose mind is noble, whose mind is without effluents, who is fully possessed of the noble path. (...)

The early canonical texts state right livelihood as avoiding and abstaining from wrong livelihood. This virtue is further explained in Buddhist texts, states Vetter, as "living from begging, but not accepting everything and not possessing more than is strictly necessary".

For lay Buddhists, this precept requires that the livelihood avoid causing suffering to sentient beings by cheating them, or harming or killing them in any way.

The Anguttara Nikaya III.208 asserts that the right livelihood does not trade in weapons, living beings, meat, alcoholic drink or poison.

The same text, in section V.177, asserts that this applies to lay Buddhists.

This has meant, states Harvey, that raising and trading cattle livestock for slaughter is a breach of "right livelihood" precept in the Buddhist tradition, and Buddhist countries lack the mass slaughter houses found in Western countries.

Right effort

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=14

\]   See also:

Four Right Efforts

https://en.wikipedia.org/wiki/Four\_Right\_Efforts

https://en.wikipedia.org/wiki/Viriya

dhamma vicaya

https://en.wikipedia.org/wiki/Dhamma\_vicaya

Examination of conscience

https://en.wikipedia.org/wiki/Examination\_of\_conscience

Right effort (

samyag-vyāyāma

sammā-vāyāma

) is preventing the arising of

unwholesome states

https://en.wikipedia.org/wiki/Four\_Right\_Efforts

, and the generation of

wholesome states

https://en.wikipedia.org/wiki/Four\_Right\_Efforts

. This includes

indriya-samvara

, "guarding the sense-doors", restraint of the sense faculties.

Right effort is presented in the Pali Canon, such as the

Sacca-vibhanga Sutta

, as follows:

And what is right effort?

Here the monk arouses his will, puts forth effort, generates energy, exerts his mind, and strives to prevent the arising of evil and unwholesome mental states that have not yet arisen.

He arouses his will... and strives to eliminate evil and unwholesome mental states that have already arisen. He arouses his will... and strives to generate wholesome mental states that have not yet arisen.

He arouses his will, puts forth effort, generates energy, exerts his mind, and strives to maintain wholesome mental states that have already arisen, to keep them free of delusion, to develop, increase, cultivate, and perfect them.

This is called right effort.

The unwholesome states (

) are described in the Buddhist texts are related to thoughts, emotions, intentions. These include the

pancanivarana

five hindrances

https://en.wikipedia.org/wiki/Five\_hindrances

), that is, sensual thoughts, doubts about the path, restlessness, drowsiness, and ill will of any kind.

Of these, the Buddhist traditions consider sensual thoughts and ill will needing more right effort. Sensual desire that must be eliminated by effort includes anything related to sights, sounds, smells, tastes and touch. This is to be done by restraint of the sense faculties (

indriya-samvara

). Ill will that must be eliminated by effort includes any form of aversion including hatred, anger, resentment towards anything or anyone.

Right mindfulness

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=15

\]   Main article:

Mindfulness (Buddhism)

https://en.wikipedia.org/wiki/Mindfulness\_(Buddhism)

https://en.wikipedia.org/wiki/Sampaja%C3%B1%C3%B1a

Dhamma vicaya

https://en.wikipedia.org/wiki/Dhamma\_vicaya

Satipatthana

https://en.wikipedia.org/wiki/Satipatthana

Anapanasati

https://en.wikipedia.org/wiki/Anapanasati

Satipatthana Sutta

https://en.wikipedia.org/wiki/Satipatthana\_Sutta

While originally, in Yogic practice,

may have meant to remember the meditation object, to cultivate a deeply absorbed, secluded state of mind,

in the oldest Buddhism it has the meaning of "retention", being mindful of the

(both wholesome states of mind, and teachings and practices that remind of those wholesome states of mind) that are beneficial to the Buddhist path.

According to Gethin,

is a quality that guards or watches over the mind;

the stronger it becomes, the weaker unwholesome states of mind become, weakening their power "to take over and dominate thought, word and deed."

According to

Frauwallner

https://en.wikipedia.org/wiki/Erich\_Frauwallner

, mindfulness was a means to prevent the arising of craving, which resulted simply from contact between the senses and their objects. According to Frauwallner this may have been the Buddha's original idea.

According to Trainor, mindfulness aids one not to crave and cling to any transitory state or thing, by complete and constant awareness of phenomena as impermanent, suffering and without self.

Gethin refers to the

Milindapanha

, which states that

brings to mind the

and their beneficial or unbeneficial qualities, aiding the removal of unbeneficial dhammas and the strengthening of beneficial dhammas.

Gethin further notes that

makes one aware of the "full range and extent of

", that is, the relation between things, broadening one's view and understanding.

Satipatthana Sutta

describes the contemplation of

four domains

https://en.wikipedia.org/wiki/Satipatthana

, namely body, feelings, mind and phenomena.

Satipatthana Sutta

is regarded by the vipassana movement as the quintessential text on Buddhist meditation, taking cues from it on "bare attention" and the contemplation on the observed phenomena as

According to Grzegorz Polak, the four

have been misunderstood by the developing Buddhist tradition, including Theravada, to refer to four different foundations. According to Polak, the four

do not refer to four different foundations of which one should be aware, but are an alternate description of the

, describing how the

are tranquilized:

six sense-bases

https://en.wikipedia.org/wiki/Ayatana

which one needs to be aware of (

kāyānupassanā

contemplation on

https://en.wikipedia.org/wiki/Vedan%C4%81

, which arise with the contact between the senses and their objects (

vedanānupassanā

the altered states of mind to which this practice leads (

cittānupassanā

the development from the

five hindrances

https://en.wikipedia.org/wiki/Five\_hindrances

seven factors of enlightenment

https://en.wikipedia.org/wiki/Seven\_factors\_of\_enlightenment

dhammānupassanā

vipassana movement

https://en.wikipedia.org/wiki/Vipassana\_movement

, mindfulness (

samyak-smṛti

) is interpreted as "bare attention": never be absent minded, being conscious of what one is doing.

Rupert Gethin

notes that the contemporary vipassana movement interprets the

Satipatthana Sutta

as "describing a pure form of insight (

) meditation" for which

are not necessary. Yet, in

pre-sectarian Buddhism

https://en.wikipedia.org/wiki/Pre-sectarian\_Buddhism

, the establishment of mindfulness was placed before the practice of the

, and associated with the abandonment of the

five hindrances

https://en.wikipedia.org/wiki/Five\_hindrances

and the entry into the first

\[ note 10 \]

-scheme describes mindfulness also as appearing in the third and fourth

, after initial concentration of the mind.

\[ note 11 \]

Gombrich and Wynne note that, while the second

denotes a state of absorption, in the third and fourth

one comes out of this absorption, being mindfully aware of objects while being indifferent to them.

\[ note 12 \]

According to Gombrich, "the later tradition has falsified the jhana by classifying them as the quintessence of the concentrated, calming kind of meditation, ignoring the other – and indeed higher – element".

Right samadhi (unification of mind)

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=16

\]   Main article:

Dhyāna in Buddhism

https://en.wikipedia.org/wiki/Dhy%C4%81na\_in\_Buddhism

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=17

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=17

samyak-samādhi

sammā-samādhi

) is a common practice or goal in Indian religions. The term

derives from the root sam-a-dha, which means 'to collect' or 'bring together',

citation needed

and thus it is often translated as 'concentration' or 'unification of mind'. In the early Buddhist texts, samadhi is also associated with the term "

https://en.wikipedia.org/wiki/Samatha

" (calm abiding).

citation needed

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=18

Bronkhorst notes that neither the Four Noble Truths nor the Noble Eightfold Path discourse provide details of right

, such as the following in

Saccavibhanga Sutta

, equate it with

And what is right concentration?

\[i\] Here, the monk, detached from sense-desires, detached from unwholesome states, enters and remains in the first

(level of concentration, Sanskrit:

), in which there is applied and sustained thinking, together with joy and pleasure born of detachment;

\[ii\] And through the subsiding of applied and sustained thinking, with the gaining of inner stillness and oneness of mind, he enters and remains in the second

, which is without applied and sustained thinking, and in which there are joy and pleasure born of concentration;

\[iii\] And through the fading of joy, he remains equanimous, mindful and aware, and he experiences in his body the pleasure of which the Noble Ones say: "equanimous, mindful and dwelling in pleasure", and thus he enters and remains in the third

\[iv\] And through the giving up of pleasure and pain, and through the previous disappearance of happiness and sadness, he enters and remains in the fourth

, which is without pleasure and pain, and in which there is pure equanimity and mindfulness.

This is called right concentration.

Bronkhorst has questioned the historicity and chronology of the description of the four

. Bronkhorst states that this path may be similar to what the Buddha taught, but the details and the form of the description of the

in particular, and possibly other factors, is likely the work of later scholasticism.

Bronkhorst notes that description of the third

cannot have been formulated by the Buddha, since it includes the phrase "Noble Ones say", quoting earlier Buddhists, indicating it was formulated by later Buddhists.

It is likely that later Buddhist scholars incorporated this, then attributed the details and the path, particularly the insights at the time of liberation, to have been discovered by the Buddha.

Concentration

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=19

In the Theravada tradition,

is interpreted as concentration on a meditation object.

https://en.wikipedia.org/wiki/Buddhagosa

defines samadhi as "the centering of consciousness and consciousness concomitants evenly and rightly on a single object...the state in virtue of which consciousness and its concomitants remain evenly and rightly on a single object, undistracted and unscattered."

According to Henepola Gunaratana, in the suttas samadhi is defined as one-pointedness of mind (

Cittass'ekaggatā

According to

Bhikkhu Bodhi

https://en.wikipedia.org/wiki/Bhikkhu\_Bodhi

, the right concentration factor is reaching a one-pointedness of mind and unifying all mental factors, but it is not the same as "a gourmet sitting down to a meal, or a soldier on the battlefield" who also experience one-pointed concentration. The difference is that the latter have a one-pointed object in focus with complete awareness directed to that object – the meal or the target, respectively. In contrast, right concentration meditative factor in Buddhism is a state of awareness without any object or subject, and ultimately unto no-thingness and emptiness, as articulated in apophatic discourse.

Development into equanimity

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=20

Although often translated as "concentration", as in the limiting of the attention of the mind on one object, in the fourth

"equanimity and mindfulness remain",

and the practice of concentration-meditation may well have been incorporated from non-Buddhist traditions.

Vetter notes that

consists of the

four stages of awakening

https://en.wikipedia.org/wiki/Four\_stages\_of\_awakening

...to put it more accurately, the first dhyana seems to provide, after some time, a state of strong concentration, from which the other stages come forth; the second stage is called samadhija.

Gombrich and Wynne note that, while the second

denotes a state of absorption, in the third and fourth

one comes out of this absorption, being mindfully awareness of objects while being indifferent to it.

According to Gombrich, "the later tradition has falsified the jhana by classifying them as the quintessence of the concentrated, calming kind of meditation, ignoring the other – and indeed higher – element."

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=21

Following the Noble Eightfold Path leads to

https://en.wikipedia.org/wiki/Moksha

in the form of

https://en.wikipedia.org/wiki/Nirvana

And what is that ancient path, that ancient road, traveled by the Rightly Self-awakened Ones of former times? Just this noble eightfold path: right view, right aspiration, right speech, right action, right livelihood, right effort, right mindfulness, right concentration. That is the ancient path, the ancient road, traveled by the Rightly Self-awakened Ones of former times. I followed that path. Following it, I came to direct knowledge of aging & death, direct knowledge of the origination of aging & death, direct knowledge of the cessation of aging & death, direct knowledge of the path leading to the cessation of aging & death. I followed that path. Following it, I came to direct knowledge of birth... becoming... clinging... craving... feeling... contact... the six sense media... name-&-form... consciousness, direct knowledge of the origination of consciousness, direct knowledge of the cessation of consciousness, direct knowledge of the path leading to the cessation of consciousness. I followed that path.

—  The Buddha, Nagara Sutta,

Samyutta Nikaya ii.124

, Translated by Thanissaro Bhikkhu

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=22

Order of practice

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=23

Vetter notes that originally the path culminated in the practice of

dhyana/samadhi

as the core soteriological practice.

According to the Pali and Chinese canon, the

state (right concentration) is dependent on the development of preceding path factors:

The Blessed One said: "Now what, monks, is noble right concentration with its supports and requisite conditions? Any singleness of mind equipped with these seven factors – right view, right resolve, right speech, right action, right livelihood, right effort, and right mindfulness – is called noble right concentration with its supports and requisite conditions.

—  Maha-cattarisaka Sutta

According to the discourses, right view, right resolve, right speech, right action, right livelihood, right effort, and right mindfulness are used as the support and requisite conditions for the practice of right concentration. Understanding of the right view is the preliminary role, and is also the forerunner of the entire Noble Eightfold Path.

According to the modern Theravada

https://en.wikipedia.org/wiki/Bhikkhu

and scholar

Walpola Rahula

https://en.wikipedia.org/wiki/Walpola\_Rahula

, the divisions of the noble eightfold path "are to be developed more or less simultaneously, as far as possible according to the capacity of each individual. They are all linked together and each helps the cultivation of the others."

Bhikkhu Bodhi explains that these factors are not sequential, but components, and "with a certain degree of progress all eight factors can be present simultaneously, each supporting the others. However, until that point is reached, some sequence in the unfolding of the path is inevitable."

The stage in the Path where there is no more learning in

https://en.wikipedia.org/wiki/Yogachara

Abhidharma, state Buswell and Gimello, is identical to

, the ultimate goal in Buddhism.

Sila-samadhi-prajna

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=24

The Noble Eightfold Path is sometimes divided into

three basic divisions

https://en.wikipedia.org/wiki/Three\_disciplines\_of\_Buddhism

, with right view and right resolve concluding the sequence:

Division   Eightfold Path factors  Moral virtue

Right speech

https://en.wikipedia.org#Right\_speech

Right action

https://en.wikipedia.org#Right\_action

Right livelihood

https://en.wikipedia.org#Right\_livelihood

(Sanskrit and Pāli:

Right effort

https://en.wikipedia.org#Right\_effort

Right mindfulness

https://en.wikipedia.org#Right\_mindfulness

Right concentration

https://en.wikipedia.org#Right\_concentration

#### Insight, wisdom (Sanskrit:

https://en.wikipedia.org#Right\_view

Right resolve

https://en.wikipedia.org#Right\_resolve

This order is a later development, when discriminating insight (

) became central to Buddhist soteriology, and came to be regarded as the culmination of the Buddhist path.

Yet, Majjhima Nikaya 117,

Mahācattārīsaka Sutta

, describes the first seven practices as requisites for right samadhi. According to Vetter, this may have been the original soteriological practice in early Buddhism.

moral virtues

https://en.wikipedia.org/wiki/Buddhist\_ethics

" (Sanskrit:

) group consists of three paths: right speech, right action and right livelihood.

, though translated by English writers as linked to "morals or ethics", states Bhikkhu Bodhi, is in ancient and medieval Buddhist commentary tradition closer to the concept of discipline and disposition that "leads to harmony at several levels – social, psychological, karmic and contemplative". Such harmony creates an environment to pursue the meditative steps in the Noble Eightfold Path by reducing social disorder, preventing inner conflict that result from transgressions, favoring future karma-triggered movement through better rebirths, and purifying the mind.

The meditation group ("samadhi") of the path progresses from moral restraints to training the mind.

Right effort and mindfulness calm the mind-body complex, releasing unwholesome states and habitual patterns and encouraging the development of wholesome states and non-automatic responses, the

(seven factors of awakening). The practice of

reinforces these developments, leading to

(equanimity) and mindfulness.

According to the Theravada commentarial tradition and the contemporary vipassana movement, the goal in this group of the Noble Eightfold Path is to develop clarity and insight into the nature of reality –

, discard negative states and dispel

(ignorance), ultimately attaining

In the threefold division,

(insight, wisdom) is presented as the culmination of the path, whereas in the eightfold division the path starts with correct knowledge or insight, which is needed to understand why this path should be followed.

Schools of Buddhism and their views of the Eightfold Path

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=25

Theravada presentations of the path

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=26

Theravada Buddhism is a diverse tradition and thus includes different explanations of the path to awakening. However, the teachings of the Buddha are often encapsulated by Theravadins in the basic framework of the Four Noble Truths and the Eighthfold Path.

Some Theravada Buddhists also follow the presentation of the path laid out in

Buddhaghosa's

https://en.wikipedia.org/wiki/Buddhaghosa

Visuddhimagga

https://en.wikipedia.org/wiki/Buddhaghosa

. This presentation is known as the "Seven Purifications" (

satta-visuddhi

This schema and its accompanying outline of "insight knowledges" (

vipassanā-ñāṇa

) is used by modern influential Theravadin scholars, such

Mahasi Sayadaw

https://en.wikipedia.org/wiki/Mahasi\_Sayadaw

(in his "The Progress of Insight") and

Nyanatiloka Thera

https://en.wikipedia.org/wiki/Nyanatiloka

(in "The Buddha's Path to Deliverance").

Mahayana presentations of the path

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=27

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=27

Buddhism is based principally upon the path of a

Bodhisattva

https://en.wikipedia.org/wiki/Bodhisattva

Bodhisattva

refers to one who is on the path to buddhahood.

was originally a synonym for

Bodhisattvayāna

or "Bodhisattva Vehicle".

In the earliest texts of Mahāyāna Buddhism, the path of a bodhisattva was to awaken the

Between the 1st and 3rd century CE, this tradition introduced the

doctrine, which means ten levels or stages of awakening.

This development was followed by the acceptance that it is impossible to achieve Buddhahood in one (current) lifetime, and the best goal is not nirvana for oneself, but Buddhahood after climbing through the ten levels during multiple rebirths.

Mahāyāna scholars then outlined an elaborate path, for monks and laypeople, and the path includes the vow to help teach Buddhist knowledge to other beings, so as to help them cross samsara and liberate themselves, once one reaches the Buddhahood in a future rebirth.

One part of this path are the

(perfections, to cross over), derived from the

tales of Buddha's numerous rebirths.

The doctrine of the bodhisattva bhūmis was also eventually merged with the

Sarvāstivāda Vaibhāṣika

https://en.wikipedia.org/wiki/Vaibh%C4%81%E1%B9%A3ika

schema of the "five paths" by the

https://en.wikipedia.org/wiki/Yogachara

This Mahāyāna "five paths" presentation can be seen in

https://en.wikipedia.org/wiki/Asanga

Mahāyānasaṃgraha

https://en.wikipedia.org/wiki/Asanga

The Mahāyāna texts are inconsistent in their discussion of the

, and some texts include lists of two, others four, six, ten and fifty-two.

#### The six paramitas have been most studied, and these are:

: perfection of giving; primarily to monks, nuns and the Buddhist monastic establishment dependent on the alms and gifts of the lay householders, in return for generating religious merit;

some texts recommend ritually transferring the merit so accumulated for better rebirth to someone else

: perfection of morality; it outlines ethical behaviour for both the laity and the Mahayana monastic community; this list is similar to Śīla in the Eightfold Path (i.e. Right Speech, Right Action, Right Livelihood)

: perfection of patience, willingness to endure hardship

: perfection of vigour; this is similar to Right Effort in the Eightfold Path

: perfection of meditation; this is similar to Right Concentration in the Eightfold Path

: perfection of insight (wisdom), awakening to the characteristics of existence such as karma, rebirths, impermanence, no-self, dependent origination and emptiness;

this is complete acceptance of the Buddha teaching, then conviction, followed by ultimate realisation that "dharmas are non-arising".

In Mahāyāna Sutras that include ten

, the additional four perfections are "skillful means, vow, power and knowledge".

The most discussed

and the highest rated perfection in Mahayana texts is the "Prajna-paramita", or the "perfection of insight".

This insight in the Mahāyāna tradition, states Shōhei Ichimura, has been the "insight of non-duality or the absence of reality in all things".

East Asian Buddhism

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=28

East Asian Buddhism

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=28

is influenced by both the classic Indian Buddhist presentations of the path such as the Eightfold Path as well as classic Indian Mahāyāna presentations such as that found in the

Da zhidu lun

https://en.wikipedia.org/wiki/Da\_zhidu\_lun

There are many different presentations of

soteriology

https://en.wikipedia.org/wiki/Soteriology

, including numerous paths and vehicles (

) in the different traditions of East Asian Buddhism.

There is no single dominant presentation. In

Zen Buddhism

https://en.wikipedia.org/wiki/Zen\_Buddhism

for example, one can find outlines of the path such as the

Two Entrances and Four Practices

https://en.wikipedia.org/wiki/Long\_Scroll\_of\_the\_Treatise\_on\_the\_Two\_Entrances\_and\_Four\_Practices

https://en.wikipedia.org/wiki/Five\_Ranks

Ten Ox-Herding Pictures

https://en.wikipedia.org/wiki/Ten\_Bulls

The Three mysterious Gates

https://en.wikipedia.org/wiki/Linji\_Yixuan#Expressing\_the\_inexpressible

Indo-Tibetan Buddhism

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=29

In Indo-Tibetan Buddhism, the path to liberation is outlined in the genre known as

https://en.wikipedia.org/wiki/Lamrim

("Stages of the Path"). All the various Tibetan schools have their own Lamrim presentations. This genre can be traced to

https://en.wikipedia.org/wiki/Atisha

's 11th-century

A Lamp for the Path to Enlightenment

Bodhipathapradīpa

Cognitive psychology

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=30

The noble eightfold path has been compared to

cognitive psychology

https://en.wikipedia.org/wiki/Cognitive\_psychology

; Gil Fronsdal says the right view factor can be interpreted to mean how one's mind views the world, and how that leads to patterns of thought, intention and actions.

Peter Randall states that it is the seventh factor or right mindfulness that may be thought in terms of cognitive psychology, wherein the change in thought and behavior are linked.

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=31

Ashtanga (eight limbs of yoga)

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=31

Bodhipakkhiyādhammā

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=31

(thirty-seven qualities for awakening)

Four Right Exertions

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=31

Mangala Sutta

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=31

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=31

(body, speech and mind)

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=32

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=32

One of those longer sequences, from the

CulaHatthipadopama-sutta

, the "Lesser Discourse on the Simile of the Elephant's Footprints", is as follows:

Dhammalsaddhalpabbajja

: A layman hears a Buddha teach the Dhamma, comes to have faith in him, and decides to take ordination as a monk;

: He adopts the moral precepts;

indriyasamvara

: He practises "guarding the six sense-doors";

sati-sampajanna

: He practises mindfulness and self-possession (actually described as mindfulness of the body, kāyānussatti);

: He finds an isolated spot in which to meditate, purifies his mind of the hindrances (nwarana), and attains the first rupa-jhana;

: He attains the second jhana;

: He attains the third jhana;

: He attains the fourth jhana;

pubbenivasanussati-nana

: he recollects his many former existences in samsara;

sattanam cutupapata-nana

: he observes the death and rebirth of beings according to their karmas;

dsavakkhaya-nana

: He brings about the destruction of the dsavas (cankers), and attains a profound realization of (as opposed to mere knowledge about) the four noble truths;

: He perceives that he is now liberated, that he has done what was to be done.

A similar sequence can be found in the

Samaññaphala Sutta

https://en.wikipedia.org/wiki/Sama%C3%B1%C3%B1aphala\_Sutta

According to Frauwallner, mindfulness was a means to prevent the arising of craving, which resulted simply from contact between the senses and their objects; this may have been the Buddha's original idea;

https://en.wikipedia.org/wiki/Buddhadasa

Heartwood of the Bodhi-tree

Pratītyasamutpāda

https://en.wikipedia.org/wiki/Prat%C4%ABtyasamutp%C4%81da

; and Grzegorz Polak (2011),

Reexamining Jhana: Towards a Critical Reconstruction of Early Buddhist Soteriology

, p.153-156, 196–197.

Vetter translates it as "offering into the fire".

Compare the stock sequence of a "graduated talk" and "the distinctive teaching of the Awakened Ones": "Then the Blessed One gave a graduated talk to Upāli the householder, i.e., a talk on giving, a talk on virtue, a talk on heaven; he proclaimed the drawbacks of, degradation in, & defilement in sensuality, and the rewards of renunciation. Then—when he knew that Upāli the householder was of ready mind, malleable mind, unhindered mind, exultant mind, confident mind—he proclaimed to him the distinctive teaching of the Awakened Ones: stress, origination, cessation, path. Just as a white cloth with stains removed would rightly take dye, in the same way there arose to Upāli the householder, in that very seat, the dustless, stainless Dhamma eye: Whatever is subject to origination is all subject to cessation. Then—having seen the Dhamma, having reached the Dhamma, known the Dhamma, gained a footing in the Dhamma, having crossed over & beyond doubt, having had no more questioning—Upāli the householder gained fearlessness and was independent of others with regard to the Teacher’s message."

CulaHatthipadopama-sutta

(the "Lesser Discourse on the Simile of the Elephant's Footprints") and the

Samaññaphala Sutta

https://en.wikipedia.org/wiki/Sama%C3%B1%C3%B1aphala\_Sutta

https://en.wikipedia.org/wiki/Sama%C3%B1%C3%B1aphala\_Sutta

The formula is repeated in other sutras, for example the

Sacca-vibhanga Sutta

(MN 141): "And what is right mindfulness?

Here the monk remains contemplating the body as body, resolute, aware and mindful, having put aside worldly desire and sadness;

he remains contemplating feelings as feelings;

he remains contemplating mental states as mental states;

he remains contemplating mental objects as mental objects, resolute, aware and mindful, having put aside worldly desire and sadness;

This is called right mindfulness."

From The Way of Mindfulness, The

Satipatthana Sutta

and Its Commentary, Soma Thera (1998),

the dull-witted man of the theorizing type \[ditthi carita\] it is convenient to see consciousness \[citta\] in the fairly simple way it is set forth in this discourse, by way of impermanence \[

\], and by way of such divisions as mind-with-lust \[saragadi vasena\], in order to reject the notion of permanence \[nicca sañña\] in regard to consciousness. Consciousness is a special condition \[visesa karana\] for the wrong view due to a basic belief in permanence \[niccanti abhinivesa vatthutaya ditthiya\]. The contemplation on consciousness, the Third Arousing of Mindfulness, is the Path to Purity of this type of man.

the keen-witted man of the theorizing type it is convenient to see mental objects or things \[dhamma\], according to the manifold way set forth in this discourse, by way of perception, sense-impression and so forth \[nivaranadi vasena\], in order to reject the notion of a soul \[

\] in regard to mental things. Mental things are special conditions for the wrong view due to a basic belief in a soul \[attanti abhinivesa vatthutaya ditthiya\]. For this type of man the contemplation on mental objects, the Fourth Arousing of Mindfulness, is the Path to Purity.

Vetter and Bronkhorst note that the path

with right view, which includes insight into

kāyānupassanā

vedanānupassanā

cittānupassanā

, resemble the

five skandhas

https://en.wikipedia.org/wiki/Skandha

and the chain of causation as described in the middle part of

Pratītyasamutpāda

https://en.wikipedia.org/wiki/Prat%C4%ABtyasamutp%C4%81da

dhammānupassanā

refers to mindfulness as retention, calling into mind the beneficial

which are applied to analyse phenomena, and counter the arising of disturbing thoughts and emotions.

Gethin: "The sutta is often read today as describing a pure form of insight (

) meditation that bypasses calm (

https://en.wikipedia.org/wiki/Samatha

) meditation and the four absorptions (

), as outlined in the description of the Buddhist path found, for example, in the

Samaññaphala Sutta

https://en.wikipedia.org/wiki/Sama%C3%B1%C3%B1aphala\_Sutta

\[...\]. The earlier tradition, however, seems not to have always read it this way, associating accomplishment in the exercise of establishing mindfulness with abandoning of the

five hindrances

https://en.wikipedia.org/wiki/Five\_hindrances

and the first absorption."

Original publication:  Gombrich, Richard (2007).

Religious Experience in Early Buddhism

. OCHS Library.

https://web.archive.org/web/20160701190900/http://www.ochs.org.uk/lectures/religious-experience-early-buddhism

from the original on 1 July 2016 . Retrieved  12 October  2018 .

https://web.archive.org/web/20160701190900/http://www.ochs.org.uk/lectures/religious-experience-early-buddhism

Original publication:  Gombrich, Richard (2007).

Religious Experience in Early Buddhism

. OCHS Library.

https://web.archive.org/web/20160701190900/http://www.ochs.org.uk/lectures/religious-experience-early-buddhism

from the original on 1 July 2016 . Retrieved  12 October  2018 .

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=33

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=33

Brekke, Torkel. "The Religious Motivation of the Early Buddhists". Journal of the American Academy of Religion, Vol. 67, No. 4 (Dec. 1999), p. 860

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=33

www.wisdomlib.org (18 October 2018).

"Aryashtangamarga, Arya-ashtanga-marga, Āryāṣṭāṅgamārga: 6 definitions"

https://www.wisdomlib.org/definition/aryashtangamarga

www.wisdomlib.org

https://web.archive.org/web/20230724104103/https://www.wisdomlib.org/definition/aryashtangamarga

from the original on 24 July 2023 . Retrieved  24 July  2023 .

https://web.archive.org/web/20230724104103/https://www.wisdomlib.org/definition/aryashtangamarga

www.wisdomlib.org (5 July 2019).

"Samyag-marga, Samyagmārga, Samyanc-marga: 2 definitions"

https://www.wisdomlib.org/definition/samyag-marga

www.wisdomlib.org

https://web.archive.org/web/20230724104103/https://www.wisdomlib.org/definition/samyag-marga

from the original on 24 July 2023 . Retrieved  24 July  2023 .

https://web.archive.org/web/20230724104103/https://www.wisdomlib.org/definition/samyag-marga

Gethin 1998

https://web.archive.org/web/20230724104103/https://www.wisdomlib.org/definition/samyag-marga

, pp. 81–83.

Anderson 2013

https://en.wikipedia.org#cite\_ref-FOOTNOTEAnderson201364–65\_5-0

, pp. 64–65.

https://en.wikipedia.org#cite\_ref-FOOTNOTELopez2009136-137\_6-0

, p. 136-137.

Stephen J. Laumakis (2008).

An Introduction to Buddhist Philosophy

. Cambridge University Press. pp.  150– 151.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-1-139-46966-1

https://en.wikipedia.org/wiki/ISBN\_(identifier)

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Vetter 1988

https://en.wikipedia.org/wiki/ISBN\_(identifier)

, pp. 11–14.

Vetter 1988

https://en.wikipedia.org#cite\_ref-FOOTNOTEVetter1988\_9-0

https://en.wikipedia.org#cite\_ref-FOOTNOTEVetter1988\_9-0

Bronkhorst 1993

https://en.wikipedia.org#cite\_ref-FOOTNOTEVetter1988\_9-0

https://en.wikipedia.org#cite\_ref-FOOTNOTEVetter1988\_9-0

https://en.wikipedia.org#cite\_ref-FOOTNOTEVetter1988\_9-0

, pp. 147–51.

https://en.wikipedia.org#cite\_ref-FOOTNOTEVetter1988\_9-0

https://en.wikipedia.org#cite\_ref-FOOTNOTEVetter1988\_9-0

, pp. 39–41.

https://en.wikipedia.org#cite\_ref-FOOTNOTEVetter1988\_9-0

Harvey 2016

https://en.wikipedia.org#cite\_ref-FOOTNOTEVetter1988\_9-0

, p. 253–55.

https://en.wikipedia.org#cite\_ref-FOOTNOTEVetter1988\_9-0

Williams, Tribe & Wynne 2012

https://en.wikipedia.org#cite\_ref-FOOTNOTEVetter1988\_9-0

Harvey, Peter (2000).

An introduction to Buddhist ethics: foundations, values and issues

. Cambridge: Cambridge Univ. Press. pp.  123– 24.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

0-521-55394-6

https://en.wikipedia.org/wiki/ISBN\_(identifier)

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Williams 2002

https://en.wikipedia.org/wiki/ISBN\_(identifier)

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Buswell & Lopez 2003

https://en.wikipedia.org/wiki/ISBN\_(identifier)

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Williams 2002

https://en.wikipedia.org/wiki/ISBN\_(identifier)

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Buswell 2004

https://en.wikipedia.org/wiki/ISBN\_(identifier)

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Khenchen Thrangu Rinpoche (2007).

Everyday Consciousness and Primordial Awareness

. Snow Lion. p. 80.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-1-55939-973-9

https://en.wikipedia.org/wiki/ISBN\_(identifier)

permanent dead link

Thomas William Rhys Davids; William Stede (1921).

Pali-English Dictionary

. Motilal Banarsidass. pp.  695– 96.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-81-208-1144-7

https://en.wikipedia.org/wiki/ISBN\_(identifier)

https://en.wikipedia.org/wiki/Template:Cite\_book

}} :  ISBN / Date incompatibility (

https://en.wikipedia.org/wiki/Help:CS1\_errors#invalid\_isbn\_date

https://en.wikipedia.org/wiki/Help:CS1\_errors#invalid\_isbn\_date

Mkhas-grub Dge-legs-dpal-bzaṅ-po; José Ignacio Cabezón (1992).

A Dose of Emptiness: An Annotated Translation of the sTong thun chen mo of mKhas grub dGe legs dpal bzang

. State University of New York Press. p. 214.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-0-7914-0729-5

https://en.wikipedia.org/wiki/ISBN\_(identifier)

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Chögyam Trungpa (2010).

The Heart of the Buddha

. Shambhala Publications. p. 119.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-0-8348-2125-5

https://en.wikipedia.org/wiki/ISBN\_(identifier)

https://en.wikipedia.org/wiki/ISBN\_(identifier)

https://en.wikipedia.org/wiki/ISBN\_(identifier)

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Hirakawa 1990

https://en.wikipedia.org/wiki/ISBN\_(identifier)

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Bucknell 1984

https://en.wikipedia.org/wiki/ISBN\_(identifier)

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Bucknell 1984

https://en.wikipedia.org/wiki/ISBN\_(identifier)

, p. 11-12.

Gethin, Rupert, Sayings of the Buddha: New Translations from the Pali Nikayas (Oxford World's Classics), 2008, p. 142.

Thanissaro Bhikkhu.

"Maha-cattarisaka Sutta"

http://www.accesstoinsight.org/tipitaka/mn/mn.117.than.html

. Access to Insight.

https://web.archive.org/web/20200726000945/https://www.accesstoinsight.org/tipitaka/mn/mn.117.than.html

from the original on 26 July 2020 . Retrieved  6 May  2008 .

https://web.archive.org/web/20200726000945/https://www.accesstoinsight.org/tipitaka/mn/mn.117.than.html

"Taishō Tripiṭaka Vol. 2, No. 99, Sutra 785"

https://web.archive.org/web/20200726000945/https://www.accesstoinsight.org/tipitaka/mn/mn.117.than.html

. Cbeta. Archived from

the original

http://www.cbeta.org/result/normal/T02/0099\_028.htm

on 23 September 2008 . Retrieved  28 October  2008 .

http://www.cbeta.org/result/normal/T02/0099\_028.htm

Choong 2000

http://www.cbeta.org/result/normal/T02/0099\_028.htm

http://www.cbeta.org/result/normal/T02/0099\_028.htm

Fuller 2005

http://www.cbeta.org/result/normal/T02/0099\_028.htm

, p. 55-56.

Vetter 1988

https://en.wikipedia.org#cite\_ref-FOOTNOTEVetter198812,\_77–79\_34-0

, pp. 12, 77–79.

Velez de Cea 2013

https://en.wikipedia.org#cite\_ref-FOOTNOTEVelez\_de\_Cea201354\_35-0

Wei-hsün Fu & Wawrytko 1994

https://en.wikipedia.org#cite\_ref-FOOTNOTEWei-hsün\_FuWawrytko1994194\_36-0

Vetter 1988

https://en.wikipedia.org#cite\_ref-FOOTNOTEVetter198877\_38-0

Harvey 2013

https://en.wikipedia.org#cite\_ref-FOOTNOTEHarvey201383–84\_39-0

, pp. 83–84.

Ajahn Brahm (27 May 2018).

"Word of the Buddha"

https://discourse.suttacentral.net/t/updating-nyanantiloka-theras-word-of-the-buddha/9552/11

https://web.archive.org/web/20200804164855/https://discourse.suttacentral.net/t/updating-nyanantiloka-theras-word-of-the-buddha/9552/11

from the original on 4 August 2020 . Retrieved  11 March  2020 .

Vetter 1988

https://en.wikipedia.org#cite\_ref-FOOTNOTEVetter198812–13\_41-0

, pp. 12–13.

https://en.wikipedia.org#cite\_ref-FOOTNOTEVetter198812–13\_41-0

"Right Speech: samma vaca"

https://en.wikipedia.org#cite\_ref-FOOTNOTEVetter198812–13\_41-0

www.accesstoinsight.org

https://web.archive.org/web/20201109032859/https://www.accesstoinsight.org/ptf/dhamma/sacca/sacca4/samma-vaca/index.html

from the original on 9 November 2020 . Retrieved  29 January  2023 .

https://web.archive.org/web/20201109032859/https://www.accesstoinsight.org/ptf/dhamma/sacca/sacca4/samma-vaca/index.html

Vetter 1988

https://web.archive.org/web/20201109032859/https://www.accesstoinsight.org/ptf/dhamma/sacca/sacca4/samma-vaca/index.html

, p. 12-13.

Analayo (2013),

Satipatthana

, Windhorse Publications: "... sense-restraint, which in fact constitutes an aspect of right effort."

Harvey 2013

https://en.wikipedia.org#cite\_ref-FOOTNOTEHarvey201383\_45-0

Gethin 2003

https://en.wikipedia.org#cite\_ref-FOOTNOTEGethin200332\_46-0

Gethin 2003

https://en.wikipedia.org#cite\_ref-FOOTNOTEGethin200343\_47-0

Williams 2000

https://en.wikipedia.org#cite\_ref-FOOTNOTEWilliams200045\_48-0

https://en.wikipedia.org#cite\_ref-FOOTNOTEPolak2011\_50-0

https://en.wikipedia.org#cite\_ref-FOOTNOTEPolak2011\_50-0

Gunaratana 2001

https://en.wikipedia.org#cite\_ref-FOOTNOTEPolak2011\_50-0

Chryssides & Wilkins (2006)

https://en.wikipedia.org#cite\_ref-FOOTNOTEChryssidesWilkins2006249\_52-0

https://en.wikipedia.org#cite\_ref-FOOTNOTEChryssidesWilkins2006249\_52-0

Sujato 2012

https://en.wikipedia.org#cite\_ref-FOOTNOTEChryssidesWilkins2006249\_52-0

https://en.wikipedia.org#cite\_ref-FOOTNOTEChryssidesWilkins2006249\_52-0

Sujato, Bhikku.

Digha Nikaya The Long Discourses

. SuttaCentral. p. 213.

https://web.archive.org/web/20221118104207/https://readingfaithfully.org/digha-nikaya-translated-by-bhikkhu-sujato-free-epub-kindle-pdf/

from the original on 18 November 2022 . Retrieved  18 November  2022 .

https://web.archive.org/web/20221118104207/https://readingfaithfully.org/digha-nikaya-translated-by-bhikkhu-sujato-free-epub-kindle-pdf/

Vetter 1988

https://web.archive.org/web/20221118104207/https://readingfaithfully.org/digha-nikaya-translated-by-bhikkhu-sujato-free-epub-kindle-pdf/

, p. 12 with footnote 4.

https://web.archive.org/web/20221118104207/https://readingfaithfully.org/digha-nikaya-translated-by-bhikkhu-sujato-free-epub-kindle-pdf/

Bikkhu Sujato,

Mahācattārīsakasutta

, "The Great Forty"

https://suttacentral.net/mn117/en/sujato?layout=plain&reference=none&notes=asterisk&highlight=false&script=latin

https://suttacentral.net/mn117/en/sujato?layout=plain&reference=none&notes=asterisk&highlight=false&script=latin

19 November 2022 at the

Wayback Machine

https://en.wikipedia.org/wiki/Wayback\_Machine

https://en.wikipedia.org/wiki/Wayback\_Machine

Majjhima Nikaya 56,

Upālivāda Sutta

https://www.dhammatalks.org/suttas/MN/MN56.html

16 December 2022 at the

Wayback Machine

https://en.wikipedia.org/wiki/Wayback\_Machine

, translation Thanissaro Bhikkhu

https://en.wikipedia.org/wiki/Wayback\_Machine

The Buddhist Path to Awakening

; Keren Arbel,

Early Buddhist Meditation

Analayo (2011)

https://en.wikipedia.org#cite\_ref-FOOTNOTEAnalayo201113-14\_62-0

, p. 13-14.

Bhikkhu Bodhi.

"The Noble Eightfold Path: The Way to the End of Suffering"

http://www.accesstoinsight.org/lib/authors/bodhi/waytoend.html#ch2

. Access to Insight.

https://web.archive.org/web/20190828222920/http://www.accesstoinsight.org/lib/authors/bodhi/waytoend.html#ch2

from the original on 28 August 2019 . Retrieved  10 July  2010 .

https://web.archive.org/web/20190828222920/http://www.accesstoinsight.org/lib/authors/bodhi/waytoend.html#ch2

Fuller 2005

https://web.archive.org/web/20190828222920/http://www.accesstoinsight.org/lib/authors/bodhi/waytoend.html#ch2

https://web.archive.org/web/20190828222920/http://www.accesstoinsight.org/lib/authors/bodhi/waytoend.html#ch2

Bhikkhu Bodhi (2005).

In the Buddha's Words: An Anthology of Discourses from the Pali Canon

. Wisdom Publications. pp. 147, 446 with note 9.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-0-86171-996-9

https://en.wikipedia.org/wiki/ISBN\_(identifier)

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Richard Gombrich 2009

https://en.wikipedia.org/wiki/ISBN\_(identifier)

, pp. 27–28, 103–09.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

https://en.wikipedia.org/wiki/ISBN\_(identifier)

, pp. 59, 96–97.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

What the Buddha Thought

Thanissaro Bhikkhu (2005).

"Saccavibhanga Sutta"

http://www.accesstoinsight.org/tipitaka/mn/mn.141.than.html

. Access to Insight.

https://web.archive.org/web/20070524160757/http://www.accesstoinsight.org/tipitaka/mn/mn.141.than.html

from the original on 24 May 2007 . Retrieved  19 July  2007 .

Damien Keown; Charles S. Prebish (2013).

Encyclopedia of Buddhism

. Routledge. p. 333.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-1-136-98588-1

https://en.wikipedia.org/wiki/ISBN\_(identifier)

https://web.archive.org/web/20230111060832/https://books.google.com/books?id=NFpcAgAAQBAJ

from the original on 11 January 2023 . Retrieved  5 October  2016 .

Thanissaro Bhikkhu.

"Saccavibhanga Sutta"

http://www.accesstoinsight.org/tipitaka/mn/mn.141.than.html

. Access to Insight.

https://web.archive.org/web/20080511214556/http://www.accesstoinsight.org/tipitaka/mn/mn.141.than.html

from the original on 11 May 2008 . Retrieved  6 May  2008 .

Thanissaro Bhikkhu (1997).

"Samaññaphala Sutta"

http://www.accesstoinsight.org/tipitaka/dn/dn.02.0.than.html

. Access to Insight.

https://web.archive.org/web/20140209063536/http://www.accesstoinsight.org/tipitaka/dn/dn.02.0.than.html

from the original on 9 February 2014 . Retrieved  20 July  2007 .

https://web.archive.org/web/20140209063536/http://www.accesstoinsight.org/tipitaka/dn/dn.02.0.than.html

Kalupahana 1992

https://web.archive.org/web/20140209063536/http://www.accesstoinsight.org/tipitaka/dn/dn.02.0.than.html

Thanissaro Bhikkhu.

"Abhaya Sutta"

http://www.accesstoinsight.org/tipitaka/mn/mn.058.than.html

. Access to Insight.

https://web.archive.org/web/20080511210656/http://www.accesstoinsight.org/tipitaka/mn/mn.058.than.html

from the original on 11 May 2008 . Retrieved  6 May  2008 .

Kalupahana 1992

https://en.wikipedia.org#cite\_ref-FOOTNOTEKalupahana199250–52\_75-0

, pp. 50–52.

https://en.wikipedia.org#cite\_ref-FOOTNOTEKalupahana199250–52\_75-0

Kalupahana 1992

https://en.wikipedia.org#cite\_ref-FOOTNOTEKalupahana199250–52\_75-0

, p. 50-52.

J Ganeri (2007).

The Concealed Art of the Soul: Theories of Self and Practices of Truth in Indian Ethics and Epistemology

. Oxford University Press. pp.  47– 48.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-0-19-920241-6

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Roderick Bucknell; Chris Kang (2013).

The Meditative Way: Readings in the Theory and Practice of Buddhist Meditation

. Routledge. pp.  12– 13.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-1-136-80408-3

https://en.wikipedia.org/wiki/ISBN\_(identifier)

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Christopher Gowans (2004).

Philosophy of the Buddha: An Introduction

. Routledge. pp.  177– 78.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-1-134-46973-4

https://en.wikipedia.org/wiki/ISBN\_(identifier)

https://web.archive.org/web/20230111060836/https://books.google.com/books?id=EbU4Hd5lro0C

from the original on 11 January 2023 . Retrieved  5 October  2016 .

https://web.archive.org/web/20230111060836/https://books.google.com/books?id=EbU4Hd5lro0C

Purusottama Bilimoria; Joseph Prabhu; Renuka M. Sharma (2007).

Indian Ethics: Classical traditions and contemporary challenges

. Ashgate Publishing. pp.  311– 24.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-0-7546-3301-3

https://en.wikipedia.org/wiki/ISBN\_(identifier)

https://en.wikipedia.org/wiki/ISBN\_(identifier)

John Arapura (2003). K. R. Sundararajan & Bithika Mukerji (ed.).

Hindu Spirituality: Postclassical and Modern

. Motilal Banarsidass. pp.  392– 417.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-81-208-1937-5

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Vetter 1988

https://en.wikipedia.org#cite\_ref-FOOTNOTEVetter198812\_82-0

https://en.wikipedia.org#cite\_ref-FOOTNOTEVetter198812\_82-0

Thanissaro Bhikkhu.

"Cunda Kammaraputta Sutta"

http://www.accesstoinsight.org/tipitaka/an/an10/an10.176.than.html

. Access to Insight.

https://web.archive.org/web/20200911215322/https://www.accesstoinsight.org/tipitaka/an/an10/an10.176.than.html

from the original on 11 September 2020 . Retrieved  6 May  2008 .

https://web.archive.org/web/20200911215322/https://www.accesstoinsight.org/tipitaka/an/an10/an10.176.than.html

Christopher Gowans (2015). Steven M. Emmanuel (ed.).

A Companion to Buddhist Philosophy

. John Wiley & Sons. p. 440.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-1-119-14466-3

https://en.wikipedia.org/wiki/ISBN\_(identifier)

https://web.archive.org/web/20230111053956/https://books.google.com/books?id=P\_lmCgAAQBAJ

from the original on 11 January 2023 . Retrieved  5 October  2016 .

https://web.archive.org/web/20230111053956/https://books.google.com/books?id=P\_lmCgAAQBAJ

Andrew Powell (1989).

Living Buddhism

. University of California Press. p. 24.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-0-520-20410-2

https://en.wikipedia.org/wiki/ISBN\_(identifier)

https://en.wikipedia.org/wiki/ISBN\_(identifier)

David L. Weddle (2010).

Miracles: Wonder and Meaning in World Religions

. New York University Press. p. 118.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-0-8147-9483-8

https://en.wikipedia.org/wiki/ISBN\_(identifier)

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Rahula 2007

https://en.wikipedia.org/wiki/ISBN\_(identifier)

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Martine Batchelor (2014).

The Spirit of the Buddha

. Yale University Press. p. 59.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-0-300-17500-4

https://en.wikipedia.org/wiki/ISBN\_(identifier)

https://web.archive.org/web/20230111055838/https://books.google.com/books?id=fL3mykqlOJcC&pg=PT59

from the original on 11 January 2023 . Retrieved  5 October  2016 . ; Quote: These five trades, O monks, should not be taken up by a lay follower: trading with weapons, trading in living beings, trading in meat, trading in intoxicants, trading in poison."

https://web.archive.org/web/20230111055838/https://books.google.com/books?id=fL3mykqlOJcC&pg=PT59

Harvey 2013

https://web.archive.org/web/20230111055838/https://books.google.com/books?id=fL3mykqlOJcC&pg=PT59

, pp. 273–74.

https://web.archive.org/web/20230111055838/https://books.google.com/books?id=fL3mykqlOJcC&pg=PT59

Chip Hartranft (spring 2011),

Did the Buddha Teach Satipatthāna?

https://www.buddhistinquiry.org/article/did-the-buddha-teach-satipatth%c4%81na

4 August 2020 at the

Wayback Machine

https://en.wikipedia.org/wiki/Wayback\_Machine

, Buddhist Inquiry

https://en.wikipedia.org/wiki/Wayback\_Machine

https://en.wikipedia.org/wiki/Wayback\_Machine

, pp. 942–43.

Kevin Trainor (2004).

Buddhism: The Illustrated Guide

. Oxford University Press. p. 74.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-0-19-517398-7

https://en.wikipedia.org/wiki/ISBN\_(identifier)

https://web.archive.org/web/20230111060833/https://books.google.com/books?id=\_PrloTKuAjwC

from the original on 11 January 2023 . Retrieved  5 October  2016 .

https://web.archive.org/web/20230111060833/https://books.google.com/books?id=\_PrloTKuAjwC

Gethin 2003

https://web.archive.org/web/20230111060833/https://books.google.com/books?id=\_PrloTKuAjwC

, p. 37-38.

https://web.archive.org/web/20230111060833/https://books.google.com/books?id=\_PrloTKuAjwC

Gethin 2003

https://web.archive.org/web/20230111060833/https://books.google.com/books?id=\_PrloTKuAjwC

, p. 39, 42.

https://web.archive.org/web/20230111060833/https://books.google.com/books?id=\_PrloTKuAjwC

J. Mark G. Williams; Jon Kabat-Zinn (2013).

Mindfulness: Diverse Perspectives on Its Meaning, Origins and Applications

. Routledge. pp.  21– 27.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-1-317-98514-3

https://en.wikipedia.org/wiki/ISBN\_(identifier)

https://en.wikipedia.org/wiki/ISBN\_(identifier)

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Bodhi, Bhikkhu; Thera, Soma (1998).

"The Way of Mindfulness: The Satipatthana Sutta and Its Commentary"

http://www.accesstoinsight.org/lib/authors/soma/wayof.html

https://web.archive.org/web/20200228152818/https://www.accesstoinsight.org/lib/authors/soma/wayof.html

from the original on 28 February 2020 . Retrieved  27 May  2016 .

https://web.archive.org/web/20200228152818/https://www.accesstoinsight.org/lib/authors/soma/wayof.html

https://web.archive.org/web/20200228152818/https://www.accesstoinsight.org/lib/authors/soma/wayof.html

, pp. 153–56, 196–97.

https://web.archive.org/web/20200228152818/https://www.accesstoinsight.org/lib/authors/soma/wayof.html

https://web.archive.org/web/20200228152818/https://www.accesstoinsight.org/lib/authors/soma/wayof.html

Vetter 1988

https://en.wikipedia.org#cite\_ref-FOOTNOTEVetter198813\_105-0

https://en.wikipedia.org#cite\_ref-FOOTNOTEVetter198813\_105-0

Johannes Bronkhorst (2009).

Buddhist Teaching in India

. Simon and Schuster. pp.  10– 17.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-0-86171-566-4

https://en.wikipedia.org/wiki/ISBN\_(identifier)

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Johannes Bronkhorst (2009).

Buddhist Teaching in India

. Simon and Schuster. pp.  16– 17.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-0-86171-566-4

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Johannes Bronkhorst (2009).

Buddhist Teaching in India

. Simon and Schuster. pp.  17– 19.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-0-86171-566-4

https://en.wikipedia.org/wiki/ISBN\_(identifier)

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Oliver Freiberger (2006).

Asceticism and Its Critics: Historical Accounts and Comparative Perspectives

. Oxford University Press. pp.  249– 51.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-0-19-971901-3

https://en.wikipedia.org/wiki/ISBN\_(identifier)

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Visudimagga 84–85

full citation needed

Henepola Gunaratana (1995), The Jhanas in Theravada Buddhist Meditation

Bronkhorst 1993

Bronkhorst 1993

, pp. 53–70.

Gombrich, Richard (1997).

"Religious Experience in Early Buddhism"

https://ocbs.org/religious-experience-in-early-buddhism/

Oxford Centre for Buddhist Studies

https://web.archive.org/web/20220129114243/https://ocbs.org/religious-experience-in-early-buddhism/

from the original on 29 January 2022 . Retrieved  31 March  2022 .

https://web.archive.org/web/20220129114243/https://ocbs.org/religious-experience-in-early-buddhism/

Thanissaro Bhikkhu.

"Nagara Sutta"

http://www.accesstoinsight.org/tipitaka/sn/sn12/sn12.065.than.html

. Access to Insight.

https://web.archive.org/web/20090418063130/http://www.accesstoinsight.org/tipitaka/sn/sn12/sn12.065.than.html

from the original on 18 April 2009 . Retrieved  6 May  2008 .

https://web.archive.org/web/20090418063130/http://www.accesstoinsight.org/tipitaka/sn/sn12/sn12.065.than.html

"Samyukta Agama, sutra no. 287, Taisho vol 2, p. 80"

https://web.archive.org/web/20090418063130/http://www.accesstoinsight.org/tipitaka/sn/sn12/sn12.065.than.html

. Cbeta. Archived from

the original

http://www.cbeta.org/result/normal/T02/0099\_012.htm

on 23 September 2008 . Retrieved  27 October  2008 .

http://www.cbeta.org/result/normal/T02/0099\_012.htm

"Madhyama Agama, Taishō Tripiṭaka Vol. 1, No. 26, sutra 31 (分別聖諦經第十一)"

http://www.cbeta.org/result/normal/T02/0099\_012.htm

. Cbeta. Archived from

the original

http://www.cbeta.org/result/normal/T01/0026\_007.htm

on 22 November 2008 . Retrieved  28 October  2008 .

http://www.cbeta.org/result/normal/T01/0026\_007.htm

http://www.cbeta.org/result/normal/T01/0026\_007.htm

Taishō Tripiṭaka

(32). Cbeta: 814. Archived from

the original

http://www.cbeta.org/result/normal/T01/0032\_001.htm

on 22 November 2008 . Retrieved  28 October  2008 .   {{

cite journal

https://en.wikipedia.org/wiki/Template:Cite\_journal

}} :  Cite uses generic title (

https://en.wikipedia.org/wiki/Help:CS1\_errors#generic\_title

https://en.wikipedia.org/wiki/Help:CS1\_errors#generic\_title

"Madhyama Agama, Taishō Tripiṭaka Vol. 1, No. 26, sutra 189 (中阿含雙品 聖道經第三)"

https://en.wikipedia.org/wiki/Help:CS1\_errors#generic\_title

. Cbeta. Archived from

the original

http://www.cbeta.org/result/normal/T01/0026\_049.htm

on 22 November 2008 . Retrieved  27 October  2008 .

http://www.cbeta.org/result/normal/T01/0026\_049.htm

http://www.cbeta.org/result/normal/T01/0026\_049.htm

Bhikkhu Bodhi.

"The Noble Eightfold Path: The Way to the End of Suffering"

http://www.accesstoinsight.org/lib/authors/bodhi/waytoend.html

. Buddhist Publication Society. p. 14.

https://web.archive.org/web/20190828222920/http://www.accesstoinsight.org/lib/authors/bodhi/waytoend.html

from the original on 28 August 2019 . Retrieved  6 May  2008 .

https://web.archive.org/web/20190828222920/http://www.accesstoinsight.org/lib/authors/bodhi/waytoend.html

Buswell & Gimello 1994

https://web.archive.org/web/20190828222920/http://www.accesstoinsight.org/lib/authors/bodhi/waytoend.html

https://web.archive.org/web/20190828222920/http://www.accesstoinsight.org/lib/authors/bodhi/waytoend.html

Rinpoche Karma-raṅ-byuṅ-kun-khyab-phrin-las (1986).

The Dharma: That Illuminates All Beings Impartially Like the Light of the Sun and Moon

. State University of New York Press. pp.  32– 33.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-0-88706-156-1

https://en.wikipedia.org/wiki/ISBN\_(identifier)

. ; Quote: "There are various ways of examining the Complete Path. For example, we can speak of Five Paths constituting its different levels: the Path of Accumulation, the Path of Application, the Path of Seeing, the Path of Meditation and the Path of No More Learning, or Buddhahood."

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Prebish 2000

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Harvey 2013

https://en.wikipedia.org#cite\_ref-FOOTNOTEHarvey201383-84\_127-0

, p. 83-84.

https://en.wikipedia.org#cite\_ref-FOOTNOTEHarvey201383-84\_127-0

https://en.wikipedia.org#cite\_ref-FOOTNOTEHarvey201383-84\_127-0

, p. 44-48.

https://en.wikipedia.org#cite\_ref-FOOTNOTEHarvey201383-84\_127-0

https://en.wikipedia.org#cite\_ref-FOOTNOTEHarvey201383-84\_127-0

, p. 44-53.

https://en.wikipedia.org#cite\_ref-FOOTNOTEHarvey201383-84\_127-0

Anderson 2013

https://en.wikipedia.org#cite\_ref-FOOTNOTEHarvey201383-84\_127-0

https://en.wikipedia.org#cite\_ref-FOOTNOTEHarvey201383-84\_127-0

Crosby, Kate (2013). "Theravada Buddhism: Continuity, Diversity, and Identity," p. 113-114, John Wiley & Sons.

https://en.wikipedia.org#cite\_ref-FOOTNOTEHarvey201383-84\_127-0

See for example, the presentation of the path in Henepola Gunaratana (2011). "Eight Mindful Steps to Happiness: Walking the Buddha's Path", Simon and Schuster.

https://en.wikipedia.org#cite\_ref-FOOTNOTEHarvey201383-84\_127-0

Shankman, Richard (2008). "The Experience of Samadhi: An In-depth Exploration of Buddhist Meditation," p. 53. Shambhala Publications.

https://en.wikipedia.org#cite\_ref-FOOTNOTEHarvey201383-84\_127-0

Mahasi Sayadaw (1994). "The Progress of Insight: A Treatise on Satipatthana Meditation," p. vii Buddhist Publication Society

https://en.wikipedia.org#cite\_ref-FOOTNOTEHarvey201383-84\_127-0

Nyanatiloka Thera (2010). "The Buddha's Path to Deliverance: A Systematic Exposition in the Words of the Sutta Piṭaka," p. 42. Buddhist Publication Society.

Nattier (2003)

https://en.wikipedia.org#cite\_ref-FOOTNOTENattier2003137–138,\_142–146\_136-0

, pp. 137–138, 142–146.

https://en.wikipedia.org#cite\_ref-FOOTNOTENattier2003137–138,\_142–146\_136-0

Gyatso (1995)

https://en.wikipedia.org#cite\_ref-FOOTNOTENattier2003137–138,\_142–146\_136-0

https://en.wikipedia.org#cite\_ref-FOOTNOTENattier2003137–138,\_142–146\_136-0

Nattier (2003)

https://en.wikipedia.org#cite\_ref-FOOTNOTENattier2003137–138,\_142–146\_136-0

https://en.wikipedia.org#cite\_ref-FOOTNOTENattier2003137–138,\_142–146\_136-0

Hirakawa (1993)

https://en.wikipedia.org#cite\_ref-FOOTNOTENattier2003137–138,\_142–146\_136-0

https://en.wikipedia.org#cite\_ref-FOOTNOTENattier2003137–138,\_142–146\_136-0

Conze (2001)

https://en.wikipedia.org#cite\_ref-FOOTNOTENattier2003137–138,\_142–146\_136-0

Robinson & Johnson (1997)

https://en.wikipedia.org#cite\_ref-FOOTNOTERobinsonJohnson199799\_141-0

https://en.wikipedia.org#cite\_ref-FOOTNOTERobinsonJohnson199799\_141-0

Nattier (2003)

https://en.wikipedia.org#cite\_ref-FOOTNOTERobinsonJohnson199799\_141-0

, pp. 142–152.

Robinson & Johnson (1997)

https://en.wikipedia.org#cite\_ref-FOOTNOTERobinsonJohnson1997101–102\_143-0

, pp. 101–102.

https://en.wikipedia.org#cite\_ref-FOOTNOTERobinsonJohnson1997101–102\_143-0

Buswell (2004)

https://en.wikipedia.org#cite\_ref-FOOTNOTERobinsonJohnson1997101–102\_143-0

, pp. 631–632.

Watanabe, Chikafumi (2000),

A Study of Mahayanasamgraha III: The Relation of Practical Theories and Philosophical Theories

. Ph.D. dissertation, The University of Calgary, pp. 38-40.

Nattier (2003)

, pp. 151–154.

Keown (2003)

https://en.wikipedia.org#cite\_ref-FOOTNOTEKeown2003212\_147-0

Shōhei Ichimura (2001).

Buddhist Critical Spirituality: Prajñā and Śūnyatā

. Motilal Banarsidass. pp. 28–29 with footnotes 56, 57.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-81-208-1798-2

https://en.wikipedia.org/wiki/ISBN\_(identifier)

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Gyatso (1995)

https://en.wikipedia.org/wiki/ISBN\_(identifier)

, pp. 4–12.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Buswell (2004)

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Kōgen Mizuno; Gaynor Sekimori (1996).

Essentials of Buddhism: basic terminology and concepts of Buddhist philosophy and practice

. Kōsei. pp.

https://archive.org/details/essentialsofbudd00mizu/page/28

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-4-333-01683-9

https://en.wikipedia.org/wiki/ISBN\_(identifier)

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Buswell (2004)

https://en.wikipedia.org/wiki/ISBN\_(identifier)

, pp. 631–632, 664–665, 809.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Shōhei Ichimura (2001).

Buddhist Critical Spirituality: Prajñā and Śūnyatā

. Motilal Banarsidass. p. 114.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-81-208-1798-2

https://en.wikipedia.org/wiki/ISBN\_(identifier)

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Carl Olson (2005).

The Different Paths of Buddhism: A Narrative-Historical Introduction

. Rutgers University Press. pp.

https://archive.org/details/differentpathsof0000olso/page/154

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-0-8135-3778-8

https://en.wikipedia.org/wiki/ISBN\_(identifier)

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Robert E. Buswell, Robert M. Gimello (1992).

"Paths to Liberation: The Marga and Its Transformations in Buddhist Thought,"

pp. 313-314. (Studies in East Asian Buddhism). University of Hawaii Press.

Robert E. Buswell, Robert M. Gimello (1992).

"Paths to Liberation: The Marga and Its Transformations in Buddhist Thought,"

p. 316. (Studies in East Asian Buddhism). University of Hawaii Press.

"Stages of the Path (Lamrim)"

Bhikshuni Thubten Chodron

https://web.archive.org/web/20220830184726/https://thubtenchodron.org/buddhism/02-lam-rim/

from the original on 30 August 2022 . Retrieved  4 December  2022 .

https://web.archive.org/web/20220830184726/https://thubtenchodron.org/buddhism/02-lam-rim/

Gil Fronsdal (5 December 2006).

The Dhammapada: A New Translation of the Buddhist Classic with Annotations

. Shambhala Publications, Inc.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

9780834823808

https://en.wikipedia.org/wiki/ISBN\_(identifier)

. Retrieved  14 July  2009 .

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Peter Randall (2013).

The Psychology of Feeling Sorry: The Weight of the Soul

. Routledge. pp.  206– 208.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-1-136-17026-3

https://en.wikipedia.org/wiki/ISBN\_(identifier)

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=34

Primary sources

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=35

Bodhi, Bhikkhu

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=35

The Noble Eightfold Path: The Way to the End of Suffering

https://web.archive.org/web/20190828222920/http://www.accesstoinsight.org/lib/authors/bodhi/waytoend.html

from the original on 28 August 2019 . Retrieved  4 July  2006 .

Carter, John Ross and Palihawadana, Mahinda; tr.

Buddhism: The Dhammapada

. New York: History Book Club, 1992.

Ñanamoli Thera

(tr.) & Bhikkhu Bodhi (ed., rev.) (1991).

The Discourse on Right View: The Sammaditthi Sutta and its Commentary

http://www.accesstoinsight.org/lib/authors/nanamoli/wheel377.html

10 October 2007 at the

Wayback Machine

https://en.wikipedia.org/wiki/Wayback\_Machine

(The Wheel Publication No. 377/379; includes translations of

https://en.wikipedia.org/wiki/Majjhima\_Nikaya

9 and the associated

https://en.wikipedia.org/wiki/Atthakatha

Papañcasudani

Buddhist Publication Society

https://en.wikipedia.org/wiki/Buddhist\_Publication\_Society

. Retrieved 22 September 2007 from "Access to Insight" (1994).

Nyanasobhano, Bhikkhu (1989).

Two Dialogues on Dhamma

http://www.accesstoinsight.org/lib/authors/price/wheel363.html

25 February 2008 at the

Wayback Machine

https://en.wikipedia.org/wiki/Wayback\_Machine

(Wheel No. 363/364). Kandy:

https://en.wikipedia.org/wiki/Buddhist\_Publication\_Society

. Retrieved 4 February 2008 from "Access to Insight" (2005)

Rahula, Walpola

https://en.wikipedia.org/wiki/Buddhist\_Publication\_Society

What the Buddha Taught

. New York: Grove Press, 1974.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

0-8021-3031-3

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Rewata Dhamma

https://en.wikipedia.org/wiki/ISBN\_(identifier)

The First Discourse of the Buddha

. Somerville, Massachusetts: Wisdom Publications, 1997.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

0-86171-104-1

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Snelling, John.

The Buddhist Handbook: A Complete Guide to Buddhist Schools, Teaching, Practice, and History

. Rochester: Inner Traditions, 1991. ISBN.

Sri Lanka Buddha Jayanti Tipitaka Series (SLTP) (n.d.),

Avijjāvaggo

http://metta.lk/tipitaka/2Sutta-Pitaka/3Samyutta-Nikaya/Samyutta5/44-Magga-Samyutta/01-Avijjavaggo-p.html

http://metta.lk/tipitaka/2Sutta-Pitaka/3Samyutta-Nikaya/Samyutta5/44-Magga-Samyutta/01-Avijjavaggo-p.html

20 March 2013 at the

Wayback Machine

https://en.wikipedia.org/wiki/Wayback\_Machine

https://en.wikipedia.org/wiki/Samyutta\_Nikaya

44 \[Sinhalese ed.\], ch. 1, in

https://en.wikipedia.org/wiki/Pali

). Retrieved on 16 July 2007 from "Mettanet – Lanka"

Secondary sources

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=36

Analayo, Bhikkhu (2011),

"Right View and the Scheme of the Four Truths in Early Buddhism − The Samyukta-āgama Parallel to the Sammādimmhi-sutta and the Simile of the Four Skills of a Physician"

https://buddhistuniversity.net/content/articles/right-view-and-the-four-noble-truths\_analayo

Canadian Journal of Buddhist Studies

https://web.archive.org/web/20221120121640/https://buddhistuniversity.net/content/articles/right-view-and-the-four-noble-truths\_analayo

from the original on 20 November 2022 , retrieved  20 November  2022

Anderson, Carol (2013).

Pain and Its Ending: The Four Noble Truths in the Theravada Buddhist Canon

. Routledge.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-1-136-81325-2

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Alexander Berzin (2007),

"The Eightfold Noble Path"

http://studybuddhism.com/en/advanced-studies/lam-rim/the-five-paths-to-liberation-enlightenment/the-eightfold-noble-path

http://studybuddhism.com/en/advanced-studies/lam-rim/the-five-paths-to-liberation-enlightenment/the-eightfold-noble-path

1 March 2017 at the

Wayback Machine

https://en.wikipedia.org/wiki/Wayback\_Machine

Bronkhorst, Johannes

https://en.wikipedia.org/wiki/Wayback\_Machine

The Two Traditions of Meditation in Ancient India

. Motilal Banarsidass Publ.

Bucknell, Rod (1984).

"The Buddhist to Liberation: An Analysis of the Listing of Stages"

https://journals.ub.uni-heidelberg.de/index.php/jiabs/article/viewFile/8631/2538

The Journal of the International Association of Buddhist Studies

https://web.archive.org/web/20170525145008/https://journals.ub.uni-heidelberg.de/index.php/jiabs/article/viewFile/8631/2538

from the original on 25 May 2017 . Retrieved  28 November  2014 .

Bucknell, Roderick & Stuart-Fox, Martin (1986).

The Twilight Language: Explorations in Buddhist Meditation and Symbolism

. Curzon Press: London.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

0-312-82540-4

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Buswell, Robert E. (2004).

Encyclopedia of Buddhism: A-L

. Macmillan Reference.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-0-02-865719-6

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Bhikkhu Bodhi (1998).

The Noble Eightfold Path: Way to the End of Suffering

(PDF) . Buddhist Publication Society.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

9789552401169

https://en.wikipedia.org/wiki/ISBN\_(identifier)

https://web.archive.org/web/20201126070547/https://www.bps.lk/olib/wh/wh308\_Bodhi\_Noble-Eightfold-Path.pdf

(PDF)  from the original on 26 November 2020 . Retrieved  11 February  2020 .

Buswell, Robert E. Jr; Gimello, Robert M., eds. (1994).

Paths to Liberation. The Marga and its Transformations in Buddhist Thought

. Delhi: Motilal Banarsidass Publishers.

Buswell, Robert E. Jr.; Lopez, Donald Jr. (2003).

The Princeton Dictionary of Buddhism

. Princeton University Press.

Choong, Mun-keat (2000).

The Fundamental Teachings of Early Buddhism: A Comparative Study Based on the Sutranga Portion of the Pali Samyutta-Nikaya and the Chinese Samyuktagama

. Otto Harrassowitz Verlag.

Chryssides, George; Wilkins, Margaret (2006).

A Reader in New Religious Movements

. A&C Black.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-0-8264-6167-4

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Conze, Edward

https://en.wikipedia.org/wiki/ISBN\_(identifier)

The Perfection of Wisdom in Eight Thousand Lines and its Verse Summary

, Grey Fox Press,

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-0-87704-049-1

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Eliot, Charles (2014).

Japanese Buddhism

. Routledge.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-1-317-79274-1

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Fuller, Paul (2005).

The Notion of Ditthi in Theravada Buddhism

. RoutledgeCurzon.

Gethin, Rupert (1998).

Foundations of Buddhism

. Oxford University Press.

Gethin, R.M.L. (2003) \[1992\].

The Buddhist Path to Awakening

. OneWorld Publications.

Richard Gombrich (2009).

What the Buddha thought

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-1-84553-614-5

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Gunaratana, Henepola

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Eight Mindful Steps to Happiness: Walking the Buddha's Path

. Wisdom Publications.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

0-86171-176-9

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Gyatso, Geshe Kelsang

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Introduction to Buddhism: An Explanation of the Buddhist Way of Life

Tharpa Publications

https://en.wikipedia.org/wiki/Tharpa\_Publications

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-0-9789067-7-1

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Harvey, Graham (2016).

Religions in Focus: New Approaches to Tradition and Contemporary Practices

. Routledge.

Harvey, Peter (2013).

An Introduction to Buddhism

. Cambridge University Press.

Hirakawa, Akira (1990).

A History of Indian Buddhism. From Sakyamuni to Early Mahayana

. University of Hawai'i Press.

https://en.wikipedia.org/wiki/Hdl\_(identifier)

10125/23030

https://hdl.handle.net/10125%2F23030

Hirakawa, Akira (1993), Groner, Paul (ed.),

A History of Indian Buddhism: From Śākyamuni to Early Mahāyāna

, translated by Groner, Paul, Delhi: Motilal Banarsidass,

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-81-208-0955-0

https://en.wikipedia.org/wiki/ISBN\_(identifier)

https://web.archive.org/web/20230111060831/https://books.google.com/books?id=XjjwjC7rcOYC

from the original on 11 January 2023 , retrieved  10 July  2016

Kalupahana, David J. (1992).

A history of Buddhist philosophy

. Delhi: Motilal Banarsidass Publishers Private Limited.

Keown, Damien (2000).

Buddhism: A Very Short Introduction

(Kindle ed.). Oxford University Press.

Keown, Damien (2003),

Dictionary of Buddhism

, Oxford University Press,

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-0-19-157917-2

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Kohn, Michael H.; tr.

The Shambhala Dictionary of Buddhism and Zen

. Boston: Shambhala, 1991.

Lopez, Donald S (1995).

Buddhism in Practice

(PDF) . Princeton University Press.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

0-691-04442-2

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Lopez, Donald, jr. (2009).

Buddhism and Science: A Guide for the Perplexed

. University of Chicago Press. {{

https://en.wikipedia.org/wiki/Template:Cite\_book

}} : CS1 maint: multiple names: authors list (

https://en.wikipedia.org/wiki/Category:CS1\_maint:\_multiple\_names:\_authors\_list

Nattier, Jan (2003),

A Few Good Men: The Bodhisattva Path according to The Inquiry of Ugra (Ugrapariprccha)

, University of Hawai'i Press,

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-0-8248-2607-9

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Buddhism and Cognitive Science

. Retrieved 8 July 2006.

Thera, Nyanaponika

(30 November 2013).

The Power of Mindfulness: An Inquiry into the Scope of Bare Attention and the Principal Sources of its Strength

. Access to Insight.

https://web.archive.org/web/20190805153731/https://www.accesstoinsight.org/lib/authors/nyanaponika/wheel121.html

from the original on 5 August 2019 . Retrieved  5 August  2019 .

Polak, Grzegorz (2011).

Reexamining Jhana: Towards a Critical Reconstruction of Early Buddhist Soteriology

Prebish, Charles (2000). "From Monastic Ethics to Modern Society". In Keown, Damien (ed.).

Contemporary Buddhist Ethics

. Routledge Curzon.

Rahula, Walpola (2007).

What the Buddha Taught

. Grove Press.

Raju, P. T. (1985).

Structural Depths of Indian Thought

. State University of New York Press.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-0-88706-139-4

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Robinson, Richard H.; Johnson, Willard L. (1997).

Buddhist Religions: A Historical Introduction

(4th ed.). Wadsworth Publishing.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-0-534-55858-1

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Sharf, Robert M. (2014),

"Mindfulness and mindlessness in early Chan"

http://www.thezensite.com/ZenEssays/HistoricalZen/Mind\_and\_Mindlessness.pdf

Philosophy East and West

(4):  933– 964,

https://en.wikipedia.org/wiki/Doi\_(identifier)

10.1353/pew.2014.0074

https://doi.org/10.1353%2Fpew.2014.0074

https://en.wikipedia.org/wiki/S2CID\_(identifier)

https://en.wikipedia.org/wiki/S2CID\_(identifier)

https://web.archive.org/web/20210427081440/http://www.thezensite.com/ZenEssays/HistoricalZen/Mind\_and\_Mindlessness.pdf

(PDF)  from the original on 27 April 2021 , retrieved  20 December  2020

Spiro, Melford E. (1982).

Buddhism and Society: A Great Tradition and Its Burmese Vicissitudes

. University of California Press.

Sujato, Bhante

A History of Mindfulness

(PDF) , Santipada,

https://en.wikipedia.org/wiki/ISBN\_(identifier)

9781921842092

https://en.wikipedia.org/wiki/ISBN\_(identifier)

https://web.archive.org/web/20181123134655/http://santifm.org/santipada/wp-content/uploads/2012/08/A\_History\_of\_Mindfulness\_Bhikkhu\_Sujato.pdf

(PDF)  from the original on 23 November 2018 , retrieved  20 November  2022

Velez de Cea, J. Abraham (2013).

The Buddha and Religious Diversity

. Routledge.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-1-135-10039-1

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Vetter, Tilmann (1988).

The Ideas and Meditative Practices of Early Buddhism

https://en.wikipedia.org/wiki/ISBN\_(identifier)

90-04-08959-4

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Wei-hsün Fu, Charles; Wawrytko, Sandra Ann (1994).

Buddhist Behavioral Codes and the Modern World: An International Symposium

. Greenwood.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-0-313-28890-6

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Williams, Paul (2000).

Mahayana Buddhism: The Doctrinal Foundations

. Routledge.

Williams, Paul (2002).

Buddhist Thought

(Kindle ed.). Taylor & Francis.

Williams, Paul; Tribe, Anthony; Wynne, Alexander (2012).

Buddhist Thought

. Routledge.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-1-136-52088-4

https://en.wikipedia.org/wiki/ISBN\_(identifier)

Web-sources

Victor Gunasekara,

The Pāyāsi Sutta: A Commentary and Analysis

26 January 2017 at the

Wayback Machine

https://en.wikipedia.org/wiki/Wayback\_Machine

External links

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&action=edit&section=37

Wikiquote has quotations related to

Noble Eightfold Path

"The Path to Peace and Freedom for the Mind"

16 May 2008 at the

Wayback Machine

https://en.wikipedia.org/wiki/Wayback\_Machine

by Ajaan Lee Dhammadharo

"The Craft of the Heart"

https://en.wikipedia.org/wiki/Wayback\_Machine

https://en.wikipedia.org/wiki/Wayback\_Machine

14 May 2008 at the

Wayback Machine

https://en.wikipedia.org/wiki/Wayback\_Machine

by Ajaan Lee Dhammadharo

"A Handful of Leaves"

https://en.wikipedia.org/wiki/Wayback\_Machine

by Tillmann VETTER. and E.J. BRILL. LEIDEN • NEW YORK· K0BENHA VN • KOLN. 1988 ... Vetter. p. cm. Translated from Dutch, with revisions. Bibliography

https://en.wikipedia.org/wiki/Wayback\_Machine

https://en.wikipedia.org/wiki/Wayback\_Machine

https://en.wikipedia.org/wiki/Wayback\_Machine

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Foundations

https://en.wikipedia.org/wiki/Buddhism

Four Noble Truths

https://en.wikipedia.org/wiki/Buddhism

Three Jewels

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Noble Eightfold Path

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Four sights

https://en.wikipedia.org/wiki/Buddhism

Eight Great Events

https://en.wikipedia.org/wiki/Buddhism

Great Renunciation

https://en.wikipedia.org/wiki/Buddhism

Physical characteristics

https://en.wikipedia.org/wiki/Buddhism

Life of Buddha in art

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Iconography in Laos and Thailand

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Suddhodāna (father)

https://en.wikipedia.org/wiki/Buddhism

Māyā (mother)

https://en.wikipedia.org/wiki/Buddhism

Mahapajapati Gotamī (aunt, adoptive mother)

https://en.wikipedia.org/wiki/Buddhism

Yaśodharā (wife)

https://en.wikipedia.org/wiki/Buddhism

Rāhula (son)

https://en.wikipedia.org/wiki/Buddhism

Ānanda (cousin)

https://en.wikipedia.org/wiki/Buddhism

Devadatta (cousin)

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Places where the Buddha stayed

https://en.wikipedia.org/wiki/Buddhism

Buddha in world religions

https://en.wikipedia.org/wiki/Buddhism

Bodhisattvas

https://en.wikipedia.org/wiki/Buddhism

Avalokiteśvara

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Mahāsthāmaprāpta

https://en.wikipedia.org/wiki/Buddhism

Ākāśagarbha

https://en.wikipedia.org/wiki/Buddhism

Kṣitigarbha

https://en.wikipedia.org/wiki/Buddhism

Samantabhadra

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Metteyya/Maitreya

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Mahamoggallāna

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Mahākassapa

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Mahākaccana

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Puṇṇa Mantānīputta

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Mahapajapati Gotamī

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Uppalavanna

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Key concepts

https://en.wikipedia.org/wiki/Buddhism

Avidyā (Ignorance)

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Buddha-nature

https://en.wikipedia.org/wiki/Buddhism

Dhamma theory

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Enlightenment

https://en.wikipedia.org/wiki/Buddhism

Five hindrances

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Mental factors

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Parinirvana

https://en.wikipedia.org/wiki/Buddhism

Pratītyasamutpāda

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Taṇhā (Craving)

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Ten Fetters

https://en.wikipedia.org/wiki/Buddhism

Three marks of existence

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Two truths doctrine

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Ten spiritual realms

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Human realm

https://en.wikipedia.org/wiki/Buddhism

Asura realm

https://en.wikipedia.org/wiki/Buddhism

Hungry Ghost realm

https://en.wikipedia.org/wiki/Buddhism

Animal realm

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Three planes of existence

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Chinese Chan

https://en.wikipedia.org/wiki/Buddhism

Japanese Zen

https://en.wikipedia.org/wiki/Buddhism

Korean Seon

https://en.wikipedia.org/wiki/Buddhism

Vietnamese Thiền

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Tibetan Buddhism

https://en.wikipedia.org/wiki/Buddhism

Chinese Esoteric Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Early Buddhist schools

https://en.wikipedia.org/wiki/Buddhism

Pre-sectarian Buddhism

https://en.wikipedia.org/wiki/Buddhism

Basic points unifying Theravāda and Mahāyāna

https://en.wikipedia.org/wiki/Buddhism

Southern, Eastern and Northern Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Bodhipakkhiyādhammā

https://en.wikipedia.org/wiki/Buddhism

Brahmavihara

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Buddhābhiṣeka

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Five Strengths

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Kammaṭṭhāna

https://en.wikipedia.org/wiki/Buddhism

Recollection

https://en.wikipedia.org/wiki/Buddhism

https://en.wikipedia.org/wiki/Buddhism

Anapanasati

https://en.wikipedia.org/wiki/Buddhism

Samatha-vipassanā

https://en.wikipedia.org/wiki/Buddhism

Vipassana movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

Mindfulness

https://en.wikipedia.org/wiki/Vipassana\_movement

Mindful Yoga

https://en.wikipedia.org/wiki/Vipassana\_movement

Satipatthana

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

Prostration

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

Seven Factors of Enlightenment

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

Dhamma vicaya

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

Five precepts

https://en.wikipedia.org/wiki/Vipassana\_movement

Eight precepts

https://en.wikipedia.org/wiki/Vipassana\_movement

Bodhisattva vow

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

Threefold Training

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

Four Right Exertions

https://en.wikipedia.org/wiki/Vipassana\_movement

Twenty-two vows of Ambedkar

https://en.wikipedia.org/wiki/Vipassana\_movement

Yujia Yankou

https://en.wikipedia.org/wiki/Vipassana\_movement

Shuilu Fahui

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

Bodhisattva

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

Pratyekabuddhayāna

https://en.wikipedia.org/wiki/Vipassana\_movement

Four stages of awakening

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

Monasticism

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

Western tulku

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

Householder

https://en.wikipedia.org/wiki/Vipassana\_movement

Upāsaka and Upāsikā

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

Ten principal disciples

https://en.wikipedia.org/wiki/Vipassana\_movement

Shaolin Monastery

https://en.wikipedia.org/wiki/Vipassana\_movement

Major figures

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

Buddhaghosa

https://en.wikipedia.org/wiki/Vipassana\_movement

Buddhapālita

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

Bodhidharma

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

Emperor Wen of Sui

https://en.wikipedia.org/wiki/Vipassana\_movement

Songtsen Gampo

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

Padmasambhava

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

Panchen Lama

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

B. R. Ambedkar

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

Thích Nhất Hạnh

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

Early Buddhist texts

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

Mahayana sutras

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

Chinese Buddhist canon

https://en.wikipedia.org/wiki/Vipassana\_movement

Tibetan Buddhist canon

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

Madhyamakālaṃkāra

https://en.wikipedia.org/wiki/Vipassana\_movement

Abhidharmadīpa

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

Afghanistan

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

Philippines

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://en.wikipedia.org/wiki/Vipassana\_movement

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

South Africa

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Central Asia

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Middle East

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Saudi Arabia

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Western countries

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Czech Republic

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

New Zealand

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Switzerland

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

United Kingdom

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

United States

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Buddhist councils

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

History of Buddhism in India

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Decline of Buddhism in India

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Huichang persecution of Buddhism

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Greco-Buddhism

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Gandharan Buddhism

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Buddhism and the Roman world

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Buddhism in the West

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Silk Road transmission of Buddhism

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Persecution of Buddhists

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

In Afghanistan

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Rimé movement

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Banishment of Buddhist monks from Nepal

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Dalit Buddhist movement

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Chinese invasion of Tibet

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

1959 Tibetan uprising

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Sinhalese Buddhist nationalism

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Buddhist modernism

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Vipassana movement

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

969 Movement

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Engaged Buddhism

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Women in Buddhism

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Buddhism and democracy

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Eight Consciousnesses

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Engaged Buddhism

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Eschatology

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Secular Buddhism

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

The unanswerable questions

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Architecture

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Ordination hall

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Burmese pagoda

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Dzong architecture

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

List of Buddhist architecture in China

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Japanese Buddhist architecture

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Buddhist temples in Korea

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Thai temple art and architecture

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Tibetan Buddhist architecture

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Greco-Buddhist

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Buddha in art

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Asalha Puja

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Jaya Sri Maha Bodhi

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Mahabodhi Temple

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Om mani padme hum

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Maya Devi Temple

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Prayer beads

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Prayer wheel

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Dharmachakra

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Temple of the Tooth

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Vegetarianism

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Miscellaneous

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Dharma talk

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Sacred languages

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Baháʼí Faith

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Christianity

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

East Asian religions

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Western philosophy

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Bodhisattvas

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Buddhism portal

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

https://ru.wikipedia.org/wiki/%D0%91%D1%83%D0%B4%D0%B4%D0%B8%D0%B7%D0%BC\_%D0%B2\_%D0%A2%D1%8B%D0%B2%D0%B5

Gautama Buddha

https://en.wikipedia.org/wiki/The\_Buddha

https://en.wikipedia.org/wiki/The\_Buddha

Core teachings

https://en.wikipedia.org/wiki/The\_Buddha

Four Noble Truths

https://en.wikipedia.org/wiki/The\_Buddha

Noble Eightfold Path

https://en.wikipedia.org/wiki/The\_Buddha

https://en.wikipedia.org/wiki/The\_Buddha

https://en.wikipedia.org/wiki/The\_Buddha

https://en.wikipedia.org/wiki/The\_Buddha

ten principal disciples

https://en.wikipedia.org/wiki/The\_Buddha

Four sights

https://en.wikipedia.org/wiki/The\_Buddha

Eight Great Events

https://en.wikipedia.org/wiki/The\_Buddha

Great Renunciation

https://en.wikipedia.org/wiki/The\_Buddha

https://en.wikipedia.org/wiki/The\_Buddha

https://en.wikipedia.org/wiki/The\_Buddha

https://en.wikipedia.org/wiki/The\_Buddha

Mahapajapati Gotami

https://en.wikipedia.org/wiki/The\_Buddha

https://en.wikipedia.org/wiki/The\_Buddha

https://en.wikipedia.org/wiki/The\_Buddha

https://en.wikipedia.org/wiki/The\_Buddha

https://en.wikipedia.org/wiki/The\_Buddha

https://en.wikipedia.org/wiki/Bodh\_Gaya

https://en.wikipedia.org/wiki/Bodhi\_tree

Mahabodhi Temple

https://en.wikipedia.org/wiki/Mahabodhi\_Temple

pilgrimage sites

https://en.wikipedia.org/wiki/Mahabodhi\_Temple

https://en.wikipedia.org/wiki/Mahabodhi\_Temple

https://en.wikipedia.org/wiki/Mahabodhi\_Temple

https://en.wikipedia.org/wiki/Mahabodhi\_Temple

https://en.wikipedia.org/wiki/Mahabodhi\_Temple

Physical characteristics

https://en.wikipedia.org/wiki/Mahabodhi\_Temple

https://en.wikipedia.org/wiki/Mahabodhi\_Temple

https://en.wikipedia.org/wiki/Mahabodhi\_Temple

https://en.wikipedia.org/wiki/Mahabodhi\_Temple

https://en.wikipedia.org/wiki/Mahabodhi\_Temple

https://en.wikipedia.org/wiki/Mahabodhi\_Temple

Buddha in art

https://en.wikipedia.org/wiki/Mahabodhi\_Temple

life in art

https://en.wikipedia.org/wiki/Mahabodhi\_Temple

Iconography

https://en.wikipedia.org/wiki/Mahabodhi\_Temple

https://en.wikipedia.org/wiki/Mahabodhi\_Temple

Gautama Buddha in world religions

https://en.wikipedia.org/wiki/Mahabodhi\_Temple

https://en.wikipedia.org/wiki/Mahabodhi\_Temple

https://en.wikipedia.org/wiki/Mahabodhi\_Temple

https://en.wikipedia.org/wiki/Mahabodhi\_Temple

Authority control databases

https://en.wikipedia.org/wiki/Mahabodhi\_Temple

https://www.wikidata.org/wiki/Q185514#identifiers

United States

https://www.wikidata.org/wiki/Q185514#identifiers

Czech Republic

https://www.wikidata.org/wiki/Q185514#identifiers

https://www.wikidata.org/wiki/Q185514#identifiers

Retrieved from "

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&oldid=1285600955

https://en.wikipedia.org/w/index.php?title=Noble\_Eightfold\_Path&oldid=1285600955

https://en.wikipedia.org/wiki/Help:Category

Buddhist philosophical concepts

https://en.wikipedia.org/wiki/Help:Category

Buddhist meditation

https://en.wikipedia.org/wiki/Help:Category

Buddhist ethics

https://en.wikipedia.org/wiki/Help:Category

#### Hidden categories:

All articles with dead external links

https://en.wikipedia.org/wiki/Help:Category

Articles with dead external links from October 2023

https://en.wikipedia.org/wiki/Help:Category

Articles with permanently dead external links

https://en.wikipedia.org/wiki/Help:Category

CS1 errors: ISBN date

https://en.wikipedia.org/wiki/Help:Category

Webarchive template wayback links

https://en.wikipedia.org/wiki/Help:Category

All articles with incomplete citations

https://en.wikipedia.org/wiki/Help:Category

Articles with incomplete citations from September 2016

https://en.wikipedia.org/wiki/Help:Category

CS1 errors: generic title

https://en.wikipedia.org/wiki/Help:Category

Articles with short description

https://en.wikipedia.org/wiki/Help:Category

Short description is different from Wikidata

https://en.wikipedia.org/wiki/Help:Category

Use dmy dates from September 2024

https://en.wikipedia.org/wiki/Help:Category

Articles containing Sanskrit-language text

https://en.wikipedia.org/wiki/Help:Category

Articles containing Pali-language text

https://en.wikipedia.org/wiki/Help:Category

Articles containing Bengali-language text

https://en.wikipedia.org/wiki/Help:Category

Articles containing Burmese-language text

https://en.wikipedia.org/wiki/Help:Category

Articles containing Chinese-language text

https://en.wikipedia.org/wiki/Help:Category

Articles containing Japanese-language text

https://en.wikipedia.org/wiki/Help:Category

Articles containing Khmer-language text

https://en.wikipedia.org/wiki/Help:Category

Articles containing Korean-language text

https://en.wikipedia.org/wiki/Help:Category

Articles containing Mongolian-language text

https://en.wikipedia.org/wiki/Help:Category

Articles containing Sinhala-language text

https://en.wikipedia.org/wiki/Help:Category

Articles containing Standard Tibetan-language text

https://en.wikipedia.org/wiki/Help:Category

Articles containing Tamil-language text

https://en.wikipedia.org/wiki/Help:Category

Articles containing Tagalog-language text

https://en.wikipedia.org/wiki/Help:Category

Articles containing Thai-language text

https://en.wikipedia.org/wiki/Help:Category

Articles containing Vietnamese-language text

https://en.wikipedia.org/wiki/Help:Category

All articles with unsourced statements

https://en.wikipedia.org/wiki/Help:Category

Articles with unsourced statements from October 2018

https://en.wikipedia.org/wiki/Help:Category

CS1 maint: multiple names: authors list

https://en.wikipedia.org/wiki/Help:Category

